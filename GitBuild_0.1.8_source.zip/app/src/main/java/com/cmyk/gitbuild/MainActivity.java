package com.cmyk.gitbuild;

import android.app.*;
import android.content.*;
import android.content.ContentValues;
import android.content.ClipData;
import android.content.res.ColorStateList;
import android.content.ClipboardManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.util.Base64;
import android.view.*;
import android.widget.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class MainActivity extends Activity {
    private static final int BG=Color.rgb(48,48,48), DGRAY=Color.rgb(37,32,32), GRAY=Color.rgb(69,64,64),
            LGRAY=Color.rgb(101,96,96), BLUE=Color.rgb(34,51,85), LBLUE=Color.rgb(68,85,119),
            RED=Color.rgb(68,17,0), ORANGE=Color.rgb(119,85,0), WHITE=Color.rgb(169,169,153), GREEN=Color.rgb(34,119,51), TEXT=Color.WHITE;
    private static final String CALLBACK_BASE = "http://127.0.0.1/callback";
    private static final String RETURN_URI = "gitbuild://oauth/return";
    private final List<SharedItem> shared = new ArrayList<>();
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private SecureStore store;
    private GitHubApi.Repo selectedRepo;
    private TextView repoText, statusText, authText;
    private LinearLayout filesContent, authContent, statusContent;
    private GreenCheckView authCheck, statusCheck;
    private Button buildButton, emergencyStopButton, authButton, runApkButton;
    private NToggleSwitch privateSwitch, recoverySwitch;
    private Uri lastApkUri;
    private String lastApkName;
    private OAuthLoopbackServer oauthServer;
    private volatile boolean cancelRequested;
    private volatile long activeRunId = -1L;
    private volatile Thread activeBuildThread;
    private final ExecutorService controlIo = Executors.newSingleThreadExecutor();

    private static final class SavedApk {
        final String name; final Uri uri;
        SavedApk(String name, Uri uri){ this.name=name; this.uri=uri; }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        DiagnosticLog.init(this);
        DiagnosticLog.log("APP onCreate action="+(getIntent()==null?"null":getIntent().getAction())+" data="+safeIntentData(getIntent()));
        store = new SecureStore(this); buildUi(); acceptIntent(getIntent()); handleReturnIntent(getIntent()); refreshAuthUi();
        DiagnosticLog.log("AUTH startup configured="+isConfigured()+" loggedIn="+isLoggedIn()+" pending="+notEmpty(store.getString("oauth_state")));
    }
    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i); setIntent(i);
        DiagnosticLog.log("APP onNewIntent action="+(i==null?"null":i.getAction())+" data="+safeIntentData(i));
        acceptIntent(i); handleReturnIntent(i);
    }
    @Override protected void onResume() {
        super.onResume();
        DiagnosticLog.log("APP onResume loggedIn="+isLoggedIn()+" pending="+notEmpty(store.getString("oauth_state")));
        refreshAuthUi(); showOAuthStateIfNeeded();
    }
    @Override protected void onDestroy() {
        DiagnosticLog.log("APP onDestroy changingConfig="+isChangingConfigurations()+" server="+(oauthServer!=null));
        if(oauthServer!=null) oauthServer.close(); io.shutdownNow(); controlIo.shutdownNow(); super.onDestroy();
    }

    private void buildUi() {
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(18),dp(18),dp(18)); root.setBackgroundColor(BG);
        root.addView(space(50));
        LinearLayout titleRow=row();
        TextView title=text("GitBuild",24,true); titleRow.addView(title,new LinearLayout.LayoutParams(0,dp(44),1f));
        TextView menu=menuIcon();
        titleRow.addView(menu,new LinearLayout.LayoutParams(dp(44),dp(44))); root.addView(titleRow,new LinearLayout.LayoutParams(-1,dp(44)));
        menu.setOnClickListener(v->{
            PopupMenu pm=new PopupMenu(this,menu);
            pm.getMenu().add("使用方法");
            pm.getMenu().add("診断ログ");
            pm.setOnMenuItemClickListener(item->{
                String t=String.valueOf(item.getTitle());
                if("使用方法".equals(t)) showUsage(); else if("診断ログ".equals(t)) showDiagnosticLog();
                return true;
            });
            pm.show();
        });
        TextView ver=text("0.1.8",12,false); ver.setTextColor(WHITE); root.addView(ver);
        root.addView(space(14));

        root.addView(label("GitHub"));
        authContent=row(); authContent.setGravity(Gravity.CENTER_VERTICAL);
        authCheck=new GreenCheckView(this); authCheck.setVisibility(View.GONE); authContent.addView(authCheck,new LinearLayout.LayoutParams(dp(20),dp(20)));
        authContent.addView(hGap(8)); authText=text("未ログイン",15,false); authContent.addView(authText,new LinearLayout.LayoutParams(0,-2,1f));
        root.addView(cardView(authContent));
        LinearLayout authButtons=row(); authButton=button("GitHubでログイン", LBLUE); Button settings=button("OAuth設定", GRAY);
        authButtons.addView(authButton,weight()); authButtons.addView(gap()); authButtons.addView(settings,weight()); root.addView(authButtons);
        authButton.setOnClickListener(v->{ if(isLoggedIn()) logout(); else beginLogin(); });
        settings.setOnClickListener(v->oauthSettingsDialog());

        root.addView(space(14));
        root.addView(label("受信ファイル"));
        filesContent=new LinearLayout(this); filesContent.setOrientation(LinearLayout.VERTICAL);
        root.addView(cardView(filesContent));
        root.addView(space(12));
        root.addView(label("リポジトリ")); repoText=text("未選択",15,false);
        View repoCard=card(repoText); repoCard.setClickable(true); repoCard.setFocusable(true); repoCard.setOnClickListener(v->loadRepos()); repoText.setOnClickListener(v->loadRepos()); root.addView(repoCard);
        LinearLayout repoButtons=row();
        privateSwitch=new NToggleSwitch(this);
        privateSwitch.setOnThumbColor(ORANGE);
        privateSwitch.setChecked(false,false);
        TextView privateLabel=text("Public",14,false);
        privateSwitch.setOnCheckedChangeListener((view,checked)->privateLabel.setText(checked?"Private":"Public"));
        LinearLayout privateBox=new LinearLayout(this); privateBox.setOrientation(LinearLayout.HORIZONTAL); privateBox.setGravity(Gravity.CENTER_VERTICAL|Gravity.START);
        privateBox.addView(privateSwitch,new LinearLayout.LayoutParams(dp(44),dp(26)));
        privateBox.addView(hGap(8)); privateBox.addView(privateLabel,new LinearLayout.LayoutParams(-2,dp(44)));
        privateLabel.setOnClickListener(v->privateSwitch.toggle());
        Button create=button("新規作成", ORANGE);
        repoButtons.addView(privateBox,weight()); repoButtons.addView(gap()); repoButtons.addView(create,weight()); root.addView(repoButtons);

        root.addView(space(12));
        root.addView(label("ビルド状態"));
        statusContent=new LinearLayout(this); statusContent.setOrientation(LinearLayout.VERTICAL);
        LinearLayout statusRow=row(); statusRow.setGravity(Gravity.CENTER_VERTICAL);
        statusCheck=new GreenCheckView(this); statusCheck.setVisibility(View.GONE); statusRow.addView(statusCheck,new LinearLayout.LayoutParams(dp(20),dp(20)));
        statusRow.addView(hGap(8)); statusText=text("待機中",15,false); statusRow.addView(statusText,new LinearLayout.LayoutParams(0,-2,1f)); statusContent.addView(statusRow);
        runApkButton=button("実行", ORANGE); runApkButton.setVisibility(View.GONE); runApkButton.setOnClickListener(v->runLastApk());
        LinearLayout runRow=row(); Space runStretch=new Space(this); runRow.addView(runStretch,new LinearLayout.LayoutParams(0,1,1f)); runRow.addView(runApkButton,new LinearLayout.LayoutParams(dp(76),dp(36))); statusContent.addView(runRow);
        root.addView(cardView(statusContent));
        root.addView(space(12));
        buildButton=button("アップロード＆ビルド", BLUE); root.addView(buildButton,new LinearLayout.LayoutParams(-1,dp(48)));
        root.addView(space(8));
        emergencyStopButton=button("緊急停止", DGRAY); emergencyStopButton.setEnabled(false);
        root.addView(emergencyStopButton,new LinearLayout.LayoutParams(-1,dp(48)));
        root.addView(space(6));
        LinearLayout recoveryRow=row(); recoveryRow.setGravity(Gravity.CENTER_VERTICAL|Gravity.START);
        recoverySwitch=new NToggleSwitch(this); recoverySwitch.setOnThumbColor(RED); recoverySwitch.setChecked(true,false);
        TextView recoveryLabel=text("前の状態にリカバリー",14,false);
        recoveryRow.addView(recoverySwitch,new LinearLayout.LayoutParams(dp(44),dp(26)));
        recoveryRow.addView(hGap(8)); recoveryRow.addView(recoveryLabel,new LinearLayout.LayoutParams(-2,dp(44)));
        recoveryLabel.setOnClickListener(v->recoverySwitch.toggle());
        root.addView(recoveryRow,new LinearLayout.LayoutParams(-1,dp(44)));
        create.setOnClickListener(v->createRepoDialog()); buildButton.setOnClickListener(v->startBuild());
        emergencyStopButton.setOnClickListener(v->requestEmergencyStop());
        ScrollView sv=new ScrollView(this); sv.addView(root); setContentView(sv);
        refreshFiles();
    }

    private void acceptIntent(Intent intent) {
        if(intent==null) return;
        String a=intent.getAction(); if(!Intent.ACTION_SEND.equals(a)&&!Intent.ACTION_SEND_MULTIPLE.equals(a)) return;
        DiagnosticLog.log("SHARE receive action="+a+" type="+intent.getType());
        shared.clear();
        if(Intent.ACTION_SEND.equals(a)) { Uri u=intent.getParcelableExtra(Intent.EXTRA_STREAM); if(u!=null) addUri(u); }
        else { ArrayList<Uri> us=intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM); if(us!=null) for(Uri u:us) addUri(u); }
        refreshFiles();
    }
    private void addUri(Uri u) {
        String name="shared_file"; long size=-1;
        try(Cursor c=getContentResolver().query(u,new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE},null,null,null)) {
            if(c!=null&&c.moveToFirst()){ name=c.getString(0); size=c.isNull(1)?-1:c.getLong(1); }
        } catch(Exception ignored){}
        shared.add(new SharedItem(u,name,size));
        DiagnosticLog.log("SHARE item name="+name+" size="+size+" uriScheme="+(u==null?"null":u.getScheme()));
    }
    private void refreshFiles(){
        if(filesContent==null)return;
        filesContent.removeAllViews();
        if(shared.isEmpty()){ filesContent.addView(text("ソースZIP と .yml を共有してください",15,false)); return; }
        for(int i=0;i<shared.size();i++){
            SharedItem f=shared.get(i);
            LinearLayout line=row(); line.setGravity(Gravity.CENTER_VERTICAL);
            GreenCheckView check=new GreenCheckView(this); line.addView(check,new LinearLayout.LayoutParams(dp(20),dp(20))); line.addView(hGap(8));
            TextView t=text(f.name+(f.size>=0?"   "+human(f.size):""),15,false); line.addView(t,new LinearLayout.LayoutParams(0,-2,1f));
            filesContent.addView(line,new LinearLayout.LayoutParams(-1,dp(32)));
        }
    }

    private boolean isConfigured(){ return notEmpty(store.getString("client_id")) && notEmpty(store.getSecret("client_secret")); }
    private boolean isLoggedIn(){ return notEmpty(store.getSecret("access_token")); }
    private void refreshAuthUi(){
        boolean logged=isLoggedIn();
        if(authCheck!=null) authCheck.setVisibility(logged?View.VISIBLE:View.GONE);
        if(logged) { String login=store.getString("login"); authText.setText("ログイン中"+(notEmpty(login)?" : "+login:"")); authButton.setText("ログアウト"); authButton.setBackground(round(DGRAY,10)); }
        else if(notEmpty(store.getString("oauth_state"))) { authText.setText("GitHub認証処理中…"); authButton.setText("GitHubでログイン"); authButton.setBackground(round(LBLUE,10)); }
        else { authText.setText(isConfigured()?"未ログイン":"OAuth App未設定"); authButton.setText("GitHubでログイン"); authButton.setBackground(round(LBLUE,10)); }
    }

    private void showOAuthStateIfNeeded() {
        if(isLoggedIn()) return;
        String err=store.getString("oauth_last_error");
        if(notEmpty(err)) status("OAuthエラー\n"+err);
        else if(notEmpty(store.getString("oauth_state"))) status("GitHubログイン処理中…");
    }

    private void handleReturnIntent(Intent intent) {
        Uri d=intent==null?null:intent.getData();
        if(d==null || !"gitbuild".equalsIgnoreCase(d.getScheme()) || !"oauth".equalsIgnoreCase(d.getHost())) return;
        DiagnosticLog.log("OAUTH return intent path="+d.getPath()+" loggedIn="+isLoggedIn()+" lastError="+notEmpty(store.getString("oauth_last_error")));
        refreshAuthUi();
        if(isLoggedIn()) statusSuccess("GitHubログイン完了",false);
        else if(notEmpty(store.getString("oauth_last_error"))) status("OAuthエラー\n"+store.getString("oauth_last_error"));
        else status("GitHubログイン処理中…");
    }

    private void oauthSettingsDialog() {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(18),dp(4),dp(18),0);
        TextView info=text("GitHub OAuth Appを1つ作成し、下のRedirect URIを登録してください。GitHubのログイン名・パスワードではありません。PATも不要です。",13,false); info.setTextColor(WHITE); box.addView(info);
        TextView cb=text(CALLBACK_BASE,13,false); cb.setTextColor(TEXT); cb.setPadding(0,dp(10),0,dp(10)); cb.setTextIsSelectable(true); box.addView(cb);
        EditText id=input("Client ID", false); String oldId=store.getString("client_id"); if(oldId!=null)id.setText(oldId); box.addView(id,new LinearLayout.LayoutParams(-1,dp(52)));
        box.addView(space(8));
        EditText secret=input("Client Secret", true); String oldSecret=store.getSecret("client_secret"); if(oldSecret!=null)secret.setText(oldSecret); box.addView(secret,new LinearLayout.LayoutParams(-1,dp(52)));
        AlertDialog d=new AlertDialog.Builder(this).setTitle("OAuth設定").setView(box)
                .setNegativeButton("キャンセル",null)
                .setNeutralButton("OAuth App作成",null)
                .setPositiveButton("保存",null).create();
        d.setOnShowListener(x->{
            d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->openUrl("https://github.com/settings/applications/new"));
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
                String nid=id.getText().toString().trim(), ns=secret.getText().toString().trim();
                if(nid.isEmpty()||ns.isEmpty()){toast("Client ID と Client Secret を入力してください");return;}
                try {
                    boolean changed=!nid.equals(store.getString("client_id")) || !ns.equals(store.getSecret("client_secret"));
                    DiagnosticLog.log("OAUTH settings save changed="+changed+" clientIdTail="+tail(nid,4)+" secretPresent="+(!ns.isEmpty()));
                    store.putString("client_id",nid); store.putSecret("client_secret",ns);
                    if(changed) { store.clearTokens(); store.clearOAuthPending(); store.remove("oauth_last_error"); }
                    refreshAuthUi(); d.dismiss(); toast("OAuth設定を保存しました");
                } catch(Exception e){error(e);}
            });
        }); d.show();
    }

    private void beginLogin() {
        DiagnosticLog.log("OAUTH begin configured="+isConfigured()+" loggedIn="+isLoggedIn());
        if(!isConfigured()){ DiagnosticLog.log("OAUTH begin blocked: not configured"); oauthSettingsDialog(); return; }
        try {
            if(oauthServer!=null) oauthServer.close();
            String state=randomUrlSafe(32), verifier=randomUrlSafe(64);
            String challenge=Base64.encodeToString(MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII)), Base64.URL_SAFE|Base64.NO_PADDING|Base64.NO_WRAP);
            oauthServer=new OAuthLoopbackServer(RETURN_URI,(code,returnedState,err)->ui.post(()->handleOAuthCallback(code,returnedState,err)));
            String redirect="http://127.0.0.1:"+oauthServer.port()+"/callback";
            DiagnosticLog.log("OAUTH loopback started port="+oauthServer.port()+" returnUri="+RETURN_URI);
            store.putString("oauth_state",state);
            store.putString("oauth_redirect",redirect);
            store.putSecret("oauth_verifier",verifier);
            store.putLong("oauth_started_at",System.currentTimeMillis());
            store.remove("oauth_last_error");
            String url="https://github.com/login/oauth/authorize?client_id="+enc(store.getString("client_id"))+
                    "&redirect_uri="+enc(redirect)+"&scope="+enc("repo workflow offline_access")+
                    "&state="+enc(state)+"&code_challenge="+enc(challenge)+"&code_challenge_method=S256&prompt=select_account";
            refreshAuthUi(); status("GitHub認証待ち…"); DiagnosticLog.log("OAUTH browser launch redirect="+redirect+" stateLen="+state.length()+" verifierLen="+verifier.length()); openUrl(url);
        } catch(Exception e){oauthFailure(e);}
    }

    private void handleOAuthCallback(String code,String state,String err) {
        String expected=store.getString("oauth_state");
        DiagnosticLog.log("OAUTH callback codePresent="+notEmpty(code)+" statePresent="+notEmpty(state)+" errorPresent="+notEmpty(err)+" expectedStatePresent="+notEmpty(expected));
        String redirect=store.getString("oauth_redirect");
        String verifier=store.getSecret("oauth_verifier");
        if(err!=null){oauthFailure(new Exception("OAuth: "+err));return;}
        if(code==null||state==null||!state.equals(expected)){ DiagnosticLog.log("OAUTH state validation failed match="+(state!=null&&state.equals(expected))); oauthFailure(new Exception("OAuth stateが一致しません"));return;}
        if(!notEmpty(redirect)||!notEmpty(verifier)){ DiagnosticLog.log("OAUTH pending session lost redirect="+notEmpty(redirect)+" verifier="+notEmpty(verifier)); oauthFailure(new Exception("OAuthセッション情報が失われました。もう一度ログインしてください"));return;}
        DiagnosticLog.log("OAUTH callback validated redirect="+redirect+" verifierPresent=true");
        status("GitHubログイン処理中…");
        io.execute(()->{ try {
            DiagnosticLog.log("OAUTH token exchange start clientIdTail="+tail(store.getString("client_id"),4));
            GitHubOAuth.TokenResult t=GitHubOAuth.exchange(store.getString("client_id"),store.getSecret("client_secret"),code,redirect,verifier);
            DiagnosticLog.log("OAUTH token exchange success refreshPresent="+notEmpty(t.refreshToken)+" accessExpiresAt="+t.accessExpiresAt);
            GitHubApi a=new GitHubApi(t.accessToken);
            DiagnosticLog.log("OAUTH /user lookup start");
            String login=a.getLogin();
            DiagnosticLog.log("OAUTH /user lookup success login="+login);
            saveTokens(t);
            store.putString("login",login);
            store.clearOAuthPending();
            store.remove("oauth_last_error");
            ui.post(()->{refreshAuthUi();statusSuccess("GitHubログイン完了",false);toast("GitHubにログインしました"); DiagnosticLog.log("OAUTH login completed");});
        } catch(Exception e){ui.post(()->oauthFailure(e));} });
    }

    private void oauthFailure(Exception e) {
        DiagnosticLog.error("OAUTH",e);
        String msg=e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();
        store.clearOAuthPending();
        store.putString("oauth_last_error",msg);
        refreshAuthUi();
        status("OAuthエラー\n"+msg);
    }

    private void logout(){ DiagnosticLog.log("AUTH logout"); store.clearTokens(); store.clearOAuthPending(); store.remove("oauth_last_error"); selectedRepo=null; repoText.setText("未選択"); refreshAuthUi(); status("ログアウトしました"); }

    private void saveTokens(GitHubOAuth.TokenResult t) throws Exception {
        store.putSecret("access_token",t.accessToken); store.putLong("access_expires_at",t.accessExpiresAt);
        store.putSecret("refresh_token",t.refreshToken); store.putLong("refresh_expires_at",t.refreshExpiresAt);
    }

    private GitHubApi api() throws Exception {
        String token=store.getSecret("access_token"); if(!notEmpty(token)) throw new Exception("先に「GitHubでログイン」してください");
        long exp=store.getLong("access_expires_at",0); String refresh=store.getSecret("refresh_token");
        if(exp>0 && System.currentTimeMillis()>exp-300000L && notEmpty(refresh)) {
            DiagnosticLog.log("OAUTH access token refresh start");
            GitHubOAuth.TokenResult t=GitHubOAuth.refresh(store.getString("client_id"),store.getSecret("client_secret"),refresh); saveTokens(t); token=t.accessToken; DiagnosticLog.log("OAUTH access token refresh success");
        }
        return new GitHubApi(token);
    }

    private void loadRepos() {
        if(!isLoggedIn()){toast("先にGitHubへログインしてください");return;}
        DiagnosticLog.log("REPO list start"); status("リポジトリ取得中…"); io.execute(()->{ try { List<GitHubApi.Repo> repos=api().listRepos(); DiagnosticLog.log("REPO list success count="+repos.size()); ui.post(()->showRepoPicker(repos)); } catch(Exception e){ DiagnosticLog.error("REPO list",e); ui.post(()->error(e)); } });
    }
    private void showRepoPicker(List<GitHubApi.Repo> repos) {
        status("待機中"); if(repos.isEmpty()){toast("リポジトリがありません");return;} String[] names=new String[repos.size()]; for(int i=0;i<names.length;i++) names[i]=repos.get(i).fullName;
        new AlertDialog.Builder(this).setTitle("リポジトリ選択").setItems(names,(d,which)->{selectedRepo=repos.get(which); repoText.setText(selectedRepo.fullName); DiagnosticLog.log("REPO selected "+selectedRepo.fullName);}).setNegativeButton("キャンセル",null).show();
    }
    private void createRepoDialog() {
        if(!isLoggedIn()){toast("先にGitHubへログインしてください");return;}
        final boolean makePrivate=privateSwitch!=null && privateSwitch.isChecked();
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(18),dp(2),dp(18),0);
        EditText e=input("repository-name",false); box.addView(e,new LinearLayout.LayoutParams(-1,dp(42)));
        TextView visibility=text(makePrivate?"Privateで作成":"Publicで作成",12,false); visibility.setTextColor(WHITE); visibility.setPadding(0,dp(8),0,0); box.addView(visibility);
        AlertDialog d=new AlertDialog.Builder(this).setTitle("新規リポジトリ").setView(box)
                .setNegativeButton("キャンセル",null).setPositiveButton("作成",null).create();
        d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            String name=e.getText().toString().trim(); if(name.isEmpty()){toast("リポジトリ名を入力してください");return;}
            DiagnosticLog.log("REPO create start name="+name+" private="+makePrivate); status("作成中…"); d.dismiss();
            io.execute(()->{try{GitHubApi.Repo r=api().createRepo(name,makePrivate); ui.post(()->{selectedRepo=r; repoText.setText(r.fullName); status("作成完了"); DiagnosticLog.log("REPO create success "+r.fullName+" private="+makePrivate);});}catch(Exception ex){DiagnosticLog.error("REPO create",ex);ui.post(()->error(ex));}});
        }));
        d.show();
    }

    private void startBuild() {
        if(!isLoggedIn()){toast("先にGitHubへログインしてください");return;}
        if(shared.isEmpty()){toast("ソースZIP と .yml を共有してください");return;}
        if(selectedRepo==null){toast("リポジトリを選択してください");return;}

        final boolean recoverRequested=recoverySwitch!=null && recoverySwitch.isChecked();
        cancelRequested=false; activeRunId=-1L;
        setEmergencyStopActive(true);
        buildButton.setEnabled(false); status("アップロード中…");
        DiagnosticLog.log("BUILD start repo="+selectedRepo.fullName+" files="+shared.size()+" recovery="+recoverRequested);

        io.execute(()->{
            activeBuildThread=Thread.currentThread();
            GitHubApi.CommitResult commitResult=null;
            try {
                checkCancelled();
                GitHubApi a=api();
                commitResult=a.commitFiles(selectedRepo,shared,getContentResolver());
                checkCancelled();
                String sha=commitResult.commitSha;
                DiagnosticLog.log("BUILD commit success sha="+tail(sha,8)+" previous="+tail(commitResult.previousSha,8));
                postStatus("コミット完了 / Actions待機中…");

                GitHubApi.Run run=null;
                for(int i=0;i<40&&run==null;i++){
                    checkCancelled();
                    if(i>0)sleepCancelable(3000);
                    checkCancelled();
                    run=a.findRun(selectedRepo.fullName,sha);
                }
                if(run==null) throw new Exception("このコミットから起動したActionsが見つかりません。workflowの on: push を確認してください");

                long id=run.id; activeRunId=id;
                DiagnosticLog.log("BUILD actions run found id="+id+" status="+run.status);
                while(!"completed".equals(run.status)){
                    checkCancelled();
                    DiagnosticLog.log("BUILD actions status id="+id+" status="+run.status);
                    postStatus("Actions: "+run.status+"  #"+id);
                    sleepCancelable(5000);
                    checkCancelled();
                    a=api();
                    run=a.getRun(selectedRepo.fullName,id);
                }
                checkCancelled();
                DiagnosticLog.log("BUILD actions completed id="+id+" conclusion="+run.conclusion);
                if(!"success".equals(run.conclusion)) throw new Exception("Actions終了: "+run.conclusion+"  (#"+id+")");

                postStatus("ビルド成功 / APK取得中…");
                checkCancelled();
                List<GitHubApi.Artifact> arts=a.artifacts(selectedRepo.fullName,id);
                if(arts.isEmpty()) throw new Exception("Artifactがありません");
                GitHubApi.Artifact chosen=arts.get(0);
                for(GitHubApi.Artifact x:arts) if(x.name.toLowerCase().contains("apk")){chosen=x;break;}
                DiagnosticLog.log("BUILD artifact selected id="+chosen.id+" name="+chosen.name);
                byte[] zip=a.downloadArtifact(selectedRepo.fullName,chosen.id);
                checkCancelled();
                DiagnosticLog.log("BUILD artifact downloaded bytes="+zip.length);
                List<SavedApk> saved=saveApks(zip);
                checkCancelled();
                if(saved.isEmpty()) throw new Exception("Artifact内に.apkがありません");

                String recoveryNote="";
                if(recoverRequested){
                    postStatus("APK保存完了 / 前の状態へリカバリー中…");
                    try{
                        a=api();
                        boolean restored=a.recoverPreviousState(selectedRepo,commitResult);
                        if(restored){
                            recoveryNote="\nリポジトリ: 前の状態へリカバリー済み";
                            DiagnosticLog.log("BUILD recovery completed");
                        }else{
                            recoveryNote="\nリポジトリ: リカバリー保留（HEAD変更を検出）";
                            DiagnosticLog.log("BUILD recovery skipped because branch head changed");
                        }
                    }catch(Exception re){
                        DiagnosticLog.error("BUILD recovery",re);
                        recoveryNote="\nリポジトリ: リカバリー失敗 - "+(re.getMessage()==null?re.getClass().getSimpleName():re.getMessage());
                    }
                }

                List<String> savedNames=new ArrayList<>();
                for(SavedApk aapk:saved)savedNames.add(aapk.name);
                String names=String.join(", ",savedNames);
                SavedApk primary=saved.get(0);
                String finalRecoveryNote=recoveryNote;
                DiagnosticLog.log("BUILD complete apk="+names+" recovery="+recoverRequested);
                ui.post(()->{
                    lastApkUri=primary.uri;
                    lastApkName=primary.name;
                    statusSuccess("完了\nDownload: "+names+finalRecoveryNote,true);
                    buildButton.setEnabled(true);
                    setEmergencyStopActive(false);
                });
            } catch(Exception e){
                boolean cancelled=cancelRequested || e instanceof InterruptedException || e instanceof BuildCancelledException;
                String recoveryNote="";
                if(recoverRequested && commitResult!=null){
                    try{
                        postStatus("エラー / 前の状態へリカバリー中…");
                        boolean restored=api().recoverPreviousState(selectedRepo,commitResult);
                        recoveryNote=restored?"\n前の状態へリカバリー済み":"\nリカバリー保留（HEAD変更を検出）";
                        DiagnosticLog.log("BUILD recovery after error restored="+restored);
                    }catch(Exception re){
                        DiagnosticLog.error("BUILD recovery after error",re);
                        recoveryNote="\nリカバリー失敗: "+(re.getMessage()==null?re.getClass().getSimpleName():re.getMessage());
                    }
                }
                String original=e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();
                String finalRecoveryNote=recoveryNote;
                if(cancelled) DiagnosticLog.log("BUILD emergency stop completed recovery="+recoverRequested+" note="+finalRecoveryNote.replace('\n',' '));
                else DiagnosticLog.error("BUILD",e);
                ui.post(()->{
                    buildButton.setEnabled(true);
                    setEmergencyStopActive(false);
                    if(cancelled){
                        if(finalRecoveryNote.contains("リカバリー済み")) status("停止・リカバリー完了");
                        else status("停止しました"+finalRecoveryNote);
                    } else status("エラー\n"+original+finalRecoveryNote);
                });
            } finally {
                activeRunId=-1L;
                activeBuildThread=null;
                cancelRequested=false;
            }
        });
    }

    private static final class BuildCancelledException extends Exception {
        BuildCancelledException(){ super("緊急停止"); }
    }

    private void checkCancelled() throws BuildCancelledException {
        if(cancelRequested) throw new BuildCancelledException();
    }

    private void sleepCancelable(long millis) throws Exception {
        try { Thread.sleep(millis); }
        catch(InterruptedException e){
            if(cancelRequested) throw new BuildCancelledException();
            Thread.currentThread().interrupt();
            throw e;
        }
    }

    private void setEmergencyStopActive(boolean active) {
        if(emergencyStopButton==null) return;
        emergencyStopButton.setEnabled(active);
        emergencyStopButton.setBackground(round(active?RED:DGRAY,10));
    }

    private void requestEmergencyStop() {
        if(emergencyStopButton==null || !emergencyStopButton.isEnabled()) return;
        if(cancelRequested) return;
        cancelRequested=true;
        status("停止中…");
        DiagnosticLog.log("BUILD emergency stop requested runId="+activeRunId);
        setEmergencyStopActive(false);
        Thread t=activeBuildThread;
        if(t!=null) t.interrupt();
        final long runId=activeRunId;
        final GitHubApi.Repo repo=selectedRepo;
        if(runId>0 && repo!=null){
            controlIo.execute(()->{
                try {
                    api().cancelRun(repo.fullName,runId);
                    DiagnosticLog.log("BUILD actions cancel requested id="+runId);
                } catch(Exception e) {
                    DiagnosticLog.error("BUILD actions cancel",e);
                }
            });
        }
    }

    private List<SavedApk> saveApks(byte[] zipBytes) throws Exception {
        List<SavedApk> saved=new ArrayList<>();
        try(ZipInputStream zin=new ZipInputStream(new ByteArrayInputStream(zipBytes))) {
            ZipEntry z; byte[] buf=new byte[32768];
            while((z=zin.getNextEntry())!=null){
                if(z.isDirectory()||!z.getName().toLowerCase().endsWith(".apk")){ zin.closeEntry(); continue; }
                String name=z.getName(); int slash=name.lastIndexOf('/'); if(slash>=0)name=name.substring(slash+1);
                long declaredSize=z.getSize(), declaredCrc=z.getCrc();
                ByteArrayOutputStream apkOut=new ByteArrayOutputStream(declaredSize>0&&declaredSize<Integer.MAX_VALUE?(int)declaredSize:1024*1024);
                CRC32 extractedCrc=new CRC32(); long extractedSize=0; int n;
                while((n=zin.read(buf))!=-1){ if(n==0)continue; apkOut.write(buf,0,n); extractedCrc.update(buf,0,n); extractedSize+=n; }
                zin.closeEntry();
                long crc=extractedCrc.getValue();
                DiagnosticLog.log("APK extract entry="+name+" bytes="+extractedSize+" declared="+declaredSize+" crc="+Long.toHexString(crc));
                if(declaredSize>=0&&declaredSize!=extractedSize) throw new Exception("APK展開サイズ不一致: "+name+" expected="+declaredSize+" actual="+extractedSize);
                if(declaredCrc>=0&&declaredCrc!=crc) throw new Exception("APK展開CRC不一致: "+name);
                byte[] apkBytes=apkOut.toByteArray();
                validateApkArchive(name,apkBytes);
                saved.add(saveVerifiedApk(name,apkBytes,crc));
            }
        }
        return saved;
    }

    private void validateApkArchive(String name, byte[] apkBytes) throws Exception {
        boolean manifest=false; int entries=0; byte[] buf=new byte[32768];
        try(ZipInputStream apk=new ZipInputStream(new ByteArrayInputStream(apkBytes))){
            ZipEntry e; while((e=apk.getNextEntry())!=null){
                if(!e.isDirectory()){ entries++; if("AndroidManifest.xml".equals(e.getName()))manifest=true; int n; while((n=apk.read(buf))!=-1){ /* force CRC validation */ } }
                apk.closeEntry();
            }
        }
        if(!manifest) throw new Exception("APK検証失敗: AndroidManifest.xmlがありません: "+name);
        DiagnosticLog.log("APK archive verified name="+name+" entries="+entries+" bytes="+apkBytes.length);
    }

    private SavedApk saveVerifiedApk(String requestedName, byte[] apkBytes, long expectedCrc) throws Exception {
        ContentResolver resolver=getContentResolver(); Uri u=null;
        try{
            ContentValues v=new ContentValues();
            v.put(MediaStore.Downloads.DISPLAY_NAME,requestedName);
            v.put(MediaStore.Downloads.MIME_TYPE,"application/vnd.android.package-archive");
            v.put(MediaStore.Downloads.RELATIVE_PATH,"Download");
            v.put(MediaStore.Downloads.IS_PENDING,1);
            u=resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
            if(u==null)throw new Exception("Downloadへ保存できません");
            try(OutputStream out=resolver.openOutputStream(u,"w")){
                if(out==null)throw new Exception("Downloadの出力ストリームを開けません");
                int off=0; while(off<apkBytes.length){ int len=Math.min(32768,apkBytes.length-off); out.write(apkBytes,off,len); off+=len; }
                out.flush();
            }
            long[] verify=readBackStats(u);
            DiagnosticLog.log("APK readback uri="+u+" sourceBytes="+apkBytes.length+" targetBytes="+verify[0]+" sourceCrc="+Long.toHexString(expectedCrc)+" targetCrc="+Long.toHexString(verify[1]));
            if(verify[0]!=apkBytes.length) throw new Exception("APK保存サイズ不一致: source="+apkBytes.length+", target="+verify[0]);
            if(verify[1]!=expectedCrc) throw new Exception("APK保存CRC不一致: "+requestedName);
            ContentValues done=new ContentValues(); done.put(MediaStore.Downloads.IS_PENDING,0); resolver.update(u,done,null,null);
            String actualName=queryDisplayName(u,requestedName);
            DiagnosticLog.log("APK saved verified Download/"+actualName+" bytes="+verify[0]+" uri="+u);
            return new SavedApk(actualName,u);
        }catch(Exception e){
            if(u!=null){ try{resolver.delete(u,null,null);}catch(Exception ignored){} }
            DiagnosticLog.error("APK save verify",e);
            throw e;
        }
    }

    private long[] readBackStats(Uri u) throws Exception {
        CRC32 crc=new CRC32(); long count=0; byte[] buf=new byte[32768];
        try(InputStream in=getContentResolver().openInputStream(u)){
            if(in==null)throw new Exception("保存APKを再読込できません");
            int n; while((n=in.read(buf))!=-1){ if(n==0)continue; crc.update(buf,0,n); count+=n; }
        }
        return new long[]{count,crc.getValue()};
    }

    private String queryDisplayName(Uri u,String fallback){
        try(Cursor c=getContentResolver().query(u,new String[]{MediaStore.Downloads.DISPLAY_NAME},null,null,null)){
            if(c!=null&&c.moveToFirst()){ int i=c.getColumnIndex(MediaStore.Downloads.DISPLAY_NAME); if(i>=0){String s=c.getString(i);if(s!=null&&!s.isEmpty())return s;} }
        }catch(Exception ignored){}
        return fallback;
    }

    private void runLastApk(){
        if(lastApkUri==null){toast("実行できるAPKがありません");return;}
        try{
            DiagnosticLog.log("APK run requested name="+lastApkName+" uri="+lastApkUri);
            Intent i=new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(lastApkUri,"application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        }catch(Exception e){DiagnosticLog.error("APK run",e);error(e);}
    }

    private void showUsage(){
        final Dialog d=new Dialog(this);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(18),dp(18),dp(18),dp(18)); box.setBackgroundColor(BG);
        TextView title=text("使用方法",20,true); box.addView(title,new LinearLayout.LayoutParams(-1,dp(42)));
        String guide=
                "基本の使い方\n\n"+
                "1. source用ZIPとGitHub Actionsの .yml / .yaml をGitBuildへ共有します。ZIPの元ファイル名は自由です。GitHubへ送る際は自動で source.zip に統一します。\n\n"+
                "2. 「リポジトリ」欄をタップして既存リポジトリを選ぶか、「新規作成」から作成します。Public / Privateトグルは初期値Publicで、ON時だけPrivateです。\n\n"+
                "3. 「前の状態にリカバリー」は緊急停止ボタンの下にあり、初期値はONです。ビルド後、GitBuildが投入する直前と同じリポジトリ内容へ自動で戻します。途中で別の更新を検出した場合は上書きしません。\n\n"+
                "4. 「アップロード＆ビルド」を押すと、workflowを .github/workflows/ に配置し、Actionsの完了まで監視します。\n\n"+
                "5. 成功するとArtifact内のAPKを検証してDownloadへ保存します。ビルド状態欄の「実行」から、そのAPKを開けます。\n\n"+
                "GitHub OAuth Appの作成\n\n"+
                "1. GitHubを開き、Settings → Developer settings → OAuth Apps → New OAuth App へ進みます。\n\n"+
                "2. Application name: GitBuild\n"+
                "   Homepage URL: https://github.com\n"+
                "   Redirect URI: "+CALLBACK_BASE+"\n"+
                "   Wildcard matching: OFF\n"+
                "   Device Flow: OFF\n\n"+
                "3. Register application後に表示されるClient IDをコピーします。\n\n"+
                "4. Generate a new client secretでClient Secretを生成します。Secretはパスワードと同様の秘密情報です。スクリーンショットや共有をせず、GitBuildへ直接貼り付けてください。\n\n"+
                "5. GitBuildの「OAuth設定」にClient ID / Client Secretを保存し、「GitHubでログイン」から認証します。GitHubのログイン名・パスワードをGitBuildへ入力する必要はありません。";
        TextView body=text(guide,14,false); body.setGravity(Gravity.TOP|Gravity.START); body.setLineSpacing(0,1.08f); body.setTextIsSelectable(true);
        ScrollView scroll=new ScrollView(this); scroll.addView(body,new ScrollView.LayoutParams(-1,-2)); box.addView(scroll,new LinearLayout.LayoutParams(-1,0,1f));
        box.addView(space(12));
        LinearLayout buttons=row(); Button open=button("OAuth Appsを開く",ORANGE), close=button("閉じる",DGRAY);
        buttons.addView(open,new LinearLayout.LayoutParams(0,dp(44),1f)); buttons.addView(gap()); buttons.addView(close,new LinearLayout.LayoutParams(dp(88),dp(44))); box.addView(buttons);
        open.setOnClickListener(v->openUrl("https://github.com/settings/developers")); close.setOnClickListener(v->d.dismiss());
        d.setContentView(box); d.show(); Window w=d.getWindow(); if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.setLayout((int)(getResources().getDisplayMetrics().widthPixels*0.94f),(int)(getResources().getDisplayMetrics().heightPixels*0.84f));}
    }

    private void openUrl(String url){
        try{
            Uri u=Uri.parse(url); DiagnosticLog.log("OPEN_URL host="+u.getHost()+" path="+u.getPath());
            startActivity(new Intent(Intent.ACTION_VIEW,u));
        }catch(Exception e){DiagnosticLog.error("OPEN_URL",e);error(e);}
    }

    private void showDiagnosticLog() {
        final Dialog d=new Dialog(this);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(18),dp(18),dp(18),dp(18)); box.setBackgroundColor(BG);
        TextView title=text("診断ログ",20,true); box.addView(title,new LinearLayout.LayoutParams(-1,dp(42)));
        TextView body=text(DiagnosticLog.report(this),12,false); body.setTextIsSelectable(true); body.setTypeface(android.graphics.Typeface.MONOSPACE); body.setGravity(Gravity.TOP|Gravity.START); body.setPadding(dp(12),dp(12),dp(12),dp(12)); body.setBackground(round(DGRAY,8));
        ScrollView scroll=new ScrollView(this); scroll.addView(body,new ScrollView.LayoutParams(-1,-2)); box.addView(scroll,new LinearLayout.LayoutParams(-1,0,1f));
        box.addView(space(12));
        LinearLayout buttons=row(); Button clear=button("ログ消去", Color.rgb(68,17,0)); buttons.addView(clear,new LinearLayout.LayoutParams(dp(80),dp(44)));
        Space stretch=new Space(this); buttons.addView(stretch,new LinearLayout.LayoutParams(0,1,1f));
        Button share=button(".txtを共有", LBLUE), copy=button("コピー", GRAY), close=button("閉じる", DGRAY);
        buttons.addView(share,new LinearLayout.LayoutParams(dp(92),dp(44))); buttons.addView(gap()); buttons.addView(copy,new LinearLayout.LayoutParams(dp(64),dp(44))); buttons.addView(gap()); buttons.addView(close,new LinearLayout.LayoutParams(dp(64),dp(44))); box.addView(buttons,new LinearLayout.LayoutParams(-1,dp(44)));
        clear.setOnClickListener(v->{ DiagnosticLog.clear(); DiagnosticLog.log("LOG cleared by user"); body.setText(DiagnosticLog.report(this)); });
        copy.setOnClickListener(v->{ ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE); cm.setPrimaryClip(ClipData.newPlainText("GitBuild diagnostic",DiagnosticLog.report(this))); toast("診断ログをコピーしました"); DiagnosticLog.log("LOG copied"); });
        share.setOnClickListener(v->shareDiagnosticLog()); close.setOnClickListener(v->d.dismiss());
        d.setContentView(box); Window w=d.getWindow(); if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent); w.setLayout((int)(getResources().getDisplayMetrics().widthPixels*0.96f),(int)(getResources().getDisplayMetrics().heightPixels*0.88f));} d.show(); if(d.getWindow()!=null)d.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels*0.96f),(int)(getResources().getDisplayMetrics().heightPixels*0.88f));
    }

    private void shareDiagnosticLog() {
        try {
            DiagnosticLog.log("LOG share requested");
            Uri u=Uri.parse("content://com.cmyk.gitbuild.diag/GitBuild_diagnostic.txt");
            Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_STREAM,u); i.putExtra(Intent.EXTRA_SUBJECT,"GitBuild diagnostic report"); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i,"診断ログを共有"));
        } catch(Exception e){ DiagnosticLog.error("LOG share",e); error(e); }
    }

    private static String safeIntentData(Intent i){
        if(i==null||i.getData()==null)return "null"; Uri u=i.getData(); return u.getScheme()+"://"+u.getHost()+u.getPath();
    }
    private static String tail(String s,int n){ if(s==null)return "null"; return s.length()<=n?s:s.substring(s.length()-n); }
    private static String randomUrlSafe(int bytes){byte[] b=new byte[bytes];new SecureRandom().nextBytes(b);return Base64.encodeToString(b,Base64.URL_SAFE|Base64.NO_PADDING|Base64.NO_WRAP);}
    private static String enc(String s) throws Exception{return URLEncoder.encode(s,"UTF-8").replace("+","%20");}
    private static boolean notEmpty(String s){return s!=null&&!s.isEmpty();}
    private void postStatus(String s){ui.post(()->status(s));}
    private void status(String s){
        if(statusText!=null)statusText.setText(s);
        if(statusCheck!=null)statusCheck.setVisibility(View.GONE);
        if(runApkButton!=null)runApkButton.setVisibility(View.GONE);
    }
    private void statusSuccess(String s, boolean allowRun){
        if(statusText!=null)statusText.setText(s);
        if(statusCheck!=null)statusCheck.setVisibility(View.VISIBLE);
        if(runApkButton!=null)runApkButton.setVisibility(allowRun&&lastApkUri!=null?View.VISIBLE:View.GONE);
    }
    private void error(Exception e){DiagnosticLog.error("UI",e); status("エラー\n"+(e.getMessage()==null?e.getClass().getSimpleName():e.getMessage()));}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    private TextView text(String s,int sp,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextColor(TEXT);v.setTextSize(sp);if(bold)v.setTypeface(null,1);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    private TextView label(String s){TextView v=text(s,12,false);v.setTextColor(WHITE);v.setPadding(0,0,0,dp(6));return v;}
    private EditText input(String hint,boolean password){EditText e=new EditText(this);e.setHint(hint);e.setTextColor(TEXT);e.setHintTextColor(WHITE);e.setSingleLine(true);e.setPadding(dp(12),0,dp(12),0);e.setBackground(round(GRAY,8));if(password)e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);return e;}
    private View card(TextView content){ return cardView(content); }
    private View cardView(View content){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(14),dp(12),dp(14),dp(12));l.setBackground(round(GRAY,10));l.addView(content,new LinearLayout.LayoutParams(-1,-2));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(8));l.setLayoutParams(p);return l;}
    private TextView menuIcon(){TextView v=text("⋮",22,false);v.setTextColor(WHITE);v.setGravity(Gravity.CENTER);GradientDrawable g=new GradientDrawable();g.setColor(DGRAY);g.setShape(GradientDrawable.OVAL);v.setBackground(g);v.setClickable(true);v.setFocusable(true);return v;}
    private Button button(String s,int color){Button b=new Button(this);b.setText(s);b.setTextColor(TEXT);b.setTextSize(14);b.setAllCaps(false);b.setPadding(dp(8),0,dp(8),0);b.setBackground(round(color,10));return b;}
    private GradientDrawable round(int c,int r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));return g;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);return l;} private LinearLayout.LayoutParams weight(){return new LinearLayout.LayoutParams(0,dp(44),1f);} private View gap(){return hGap(8);} private View hGap(int w){Space s=new Space(this);s.setLayoutParams(new LinearLayout.LayoutParams(dp(w),1));return s;} private View space(int h){Space s=new Space(this);s.setLayoutParams(new LinearLayout.LayoutParams(1,dp(h)));return s;}
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);} private static String human(long b){if(b<1024)return b+" B";if(b<1024*1024)return String.format(Locale.US,"%.1f KB",b/1024f);return String.format(Locale.US,"%.1f MB",b/1048576f);}
}
