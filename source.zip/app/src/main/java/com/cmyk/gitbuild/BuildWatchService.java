package com.cmyk.gitbuild;

import android.app.*;
import android.content.*;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Keeps Actions monitoring alive if the Activity is backgrounded or destroyed. */
public final class BuildWatchService extends Service {
    public static final String ACTION_HOLD="com.cmyk.gitbuild.HOLD_BUILD";
    public static final String ACTION_WATCH="com.cmyk.gitbuild.WATCH_RUN";
    public static final String ACTION_STOP="com.cmyk.gitbuild.STOP_WATCH";
    public static final String EXTRA_REPO="repo";
    public static final String EXTRA_RUN="run";
    private static final String CHANNEL="gitbuild_builds";
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private volatile long watchingRun=-1L;
    private volatile boolean stopping;

    @Override public void onCreate(){ super.onCreate(); DiagnosticLog.init(this); ensureChannel(); }

    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent==null)return START_NOT_STICKY;
        if(ACTION_STOP.equals(intent.getAction())){ stopping=true; stopSelf(); return START_NOT_STICKY; }
        String repo=intent.getStringExtra(EXTRA_REPO); long run=intent.getLongExtra(EXTRA_RUN,-1L);
        if(ACTION_HOLD.equals(intent.getAction()) && repo!=null){ startForeground(7001,monitoringNotification(repo,-1L)); DiagnosticLog.log("WATCH service hold repo="+repo); return START_STICKY; }
        if(!ACTION_WATCH.equals(intent.getAction())||repo==null||run<=0)return START_NOT_STICKY;
        startForeground(7001,monitoringNotification(repo,run));
        if(watchingRun==run)return START_STICKY;
        watchingRun=run; stopping=false;
        DiagnosticLog.log("WATCH service start repo="+repo+" run="+run);
        io.execute(()->watch(repo,run));
        return START_STICKY;
    }

    private void watch(String repo,long run){
        try{
            GitHubApi a=api();
            GitHubApi.Run state=a.getRun(repo,run);
            while(!stopping && !"completed".equals(state.status)){
                Thread.sleep(5000L); if(stopping)return; a=api(); state=a.getRun(repo,run);
            }
            if(stopping)return;
            state=a.settleCompletedRun(repo,run,state);
            if(stopping)return;
            if("success".equals(state.conclusion)){
                Uri apk=null; String apkName=null;
                for(int i=0;i<3 && apk==null && !stopping;i++){
                    HistoryApk h=findHistoryApk(run); if(h!=null){apk=h.uri;apkName=h.name;break;}
                    Thread.sleep(4000L);
                }
                if(apk==null&&!stopping){
                    Saved saved=downloadAndSaveApk(repo,run,a); if(saved!=null){apk=saved.uri;apkName=saved.name; recordHistory(repo,run,saved);}
                }
                if(apk!=null) notifySuccess(repo,run,apkName,apk); else notifySimple("GitBuild ビルド完了","Run #"+run+" は成功しました。GitBuildを開いてArtifactを取得してください",run);
            }else if(GitHubApi.isExplicitFailureConclusion(state.conclusion)){
                notifySimple("GitBuild ビルド失敗",repo+"  #"+run+"  "+state.conclusion,run);
            }else{
                String unresolved=state.conclusion==null||state.conclusion.trim().isEmpty()?"未確定":state.conclusion;
                DiagnosticLog.log("WATCH result unresolved run="+run+" conclusion="+unresolved+"; failure notification suppressed");
                notifySimple("GitBuild 監視エラー","Run #"+run+" のActions結果を確定できません: "+unresolved,run);
            }
        }catch(InterruptedException ignored){ Thread.currentThread().interrupt(); }
        catch(Exception e){ DiagnosticLog.error("WATCH service",e); if(!stopping)notifySimple("GitBuild 監視エラー",e.getMessage()==null?e.getClass().getSimpleName():e.getMessage(),run); }
        finally{ if(!stopping){watchingRun=-1L;stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();} }
    }

    private GitHubApi api() throws Exception{
        SecureStore store=new SecureStore(this); String token=store.getSecret("access_token"); if(token==null||token.isEmpty())throw new Exception("GitHubログイン情報がありません");
        long exp=store.getLong("access_expires_at",0L); String refresh=store.getSecret("refresh_token");
        if(exp>0&&System.currentTimeMillis()>exp-300000L&&refresh!=null&&!refresh.isEmpty()){
            GitHubOAuth.TokenResult t=GitHubOAuth.refresh(store.getString("client_id"),store.getSecret("client_secret"),refresh);
            store.putSecret("access_token",t.accessToken); store.putLong("access_expires_at",t.accessExpiresAt); store.putSecret("refresh_token",t.refreshToken); store.putLong("refresh_expires_at",t.refreshExpiresAt); token=t.accessToken;
        }
        return new GitHubApi(token);
    }

    private static final class HistoryApk{final Uri uri;final String name;HistoryApk(Uri u,String n){uri=u;name=n;}}
    private HistoryApk findHistoryApk(long run){
        try{
            JSONArray a=new JSONArray(getSharedPreferences("build_history",MODE_PRIVATE).getString("entries","[]"));
            for(int i=0;i<a.length();i++){JSONObject e=a.optJSONObject(i);if(e==null||e.optLong("run",-1L)!=run||!e.optBoolean("success",false))continue;String u=e.optString("apkUri","");String n=e.optString("apk","");if(!u.isEmpty())return new HistoryApk(Uri.parse(u),n);}
        }catch(Exception ignored){}
        return null;
    }

    private static final class Saved{final String name,app,version;final Uri uri;Saved(String n,String a,String v,Uri u){name=n;app=a;version=v;uri=u;}}
    private Saved downloadAndSaveApk(String repo,long run,GitHubApi a) throws Exception{
        List<GitHubApi.Artifact> arts=a.artifacts(repo,run); if(arts.isEmpty())return null;
        List<GitHubApi.Artifact> candidates=new ArrayList<>(arts);
        candidates.sort((x,y)->Integer.compare(apkArtifactPriority(x),apkArtifactPriority(y)));
        Exception lastError=null;
        for(GitHubApi.Artifact candidate:candidates){
            try{
                DiagnosticLog.log("WATCH artifact candidate id="+candidate.id+" name="+candidate.name+" priority="+apkArtifactPriority(candidate));
                byte[] artifact=a.downloadArtifact(repo,candidate.id); byte[] apk=null; String name=null; long crc=-1L;
                try(ZipInputStream zin=new ZipInputStream(new ByteArrayInputStream(artifact))){ZipEntry z;byte[] buf=new byte[32768];while((z=zin.getNextEntry())!=null){if(z.isDirectory()||!z.getName().toLowerCase(Locale.ROOT).endsWith(".apk")){zin.closeEntry();continue;}name=z.getName();int slash=name.lastIndexOf('/');if(slash>=0)name=name.substring(slash+1);ByteArrayOutputStream out=new ByteArrayOutputStream();CRC32 c=new CRC32();int n;while((n=zin.read(buf))!=-1){if(n>0){out.write(buf,0,n);c.update(buf,0,n);}}apk=out.toByteArray();crc=c.getValue();break;}}
                if(apk==null){DiagnosticLog.log("WATCH artifact skipped no apk id="+candidate.id+" name="+candidate.name);continue;}
                Identity id=inspectIdentity(apk); Uri uri=saveApk(name,apk,crc); String actual=queryName(uri,name); return new Saved(actual,id.app,id.version,uri);
            }catch(Exception e){lastError=e;DiagnosticLog.error("WATCH artifact candidate "+candidate.name,e);}
        }
        if(lastError!=null)throw lastError;
        return null;
    }

    private static int apkArtifactPriority(GitHubApi.Artifact artifact){
        if(artifact==null)return 9;
        String name=artifact.name==null?"":artifact.name.toLowerCase(Locale.ROOT);
        if(name.contains("apk"))return 0;
        if(name.equals("source")||name.equals("source.zip")||name.contains("source"))return 2;
        return 1;
    }

    private static final class Identity{final String app,version;Identity(String a,String v){app=a;version=v;}}
    private Identity inspectIdentity(byte[] bytes) throws Exception{
        File tmp=File.createTempFile("gitbuild_watch_",".apk",getCacheDir());
        try{try(FileOutputStream out=new FileOutputStream(tmp)){out.write(bytes);}PackageManager pm=getPackageManager();PackageInfo info=pm.getPackageArchiveInfo(tmp.getAbsolutePath(),PackageManager.GET_META_DATA);if(info==null)return new Identity("App","unknown");String app=info.packageName,ver=info.versionName;try{ApplicationInfo ai=info.applicationInfo;if(ai!=null){ai.sourceDir=tmp.getAbsolutePath();ai.publicSourceDir=tmp.getAbsolutePath();CharSequence l=pm.getApplicationLabel(ai);if(l!=null&&!l.toString().trim().isEmpty())app=l.toString().trim();}}catch(Exception ignored){}return new Identity(app,ver);}finally{tmp.delete();}
    }

    private Uri saveApk(String name,byte[] bytes,long expectedCrc) throws Exception{
        ContentValues v=new ContentValues();v.put(MediaStore.Downloads.DISPLAY_NAME,name);v.put(MediaStore.Downloads.MIME_TYPE,"application/vnd.android.package-archive");v.put(MediaStore.Downloads.RELATIVE_PATH,"Download");v.put(MediaStore.Downloads.IS_PENDING,1);Uri u=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(u==null)throw new Exception("APK保存失敗");
        try{try(OutputStream out=getContentResolver().openOutputStream(u,"w")){if(out==null)throw new Exception("APK出力失敗");out.write(bytes);out.flush();}CRC32 c=new CRC32();long count=0;byte[] b=new byte[32768];try(InputStream in=getContentResolver().openInputStream(u)){int n;while((n=in.read(b))!=-1){if(n>0){c.update(b,0,n);count+=n;}}}if(count!=bytes.length||c.getValue()!=expectedCrc)throw new Exception("APK保存検証失敗");ContentValues done=new ContentValues();done.put(MediaStore.Downloads.IS_PENDING,0);getContentResolver().update(u,done,null,null);return u;}catch(Exception e){try{getContentResolver().delete(u,null,null);}catch(Exception ignored){}throw e;}
    }

    private String queryName(Uri u,String fallback){try(Cursor c=getContentResolver().query(u,new String[]{MediaStore.Downloads.DISPLAY_NAME},null,null,null)){if(c!=null&&c.moveToFirst()){String n=c.getString(0);if(n!=null&&!n.isEmpty())return n;}}catch(Exception ignored){}return fallback;}

    private void recordHistory(String repo,long run,Saved s){
        try{android.content.SharedPreferences pref=getSharedPreferences("build_history",MODE_PRIVATE);JSONArray old;try{old=new JSONArray(pref.getString("entries","[]"));}catch(Exception e){old=new JSONArray();}JSONObject n=new JSONObject();n.put("time",System.currentTimeMillis()).put("success",true).put("app",s.app).put("version",s.version).put("repo",repo).put("run",run).put("apk",s.name).put("apkUri",s.uri.toString()).put("source",JSONObject.NULL).put("error",JSONObject.NULL);JSONArray out=new JSONArray();out.put(n);for(int i=0;i<old.length()&&i<29;i++)out.put(old.get(i));pref.edit().putString("entries",out.toString()).apply();}catch(Exception e){DiagnosticLog.error("WATCH history",e);}
    }

    private Notification monitoringNotification(String repo,long run){
        Intent open=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,7001,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);String detail=run>0?repo+"  #"+run:repo+"  ビルド準備中";return b.setSmallIcon(android.R.drawable.stat_sys_download).setContentTitle("GitBuild ビルド監視中").setContentText(detail).setOngoing(true).setContentIntent(pi).build();
    }

    private void notifySuccess(String repo,long run,String apkName,Uri apk){
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);if(nm==null)return;Intent install=new Intent(Intent.ACTION_VIEW);install.setDataAndType(apk,"application/vnd.android.package-archive");install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);PendingIntent pi=PendingIntent.getActivity(this,(int)(run&0x7fffffff),install,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);b.setSmallIcon(android.R.drawable.stat_sys_download_done).setContentTitle("GitBuild ビルド完了").setContentText(apkName).setAutoCancel(true).setContentIntent(pi).addAction(android.R.drawable.ic_menu_view,"インストール",pi);nm.notify((int)(run&0x7fffffff),b.build());
    }

    private void notifySimple(String title,String text,long run){NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);if(nm==null)return;Intent open=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,(int)((run>0?run:System.currentTimeMillis())&0x7fffffff),open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);b.setSmallIcon(android.R.drawable.stat_notify_error).setContentTitle(title).setContentText(text).setStyle(new Notification.BigTextStyle().bigText(text)).setAutoCancel(true).setContentIntent(pi);nm.notify((int)((run>0?run:System.currentTimeMillis())&0x7fffffff),b.build());}

    private void ensureChannel(){if(Build.VERSION.SDK_INT<26)return;NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);if(nm!=null)nm.createNotificationChannel(new NotificationChannel(CHANNEL,"GitBuild ビルド",NotificationManager.IMPORTANCE_DEFAULT));}

    @Override public void onDestroy(){stopping=true;io.shutdownNow();super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent intent){return null;}
}
