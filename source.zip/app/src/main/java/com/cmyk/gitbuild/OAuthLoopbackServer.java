package com.cmyk.gitbuild;

import android.net.Uri;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

public final class OAuthLoopbackServer implements AutoCloseable {
    public interface Callback { void onResult(String code, String state, String error); }
    private final ServerSocket server;
    private final Thread thread;
    private final Callback callback;
    private volatile boolean closed;

    public OAuthLoopbackServer(Callback callback) throws Exception {
        this.callback = callback;
        server = new ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"));
        thread = new Thread(this::run, "GitBuild-OAuth");
        thread.setDaemon(true);
        thread.start();
    }

    public int port() { return server.getLocalPort(); }

    private void run() {
        try (Socket s = server.accept()) {
            BufferedReader r = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
            String first = r.readLine();
            String code = null, state = null, error = null;
            if (first != null && first.startsWith("GET ")) {
                int sp = first.indexOf(' ', 4);
                String target = sp > 4 ? first.substring(4, sp) : "/";
                Uri u = Uri.parse("http://127.0.0.1" + target);
                code = u.getQueryParameter("code");
                state = u.getQueryParameter("state");
                error = u.getQueryParameter("error");
                if (error == null) error = u.getQueryParameter("error_description");
            } else error = "Invalid OAuth callback";
            String html = "<!doctype html><meta charset='utf-8'><meta name='viewport' content='width=device-width'><title>GitBuild</title>" +
                    "<body style='background:#303030;color:#fff;font-family:sans-serif;padding:28px'>" +
                    "<h2>GitBuild</h2><p>GitHub認証を受け取りました。</p><p>このタブを閉じてGitBuildに戻ってください。</p></body>";
            byte[] b = html.getBytes(StandardCharsets.UTF_8);
            String h = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: " + b.length + "\r\nConnection: close\r\n\r\n";
            OutputStream out = s.getOutputStream();
            out.write(h.getBytes(StandardCharsets.US_ASCII)); out.write(b); out.flush();
            callback.onResult(code, state, error);
        } catch (Exception e) {
            if (!closed) callback.onResult(null, null, e.getMessage());
        } finally { try { server.close(); } catch (Exception ignored) {} }
    }

    @Override public void close() {
        closed = true;
        try { server.close(); } catch (Exception ignored) {}
    }
}
