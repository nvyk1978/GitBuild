package com.cmyk.gitbuild;

import android.net.Uri;

public final class SharedItem {
    public final Uri uri;
    public final String name;
    public final long size;

    public SharedItem(Uri uri, String name, long size) {
        this.uri = uri;
        this.name = name;
        this.size = size;
    }
}
