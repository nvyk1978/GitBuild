package com.cmyk.gitbuild;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.os.Build;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class DiagnosticLog {
    private static final Object LOCK = new Object();
    private static final String LOG_NAME = "gitbuild_diagnostic.log";
    private static Context app;

    private DiagnosticLog() {}

    public static void init(Context context) {
        app = context.getApplicationContext();
    }

    private static File logFile() {
        if (app == null) return null;
        return new File(app.getFilesDir(), LOG_NAME);
    }

    public static void log(String message) {
        synchronized (LOCK) {
            try {
                File f = logFile();
                if (f == null) return;
                if (f.exists() && f.length() > 2L * 1024L * 1024L) {
                    // Keep diagnostics bounded. A fresh session header will follow naturally.
                    //noinspection ResultOfMethodCallIgnored
                    f.delete();
                }
                String time = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(new Date());
                String thread = Thread.currentThread().getName();
                String line = time + " [" + thread + "] " + safe(message) + "\n";
                try (FileOutputStream out = new FileOutputStream(f, true)) {
                    out.write(line.getBytes(StandardCharsets.UTF_8));
                }
            } catch (Exception ignored) {}
        }
    }

    public static void error(String where, Throwable t) {
        String msg = t == null ? "null" : (t.getMessage() == null ? t.getClass().getName() : t.getClass().getName() + ": " + t.getMessage());
        log(where + " ERROR " + msg);
        if (t != null) {
            try {
                StringWriter sw = new StringWriter();
                t.printStackTrace(new PrintWriter(sw));
                for (String line : sw.toString().split("\\r?\\n")) {
                    if (!line.trim().isEmpty()) log("  " + line);
                }
            } catch (Exception ignored) {}
        }
    }

    public static String report(Context context) {
        synchronized (LOCK) {
            StringBuilder s = new StringBuilder();
            s.append("GitBuild diagnostic report\n");
            s.append("Generated: ").append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(new Date())).append("\n");
            s.append("Device: ").append(Build.MODEL).append("\n");
            s.append("Android: ").append(Build.VERSION.RELEASE).append(" (SDK ").append(Build.VERSION.SDK_INT).append(")\n");
            try {
                PackageInfo p = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
                s.append("App: ").append(p.versionName).append(" (").append(p.getLongVersionCode()).append(")\n");
            } catch (Exception e) {
                s.append("App: unknown\n");
            }
            s.append("\n--- LOG ---\n");
            try {
                File f = logFile();
                if (f != null && f.exists()) s.append(new String(java.nio.file.Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8));
            } catch (Exception e) {
                s.append("<log read failed: ").append(e.getMessage()).append(">\n");
            }
            return s.toString();
        }
    }

    public static void clear() {
        synchronized (LOCK) {
            try {
                File f = logFile();
                if (f != null && f.exists()) {
                    //noinspection ResultOfMethodCallIgnored
                    f.delete();
                }
            } catch (Exception ignored) {}
        }
    }

    public static File writeReportFile(Context context) throws Exception {
        File f = new File(context.getCacheDir(), "GitBuild_diagnostic.txt");
        try (FileOutputStream out = new FileOutputStream(f, false)) {
            out.write(report(context).getBytes(StandardCharsets.UTF_8));
        }
        return f;
    }

    private static String safe(String s) {
        if (s == null) return "null";
        return s.replace('\r', ' ').replace('\n', ' ');
    }
}
