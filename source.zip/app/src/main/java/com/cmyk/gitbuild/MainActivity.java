package com.cmyk.gitbuild;

import android.app.*;
import android.content.*;
import android.content.ContentValues;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.util.Base64;
import android.view.*;
import android.widget.*;

import java.io.ByteArrayInputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class MainActivity extends Activity {
    private static final int BG=Color.rgb(48,48,48), DGRAY=Color.rgb(37,32,32), GRAY=Color.rgb(69,64,64),
            LGRAY=Color.rgb(101,96,96), BLUE=Color.rgb(34,51,85), LBLUE=Color.rgb(68,85,119),
            ORANGE=Color.rgb(119,85,0), WHITE=Color.rgb(169,169,153), GREEN=Color.rgb(34,119,51), TEXT=Color.WHITE;
    private static final String CALLBACK_BASE = "http://127.0.0.1/callback";
    private static final String RETURN_URI = "gitbuild://oauth/return";
    private final List<SharedItem> shared = new ArrayList<>();
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private SecureStore store;
    private GitHubApi.Repo selectedRepo;
    private TextView filesText, repoText, statusText, authText;
    private Button buildButton, authButton;
    private OAuthLoopbackServer oauthServer;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b); store = new SecureStore(this); buildUi(); acceptIntent(getIntent()); handleReturnIntent(getIntent()); refreshAuthUi();
    }
    @Override protected void onNewIntent(Intent i) { super.onNewIntent(i); setIntent(i); acceptIntent(i); handleReturnIntent(i); }
    @Override protected void onResume() { super.onResume(); refreshAuthUi(); showOAuthStateIfNeeded(); }
    @Override protected void onDestroy() { if(oauthServer!=null) oauthServer.close(); io.shutdownNow(); super.onDestroy(); }

    private void buildUi() {
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(18),dp(18),dp(18)); root.setBackgroundColor(BG);
        TextView title=text("GitBuild",24,true); root.addView(title,new LinearLayout.LayoutParams(-1,-2));
        TextView ver=text("0.1.2",12,false); ver.setTextColor(WHITE); root.addView(ver);
        root.addView(space(14));

        root.addView(label("GitHub")); authText=text("未ログイン",15,false); root.addView(card(authText));
        LinearLayout authButtons=row(); authButton=button("GitHubでログイン", LBLUE); Button settings=button("OAuth設定", GRAY);
        authButtons.addView(authButton,weight()); authButtons.addView(gap()); authButtons.addView(settings,weight()); root.addView(authButtons);
        authButton.setOnClickListener(v->{ if(isLoggedIn()) logout(); else beginLogin(); });
        settings.setOnClickListener(v->oauthSettingsDialog());

        root.addView(space(14));
        root.addView(label("受信ファイル")); filesText=text("source.zip と .yml を共有してください",15,false); root.addView(card(filesText));
        root.addView(space(12));
        root.addView(label("リポジトリ")); repoText=text("未選択",15,false); root.addView(card(repoText));
        LinearLayout repoButtons=row(); Button select=button("選択", LBLUE), create=button("新規作成", ORANGE); repoButtons.addView(select,weight()); repoButtons.addView(gap()); repoButtons.addView(create,weight()); root.addView(repoButtons);
        root.addView(space(12));
        root.addView(label("ビルド状態")); statusText=text("待機中",15,false); root.addView(card(statusText));
        root.addView(space(12));
        buildButton=button("アップロード＆ビルド", BLUE); root.addView(buildButton,new LinearLayout.LayoutParams(-1,dp(48)));
        select.setOnClickListener(v->loadRepos()); create.setOnClickListener(v->createRepoDialog()); buildButton.setOnClickListener(v->startBuild());
        ScrollView sv=new ScrollView(this); sv.addView(root); setContentView(sv);
    }

    private void acceptIntent(Intent intent) {
        String a=intent.getAction(); if(!Intent.ACTION_SEND.equals(a)&&!Intent.ACTION_SEND_MULTIPLE.equals(a)) return;
        shared.clear();
        if(Intent.ACTION_SEND.equals(a)) { Uri u=intent.getParcelableExtra(Intent.EXTRA_STREAM); if(u!=null) addUri(u); }
        else { ArrayList<Uri> us=intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM); if(us!=null) for(Uri u:us) addUri(u); }
        refreshFiles();
    }
    private void addUri(Uri u) {
        String name="shared_file"; long size=-1;
        try(Cursor c=getContentResolver().query(u,new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE},null,null,null)) {
            if(c!=null&&c.moveToFirst()){ name=c.getString(0); size=c.isNull(1)?-1:c.getLong(1); }
        } catch(Exception ignored){}
        shared.add(new SharedItem(u,name,size));
    }
    private void refreshFiles(){ StringBuilder s=new StringBuilder(); for(SharedItem f:shared) s.append("✓ ").append(f.name).append(f.size>=0?"   "+human(f.size):"").append("\n"); filesText.setText(s.length()==0?"source.zip と .yml を共有してください":s.toString().trim()); }

    private boolean isConfigured(){ return notEmpty(store.getString("client_id")) && notEmpty(store.getSecret("client_secret")); }
    private boolean isLoggedIn(){ return notEmpty(store.getSecret("access_token")); }
    private void refreshAuthUi(){
        if(isLoggedIn()) { String login=store.getString("login"); authText.setText("✓ ログイン中"+(notEmpty(login)?" : "+login:"")); authButton.setText("ログアウト"); authButton.setBackground(round(DGRAY,10)); }
        else if(notEmpty(store.getString("oauth_state"))) { authText.setText("GitHub認証処理中…"); authButton.setText("GitHubでログイン"); authButton.setBackground(round(LBLUE,10)); }
        else { authText.setText(isConfigured()?"未ログイン":"OAuth App未設定"); authButton.setText("GitHubでログイン"); authButton.setBackground(round(LBLUE,10)); }
    }

    private void showOAuthStateIfNeeded() {
        if(isLoggedIn()) return;
        String err=store.getString("oauth_last_error");
        if(notEmpty(err)) status("OAuthエラー\n"+err);
        else if(notEmpty(store.getString("oauth_state"))) status("GitHubログイン処理中…");
    }

    private void handleReturnIntent(Intent intent) {
        Uri d=intent==null?null:intent.getData();
        if(d==null || !"gitbuild".equalsIgnoreCase(d.getScheme()) || !"oauth".equalsIgnoreCase(d.getHost())) return;
        refreshAuthUi();
        if(isLoggedIn()) status("✓ GitHubログイン完了");
        else if(notEmpty(store.getString("oauth_last_error"))) status("OAuthエラー\n"+store.getString("oauth_last_error"));
        else status("GitHubログイン処理中…");
    }

    private void oauthSettingsDialog() {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(18),dp(4),dp(18),0);
        TextView info=text("GitHub OAuth Appを1つ作成し、下のRedirect URIを登録してください。GitHubのログイン名・パスワードではありません。PATも不要です。",13,false); info.setTextColor(WHITE); box.addView(info);
        TextView cb=text(CALLBACK_BASE,13,false); cb.setTextColor(TEXT); cb.setPadding(0,dp(10),0,dp(10)); cb.setTextIsSelectable(true); box.addView(cb);
        EditText id=input("Client ID", false); String oldId=store.getString("client_id"); if(oldId!=null)id.setText(oldId); box.addView(id,new LinearLayout.LayoutParams(-1,dp(52)));
        box.addView(space(8));
        EditText secret=input("Client Secret", true); String oldSecret=store.getSecret("client_secret"); if(oldSecret!=null)secret.setText(oldSecret); box.addView(secret,new LinearLayout.LayoutParams(-1,dp(52)));
        AlertDialog d=new AlertDialog.Builder(this).setTitle("OAuth設定").setView(box)
                .setNegativeButton("キャンセル",null)
                .setNeutralButton("OAuth App作成",null)
                .setPositiveButton("保存",null).create();
        d.setOnShowListener(x->{
            d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->openUrl("https://github.com/settings/applications/new"));
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
                String nid=id.getText().toString().trim(), ns=secret.getText().toString().trim();
                if(nid.isEmpty()||ns.isEmpty()){toast("Client ID と Client Secret を入力してください");return;}
                try {
                    boolean changed=!nid.equals(store.getString("client_id")) || !ns.equals(store.getSecret("client_secret"));
                    store.putString("client_id",nid); store.putSecret("client_secret",ns);
                    if(changed) { store.clearTokens(); store.clearOAuthPending(); store.remove("oauth_last_error"); }
                    refreshAuthUi(); d.dismiss(); toast("OAuth設定を保存しました");
                } catch(Exception e){error(e);}
            });
        }); d.show();
    }

    private void beginLogin() {
        if(!isConfigured()){ oauthSettingsDialog(); return; }
        try {
            if(oauthServer!=null) oauthServer.close();
            String state=randomUrlSafe(32), verifier=randomUrlSafe(64);
            String challenge=Base64.encodeToString(MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII)), Base64.URL_SAFE|Base64.NO_PADDING|Base64.NO_WRAP);
            oauthServer=new OAuthLoopbackServer(RETURN_URI,(code,returnedState,err)->ui.post(()->handleOAuthCallback(code,returnedState,err)));
            String redirect="http://127.0.0.1:"+oauthServer.port()+"/callback";
            store.putString("oauth_state",state);
            store.putString("oauth_redirect",redirect);
            store.putSecret("oauth_verifier",verifier);
            store.putLong("oauth_started_at",System.currentTimeMillis());
            store.remove("oauth_last_error");
            String url="https://github.com/login/oauth/authorize?client_id="+enc(store.getString("client_id"))+
                    "&redirect_uri="+enc(redirect)+"&scope="+enc("repo workflow offline_access")+
                    "&state="+enc(state)+"&code_challenge="+enc(challenge)+"&code_challenge_method=S256&prompt=select_account";
            refreshAuthUi(); status("GitHub認証待ち…"); openUrl(url);
        } catch(Exception e){oauthFailure(e);}
    }

    private void handleOAuthCallback(String code,String state,String err) {
        String expected=store.getString("oauth_state");
        String redirect=store.getString("oauth_redirect");
        String verifier=store.getSecret("oauth_verifier");
        if(err!=null){oauthFailure(new Exception("OAuth: "+err));return;}
        if(code==null||state==null||!state.equals(expected)){oauthFailure(new Exception("OAuth stateが一致しません"));return;}
        if(!notEmpty(redirect)||!notEmpty(verifier)){oauthFailure(new Exception("OAuthセッション情報が失われました。もう一度ログインしてください"));return;}
        status("GitHubログイン処理中…");
        io.execute(()->{ try {
            GitHubOAuth.TokenResult t=GitHubOAuth.exchange(store.getString("client_id"),store.getSecret("client_secret"),code,redirect,verifier);
            GitHubApi a=new GitHubApi(t.accessToken);
            String login=a.getLogin();
            saveTokens(t);
            store.putString("login",login);
            store.clearOAuthPending();
            store.remove("oauth_last_error");
            ui.post(()->{refreshAuthUi();status("✓ GitHubログイン完了");toast("GitHubにログインしました");});
        } catch(Exception e){ui.post(()->oauthFailure(e));} });
    }

    private void oauthFailure(Exception e) {
        String msg=e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();
        store.clearOAuthPending();
        store.putString("oauth_last_error",msg);
        refreshAuthUi();
        status("OAuthエラー\n"+msg);
    }

    private void logout(){ store.clearTokens(); store.clearOAuthPending(); store.remove("oauth_last_error"); selectedRepo=null; repoText.setText("未選択"); refreshAuthUi(); status("ログアウトしました"); }

    private void saveTokens(GitHubOAuth.TokenResult t) throws Exception {
        store.putSecret("access_token",t.accessToken); store.putLong("access_expires_at",t.accessExpiresAt);
        store.putSecret("refresh_token",t.refreshToken); store.putLong("refresh_expires_at",t.refreshExpiresAt);
    }

    private GitHubApi api() throws Exception {
        String token=store.getSecret("access_token"); if(!notEmpty(token)) throw new Exception("先に「GitHubでログイン」してください");
        long exp=store.getLong("access_expires_at",0); String refresh=store.getSecret("refresh_token");
        if(exp>0 && System.currentTimeMillis()>exp-300000L && notEmpty(refresh)) {
            GitHubOAuth.TokenResult t=GitHubOAuth.refresh(store.getString("client_id"),store.getSecret("client_secret"),refresh); saveTokens(t); token=t.accessToken;
        }
        return new GitHubApi(token);
    }

    private void loadRepos() {
        if(!isLoggedIn()){toast("先にGitHubへログインしてください");return;}
        status("リポジトリ取得中…"); io.execute(()->{ try { List<GitHubApi.Repo> repos=api().listRepos(); ui.post(()->showRepoPicker(repos)); } catch(Exception e){ ui.post(()->error(e)); } });
    }
    private void showRepoPicker(List<GitHubApi.Repo> repos) {
        status("待機中"); if(repos.isEmpty()){toast("リポジトリがありません");return;} String[] names=new String[repos.size()]; for(int i=0;i<names.length;i++) names[i]=repos.get(i).fullName;
        new AlertDialog.Builder(this).setTitle("リポジトリ選択").setItems(names,(d,which)->{selectedRepo=repos.get(which); repoText.setText(selectedRepo.fullName);}).setNegativeButton("キャンセル",null).show();
    }
    private void createRepoDialog() {
        if(!isLoggedIn()){toast("先にGitHubへログインしてください");return;}
        EditText e=input("repository-name",false);
        new AlertDialog.Builder(this).setTitle("新規リポジトリ").setMessage("Private + README初期化で作成します。")
                .setView(e).setNegativeButton("キャンセル",null).setPositiveButton("作成",(d,w)->{String name=e.getText().toString().trim(); if(name.isEmpty())return; status("作成中…"); io.execute(()->{try{GitHubApi.Repo r=api().createRepo(name,true); ui.post(()->{selectedRepo=r; repoText.setText(r.fullName); status("作成完了");});}catch(Exception ex){ui.post(()->error(ex));}});}).show();
    }

    private void startBuild() {
        if(!isLoggedIn()){toast("先にGitHubへログインしてください");return;} if(shared.isEmpty()){toast("source.zip と .yml を共有してください");return;} if(selectedRepo==null){toast("リポジトリを選択してください");return;}
        buildButton.setEnabled(false); status("アップロード中…");
        io.execute(()->{ try {
            GitHubApi a=api(); String sha=a.commitFiles(selectedRepo,shared,getContentResolver()); postStatus("コミット完了 / Actions待機中…");
            GitHubApi.Run run=null; for(int i=0;i<40&&run==null;i++){ if(i>0)Thread.sleep(3000); run=a.findRun(selectedRepo.fullName,sha); }
            if(run==null) throw new Exception("このコミットから起動したActionsが見つかりません。workflowの on: push を確認してください");
            long id=run.id;
            while(!"completed".equals(run.status)){ postStatus("Actions: "+run.status+"  #"+id); Thread.sleep(5000); a=api(); run=a.getRun(selectedRepo.fullName,id); }
            if(!"success".equals(run.conclusion)) throw new Exception("Actions終了: "+run.conclusion+"  (#"+id+")");
            postStatus("ビルド成功 / APK取得中…"); List<GitHubApi.Artifact> arts=a.artifacts(selectedRepo.fullName,id); if(arts.isEmpty()) throw new Exception("Artifactがありません");
            GitHubApi.Artifact chosen=arts.get(0); for(GitHubApi.Artifact x:arts) if(x.name.toLowerCase().contains("apk")){chosen=x;break;}
            byte[] zip=a.downloadArtifact(selectedRepo.fullName,chosen.id); List<String> saved=saveApks(zip); if(saved.isEmpty()) throw new Exception("Artifact内に.apkがありません");
            String names=String.join(", ",saved); ui.post(()->{status("✓ 完了\nDownload: "+names); buildButton.setEnabled(true);});
        } catch(Exception e){ ui.post(()->{buildButton.setEnabled(true); error(e);}); } });
    }

    private List<String> saveApks(byte[] zipBytes) throws Exception {
        List<String> saved=new ArrayList<>(); try(ZipInputStream zin=new ZipInputStream(new ByteArrayInputStream(zipBytes))) {
            ZipEntry z; byte[] buf=new byte[32768]; while((z=zin.getNextEntry())!=null){ if(z.isDirectory()||!z.getName().toLowerCase().endsWith(".apk"))continue; String name=z.getName(); int slash=name.lastIndexOf('/'); if(slash>=0)name=name.substring(slash+1);
                ContentValues v=new ContentValues(); v.put(MediaStore.Downloads.DISPLAY_NAME,name); v.put(MediaStore.Downloads.MIME_TYPE,"application/vnd.android.package-archive"); v.put(MediaStore.Downloads.RELATIVE_PATH,"Download");
                Uri u=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v); if(u==null)throw new Exception("Downloadへ保存できません");
                try(OutputStream out=getContentResolver().openOutputStream(u)){int n;while((n=zin.read(buf))>=0)out.write(buf,0,n);} saved.add(name);
            }
        } return saved;
    }

    private void openUrl(String url){ try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){error(e);} }
    private static String randomUrlSafe(int bytes){byte[] b=new byte[bytes];new SecureRandom().nextBytes(b);return Base64.encodeToString(b,Base64.URL_SAFE|Base64.NO_PADDING|Base64.NO_WRAP);}
    private static String enc(String s) throws Exception{return URLEncoder.encode(s,"UTF-8").replace("+","%20");}
    private static boolean notEmpty(String s){return s!=null&&!s.isEmpty();}
    private void postStatus(String s){ui.post(()->status(s));} private void status(String s){statusText.setText(s);} private void error(Exception e){status("エラー\n"+(e.getMessage()==null?e.getClass().getSimpleName():e.getMessage()));}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    private TextView text(String s,int sp,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextColor(TEXT);v.setTextSize(sp);if(bold)v.setTypeface(null,1);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    private TextView label(String s){TextView v=text(s,12,false);v.setTextColor(WHITE);v.setPadding(0,0,0,dp(6));return v;}
    private EditText input(String hint,boolean password){EditText e=new EditText(this);e.setHint(hint);e.setTextColor(TEXT);e.setHintTextColor(WHITE);e.setSingleLine(true);e.setPadding(dp(12),0,dp(12),0);e.setBackground(round(GRAY,8));if(password)e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);return e;}
    private View card(TextView content){LinearLayout l=new LinearLayout(this);l.setPadding(dp(14),dp(12),dp(14),dp(12));l.setBackground(round(GRAY,10));l.addView(content,new LinearLayout.LayoutParams(-1,-2));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(8));l.setLayoutParams(p);return l;}
    private Button button(String s,int color){Button b=new Button(this);b.setText(s);b.setTextColor(TEXT);b.setTextSize(14);b.setAllCaps(false);b.setPadding(dp(8),0,dp(8),0);b.setBackground(round(color,10));return b;}
    private GradientDrawable round(int c,int r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));return g;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);return l;} private LinearLayout.LayoutParams weight(){return new LinearLayout.LayoutParams(0,dp(44),1f);} private View gap(){Space s=new Space(this);s.setLayoutParams(new LinearLayout.LayoutParams(dp(8),1));return s;} private View space(int h){Space s=new Space(this);s.setLayoutParams(new LinearLayout.LayoutParams(1,dp(h)));return s;}
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);} private static String human(long b){if(b<1024)return b+" B";if(b<1024*1024)return String.format(Locale.US,"%.1f KB",b/1024f);return String.format(Locale.US,"%.1f MB",b/1048576f);}
}
