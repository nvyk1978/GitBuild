package com.cmyk.gitbuild;

import android.app.*;
import android.animation.ValueAnimator;
import android.content.*;
import android.content.ContentValues;
import android.content.ContentUris;
import android.content.ClipData;
import android.content.res.ColorStateList;
import android.content.ClipboardManager;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.util.Base64;
import android.view.*;
import android.view.animation.LinearInterpolator;
import android.widget.*;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.attribute.BasicFileAttributes;
import java.text.Normalizer;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class MainActivity extends Activity {
    private static final int BG=Color.rgb(48,48,48), DGRAY=Color.rgb(37,32,32), GRAY=Color.rgb(69,64,64),
            LGRAY=Color.rgb(101,96,96), BLUE=Color.rgb(34,51,85), LBLUE=Color.rgb(68,85,119),
            RED=Color.rgb(68,17,0), ORANGE=Color.rgb(119,85,0), WHITE=Color.rgb(169,169,153), GREEN=Color.rgb(34,119,51), TEXT=Color.WHITE,
            NEON_GREEN=Color.rgb(0,255,64), NEON_GREEN_DARK=Color.rgb(0,44,12);
    private static final String CALLBACK_BASE = "http://127.0.0.1/callback";
    private static final String RETURN_URI = "gitbuild://oauth/return";
    private final List<SharedItem> shared = new ArrayList<>();
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final ExecutorService fileIo = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private SecureStore store;
    private GitHubApi.Repo selectedRepo;
    private TextView statusDetailText, elapsedText, sourceIdentityText, sourcePrecheckText;
    private ShimmerTextView statusText, authText, repoText;
    private LinearLayout filesContent, statusContent;
    private ShimmerRow authContent, repoContent, filesFieldContent;
    private GreenCheckView authCheck, repoCheck, statusCheck;
    private Button buildButton, emergencyStopButton, clearButton, authButton, runApkButton, renameRepoButton, errorDetailsButton, shareErrorButton, rerunFailedButton;
    private ProgressBar buildSpinner;
    private NToggleSwitch recoverySwitch, autoRepoSwitch, renameSourceSwitch;
    private Uri lastApkUri;
    private String lastApkName;
    private OAuthLoopbackServer oauthServer;
    private volatile boolean cancelRequested;
    private volatile long activeRunId = -1L;
    private volatile Thread activeBuildThread;
    private volatile GitHubApi.Repo activeBuildRepo;
    private final ExecutorService controlIo = Executors.newSingleThreadExecutor();
    private File cachedSourceZipFile;
    private String cachedSourceZipOriginalName;
    private boolean buildTimerRunning;
    private boolean pendingExplorerAfterPermission;
    private long buildStartedElapsedRealtime;
    private String statusBaseText = "待機中";
    private volatile SourceIdentity lastSourceIdentity;
    private volatile Uri lastSourceIdentityUri;
    private volatile boolean sourceIdentityPending;
    private volatile PrecheckResult lastPrecheckResult;
    private volatile Uri lastPrecheckUri;
    private volatile boolean sourcePrecheckPending;
    private volatile boolean buildBusy;
    private volatile String lastFailureReport;
    private volatile long lastFailureRunId=-1L;
    private volatile String lastFailureRepo;
    private volatile boolean activityDestroyed;
    private static final String NOTIFICATION_CHANNEL="gitbuild_builds";
    private static final int CONTROL_HEIGHT_DP=44;
    private static final int TOGGLE_ROW_HEIGHT_DP=36;
    private static final int UI_GAP_DP=8;
    private static final int BUTTON_GAP_DP=12;
    private static final int GROUP_GAP_DP=12;
    private static final int STATUS_ACTION_HEIGHT_DP=32;
    private static final int STATUS_DETAIL_HEIGHT_DP=40;
    private static final int RECEIVED_FIELD_HEIGHT_DP=120;
    private static final int RECEIVED_META_HEIGHT_DP=24;
    private static final int CHECK_ICON_DP=20;
    private static final int DIAGNOSTIC_BUTTON_HEIGHT_DP=28;
    private static final int PRECHECK_OK=0, PRECHECK_WARNING=1, PRECHECK_ERROR=2;
    private final Runnable buildElapsedTicker = new Runnable() {
        @Override public void run() {
            if(!buildTimerRunning) return;
            renderStatusText();
            ui.postDelayed(this, 1000L);
        }
    };

    private static final class ShimmerTextView extends TextView {
        private final ValueAnimator shimmerAnimator;
        private boolean shimmering;
        private float shimmerX;

        ShimmerTextView(Context context) {
            super(context);
            shimmerAnimator=ValueAnimator.ofFloat(0f,1f);
            shimmerAnimator.setDuration(1450L);
            shimmerAnimator.setRepeatCount(ValueAnimator.INFINITE);
            shimmerAnimator.setInterpolator(new LinearInterpolator());
            shimmerAnimator.addUpdateListener(a->{
                float w=Math.max(1f,getWidth());
                float f=(Float)a.getAnimatedValue();
                shimmerX=(-0.55f*w)+(2.10f*w*f);
                invalidate();
            });
        }

        void setShimmering(boolean enabled){
            if(shimmering==enabled) return;
            shimmering=enabled;
            if(enabled){
                if(isAttachedToWindow() && !shimmerAnimator.isStarted()) shimmerAnimator.start();
            }else{
                shimmerAnimator.cancel();
                getPaint().setShader(null);
                invalidate();
            }
        }

        @Override protected void onAttachedToWindow(){
            super.onAttachedToWindow();
            if(shimmering && !shimmerAnimator.isStarted()) shimmerAnimator.start();
        }

        @Override protected void onDetachedFromWindow(){
            shimmerAnimator.cancel();
            getPaint().setShader(null);
            super.onDetachedFromWindow();
        }

        @Override protected void onDraw(android.graphics.Canvas canvas){
            if(shimmering && getWidth()>0){
                float band=Math.max(28f,getWidth()*0.30f);
                LinearGradient shader=new LinearGradient(
                        shimmerX-band,0f,shimmerX+band,0f,
                        new int[]{MainActivity.NEON_GREEN,MainActivity.NEON_GREEN,MainActivity.NEON_GREEN_DARK,MainActivity.NEON_GREEN,MainActivity.NEON_GREEN},
                        new float[]{0f,0.24f,0.50f,0.76f,1f},Shader.TileMode.CLAMP);
                getPaint().setShader(shader);
            }else{
                getPaint().setShader(null);
            }
            super.onDraw(canvas);
            getPaint().setShader(null);
        }
    }

    /**
     * One continuous dark-band shimmer shared by every child in a row.
     * Drawing the mask after dispatchDraw makes the same band cross icons,
     * badges and text without independent animation phases.
     */
    private static final class ShimmerRow extends LinearLayout {
        private final Paint shimmerPaint=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final ValueAnimator shimmerAnimator;
        private boolean shimmering;
        private float shimmerX;

        ShimmerRow(Context context){
            super(context);
            setOrientation(HORIZONTAL);
            setWillNotDraw(false);
            shimmerAnimator=ValueAnimator.ofFloat(0f,1f);
            shimmerAnimator.setDuration(1450L);
            shimmerAnimator.setRepeatCount(ValueAnimator.INFINITE);
            shimmerAnimator.setInterpolator(new LinearInterpolator());
            shimmerAnimator.addUpdateListener(a->{
                float w=Math.max(1f,getWidth());
                float f=(Float)a.getAnimatedValue();
                shimmerX=(-0.28f*w)+(1.56f*w*f);
                invalidate();
            });
        }

        void setShimmering(boolean enabled){
            if(shimmering==enabled) return;
            shimmering=enabled;
            if(enabled){
                if(isAttachedToWindow() && !shimmerAnimator.isStarted()) shimmerAnimator.start();
            }else{
                shimmerAnimator.cancel();
                invalidate();
            }
        }

        @Override protected void onAttachedToWindow(){
            super.onAttachedToWindow();
            if(shimmering && !shimmerAnimator.isStarted()) shimmerAnimator.start();
        }

        @Override protected void onDetachedFromWindow(){
            shimmerAnimator.cancel();
            super.onDetachedFromWindow();
        }

        @Override protected void dispatchDraw(Canvas canvas){
            super.dispatchDraw(canvas);
            if(!shimmering || getWidth()<=0) return;
            float w=getWidth();
            float band=Math.max(dpF(34f),w*0.12f);
            LinearGradient g=new LinearGradient(
                    shimmerX-band,0f,shimmerX+band,0f,
                    new int[]{Color.TRANSPARENT,Color.argb(80,0,0,0),Color.argb(225,0,0,0),Color.argb(80,0,0,0),Color.TRANSPARENT},
                    new float[]{0f,0.24f,0.50f,0.76f,1f},Shader.TileMode.CLAMP);
            shimmerPaint.setShader(g);
            canvas.drawRect(0f,0f,getWidth(),getHeight(),shimmerPaint);
            shimmerPaint.setShader(null);
        }

        private float dpF(float v){return v*getResources().getDisplayMetrics().density;}
    }

    private static final class SavedApk {
        final String name; final Uri uri; final String appName; final String versionName;
        SavedApk(String name, Uri uri, String appName, String versionName){
            this.name=name; this.uri=uri; this.appName=appName; this.versionName=versionName;
        }
    }
    private static final class ApkIdentity {
        final String appName; final String versionName; final String packageName;
        ApkIdentity(String appName, String versionName, String packageName){
            this.appName=appName; this.versionName=versionName; this.packageName=packageName;
        }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        DiagnosticLog.init(this);
        DiagnosticLog.log("APP onCreate action="+(getIntent()==null?"null":getIntent().getAction())+" data="+safeIntentData(getIntent()));
        store = new SecureStore(this); ensureNotificationChannel(); buildUi(); acceptIntent(getIntent()); handleReturnIntent(getIntent()); refreshAuthUi();
        DiagnosticLog.log("AUTH startup configured="+isConfigured()+" loggedIn="+isLoggedIn()+" pending="+notEmpty(store.getString("oauth_state")));
    }
    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i); setIntent(i);
        DiagnosticLog.log("APP onNewIntent action="+(i==null?"null":i.getAction())+" data="+safeIntentData(i));
        acceptIntent(i); handleReturnIntent(i);
    }
    @Override protected void onResume() {
        super.onResume();
        DiagnosticLog.log("APP onResume loggedIn="+isLoggedIn()+" pending="+notEmpty(store.getString("oauth_state")));
        refreshAuthUi(); showOAuthStateIfNeeded();
        if(pendingExplorerAfterPermission && (Build.VERSION.SDK_INT<30 || Environment.isExternalStorageManager())){
            pendingExplorerAfterPermission=false;
            ui.post(this::showFileExplorer);
        }
    }
    @Override protected void onDestroy() {
        activityDestroyed=true;
        boolean buildActive=activeBuildThread!=null;
        DiagnosticLog.log("APP onDestroy changingConfig="+isChangingConfigurations()+" server="+(oauthServer!=null)+" buildActive="+buildActive);
        if(oauthServer!=null) oauthServer.close();
        ui.removeCallbacks(buildElapsedTicker);
        if(!buildActive){ io.shutdownNow(); fileIo.shutdownNow(); controlIo.shutdownNow(); }
        else DiagnosticLog.log("BUILD Activity destroyed; keeping worker alive under BuildWatchService");
        super.onDestroy();
    }

    private void buildUi() {
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(18),dp(18),dp(18)); root.setBackgroundColor(BG);
        root.addView(space(50));
        LinearLayout titleRow=row();
        TextView title=text("GitBuild",25,true); title.setTextColor(WHITE); titleRow.addView(title,new LinearLayout.LayoutParams(0,dp(44),1f));
        ImageButton menu=menuIcon();
        titleRow.addView(menu,new LinearLayout.LayoutParams(dp(44),dp(44))); root.addView(titleRow,new LinearLayout.LayoutParams(-1,dp(44)));
        menu.setOnClickListener(v->{
            PopupMenu pm=new PopupMenu(this,menu);
            pm.getMenu().add("使用方法");
            pm.getMenu().add("診断ログ");
            pm.setOnMenuItemClickListener(item->{
                String t=String.valueOf(item.getTitle());
                if("使用方法".equals(t)) showUsage(); else if("診断ログ".equals(t)) showDiagnosticLog();
                return true;
            });
            pm.show();
        });
        TextView ver=text(BuildConfig.VERSION_NAME,12,false); ver.setTextColor(WHITE); root.addView(ver);
        root.addView(space(GROUP_GAP_DP));

        root.addView(label("GitHub"));
        authContent=new ShimmerRow(this); authContent.setGravity(Gravity.CENTER_VERTICAL);
        authCheck=new GreenCheckView(this); authCheck.setColors(NEON_GREEN,Color.BLACK); authCheck.setVisibility(View.GONE); authContent.addView(authCheck,new LinearLayout.LayoutParams(dp(CHECK_ICON_DP),dp(CHECK_ICON_DP)));
        authContent.addView(hGap(8)); authText=shimmerText("未ログイン",15,false); authText.setShimmering(false); authContent.addView(authText,new LinearLayout.LayoutParams(0,-2,1f));
        root.addView(mainFieldView(authContent,Color.BLACK));
        root.addView(space(BUTTON_GAP_DP));
        LinearLayout authButtons=row(); authButton=button("GitHubでログイン", LBLUE); Button settings=button("OAuth設定", GRAY);
        authButtons.addView(authButton,weight()); authButtons.addView(gap()); authButtons.addView(settings,weight()); root.addView(authButtons);
        authButton.setOnClickListener(v->{ if(isLoggedIn()) logout(); else beginLogin(); });
        settings.setOnClickListener(v->oauthSettingsDialog());

        root.addView(space(GROUP_GAP_DP));
        root.addView(label("受信ファイル"));
        filesFieldContent=new ShimmerRow(this); filesFieldContent.setOrientation(LinearLayout.VERTICAL); filesFieldContent.setGravity(Gravity.TOP|Gravity.START); filesFieldContent.setShimmering(false);
        filesContent=new LinearLayout(this); filesContent.setOrientation(LinearLayout.VERTICAL); filesContent.setGravity(Gravity.TOP|Gravity.START);
        filesFieldContent.addView(filesContent,new LinearLayout.LayoutParams(-1,0,1f));
        LinearLayout filesMetaRow=row(); filesMetaRow.setGravity(Gravity.BOTTOM|Gravity.START);
        sourceIdentityText=text("",12,false); sourceIdentityText.setTextColor(NEON_GREEN); sourceIdentityText.setVisibility(View.GONE); sourceIdentityText.setSingleLine(true); sourceIdentityText.setEllipsize(android.text.TextUtils.TruncateAt.END); sourceIdentityText.setIncludeFontPadding(false); sourceIdentityText.setGravity(Gravity.CENTER_VERTICAL|Gravity.START);
        sourcePrecheckText=text("",12,false); sourcePrecheckText.setTextColor(NEON_GREEN); sourcePrecheckText.setVisibility(View.GONE); sourcePrecheckText.setSingleLine(true); sourcePrecheckText.setIncludeFontPadding(false); sourcePrecheckText.setGravity(Gravity.CENTER_VERTICAL|Gravity.END);
        sourcePrecheckText.setClickable(true); sourcePrecheckText.setOnClickListener(v->showPrecheckDetails());
        filesMetaRow.addView(sourceIdentityText,new LinearLayout.LayoutParams(0,dp(RECEIVED_META_HEIGHT_DP),1f));
        filesMetaRow.addView(hGap(UI_GAP_DP));
        filesMetaRow.addView(sourcePrecheckText,new LinearLayout.LayoutParams(-2,dp(RECEIVED_META_HEIGHT_DP)));
        filesFieldContent.addView(filesMetaRow,new LinearLayout.LayoutParams(-1,dp(RECEIVED_META_HEIGHT_DP)));
        View filesCard=mainFieldView(filesFieldContent,Color.BLACK);
        filesCard.setPadding(dp(14),dp(4),dp(14),dp(8));
        filesCard.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(RECEIVED_FIELD_HEIGHT_DP)));
        filesCard.setClickable(true); filesCard.setFocusable(true);
        filesCard.setOnClickListener(v->showFileExplorer());
        filesContent.setClickable(true); filesContent.setOnClickListener(v->showFileExplorer());
        root.addView(filesCard);
        root.addView(space(GROUP_GAP_DP));
        root.addView(label("リポジトリ"));
        repoContent=new ShimmerRow(this); repoContent.setGravity(Gravity.CENTER_VERTICAL);
        repoCheck=new GreenCheckView(this); repoCheck.setColors(NEON_GREEN,Color.BLACK); repoCheck.setVisibility(View.GONE);
        repoContent.addView(repoCheck,new LinearLayout.LayoutParams(dp(CHECK_ICON_DP),dp(CHECK_ICON_DP))); repoContent.addView(hGap(8));
        repoText=shimmerText("未選択",15,false); repoText.setShimmering(false); repoContent.addView(repoText,new LinearLayout.LayoutParams(0,-2,1f));
        View repoCard=mainFieldView(repoContent,Color.BLACK); repoCard.setClickable(true); repoCard.setFocusable(true); repoCard.setOnClickListener(v->loadRepos()); repoContent.setOnClickListener(v->loadRepos()); repoText.setOnClickListener(v->loadRepos()); root.addView(repoCard);
        root.addView(space(UI_GAP_DP));
        LinearLayout autoRepoRow=row(); autoRepoRow.setGravity(Gravity.CENTER_VERTICAL|Gravity.START);
        autoRepoSwitch=new NToggleSwitch(this);
        autoRepoSwitch.setChecked(!"0".equals(store.getString("auto_repo_match")),false);
        TextView autoRepoLabel=text("受信ファイルからリポジトリ名の近似値を取得",13,false);
        autoRepoRow.addView(autoRepoSwitch,new LinearLayout.LayoutParams(dp(44),dp(26)));
        autoRepoRow.addView(hGap(UI_GAP_DP)); autoRepoRow.addView(autoRepoLabel,new LinearLayout.LayoutParams(0,dp(TOGGLE_ROW_HEIGHT_DP),1f));
        autoRepoLabel.setOnClickListener(v->autoRepoSwitch.toggle());
        autoRepoSwitch.setOnCheckedChangeListener((view,checked)->{
            store.putString("auto_repo_match",checked?"1":"0");
            DiagnosticLog.log("REPO auto-match toggle="+checked);
            if(checked) maybeAutoSelectRepo("toggle_on");
        });
        root.addView(autoRepoRow,new LinearLayout.LayoutParams(-1,dp(TOGGLE_ROW_HEIGHT_DP)));
        root.addView(space(BUTTON_GAP_DP));

        LinearLayout repoButtons=row();
        renameRepoButton=button("名前変更", LBLUE);
        renameRepoButton.setEnabled(false);
        renameRepoButton.setBackground(buttonBackground(DGRAY));
        renameRepoButton.setTextColor(WHITE);
        Button create=button("新規作成", BLUE);
        repoButtons.addView(renameRepoButton,weight());
        repoButtons.addView(gap());
        repoButtons.addView(create,weight());
        root.addView(repoButtons);

        root.addView(space(GROUP_GAP_DP));
        FrameLayout buildBox=new FrameLayout(this);
        buildButton=button("アップロード＆ビルド", DGRAY); buildButton.setEnabled(false); buildButton.setTextColor(WHITE); buildBox.addView(buildButton,new FrameLayout.LayoutParams(-1,dp(CONTROL_HEIGHT_DP)));
        buildSpinner=new ProgressBar(this); buildSpinner.setIndeterminate(true); buildSpinner.setIndeterminateTintList(ColorStateList.valueOf(WHITE)); buildSpinner.setVisibility(View.GONE);
        FrameLayout.LayoutParams spinnerLp=new FrameLayout.LayoutParams(dp(26),dp(26),Gravity.CENTER); buildBox.addView(buildSpinner,spinnerLp);
        root.addView(buildBox,new LinearLayout.LayoutParams(-1,dp(CONTROL_HEIGHT_DP)));

        root.addView(space(UI_GAP_DP));
        LinearLayout renameSourceRow=row(); renameSourceRow.setGravity(Gravity.CENTER_VERTICAL|Gravity.START);
        renameSourceSwitch=new NToggleSwitch(this); renameSourceSwitch.setOnThumbColor(ORANGE);
        renameSourceSwitch.setChecked(!"0".equals(store.getString("rename_source_on_complete")),false);
        TextView renameSourceLabel=text("ビルド完了時、source.zipをリネーム",14,false);
        renameSourceRow.addView(renameSourceSwitch,new LinearLayout.LayoutParams(dp(44),dp(26)));
        renameSourceRow.addView(hGap(UI_GAP_DP)); renameSourceRow.addView(renameSourceLabel,new LinearLayout.LayoutParams(0,dp(TOGGLE_ROW_HEIGHT_DP),1f));
        renameSourceLabel.setOnClickListener(v->renameSourceSwitch.toggle());
        renameSourceSwitch.setOnCheckedChangeListener((view,checked)->{
            store.putString("rename_source_on_complete",checked?"1":"0");
            DiagnosticLog.log("SOURCE rename-on-complete toggle="+checked);
        });
        root.addView(renameSourceRow,new LinearLayout.LayoutParams(-1,dp(TOGGLE_ROW_HEIGHT_DP)));

        root.addView(space(BUTTON_GAP_DP));
        root.addView(label("ビルド状態"));
        statusContent=new LinearLayout(this); statusContent.setOrientation(LinearLayout.VERTICAL); statusContent.setPadding(dp(14),dp(6),dp(14),dp(10)); statusContent.setBackground(round(Color.BLACK,10));
        LinearLayout statusHeaderRow=row(); statusHeaderRow.setGravity(Gravity.CENTER_VERTICAL);
        statusCheck=new GreenCheckView(this); statusCheck.setColors(NEON_GREEN,Color.BLACK); statusCheck.setVisibility(View.GONE);
        statusHeaderRow.addView(statusCheck,new LinearLayout.LayoutParams(dp(CHECK_ICON_DP),dp(CHECK_ICON_DP)));
        statusHeaderRow.addView(hGap(8));
        statusText=shimmerText("待機中",15,false); statusText.setTextColor(NEON_GREEN); statusText.setIncludeFontPadding(false); statusText.setGravity(Gravity.CENTER_VERTICAL|Gravity.START);
        statusHeaderRow.addView(statusText,new LinearLayout.LayoutParams(0,dp(24),1f));
        elapsedText=text("",14,false); elapsedText.setIncludeFontPadding(false); elapsedText.setGravity(Gravity.CENTER_VERTICAL|Gravity.END); elapsedText.setTextColor(NEON_GREEN);
        statusHeaderRow.addView(elapsedText,new LinearLayout.LayoutParams(dp(58),dp(24)));
        statusContent.addView(statusHeaderRow,new LinearLayout.LayoutParams(-1,dp(24)));
        statusDetailText=text("",14,false); statusDetailText.setTextColor(NEON_GREEN); statusDetailText.setIncludeFontPadding(false); statusDetailText.setSingleLine(false); statusDetailText.setMaxLines(2); statusDetailText.setEllipsize(android.text.TextUtils.TruncateAt.END); statusDetailText.setGravity(Gravity.CENTER_VERTICAL|Gravity.START); statusDetailText.setPadding(dp(CHECK_ICON_DP+8),0,0,0);
        statusContent.addView(statusDetailText,new LinearLayout.LayoutParams(-1,dp(STATUS_DETAIL_HEIGHT_DP)));
        LinearLayout actionRow=row(); actionRow.setGravity(Gravity.BOTTOM|Gravity.END);
        errorDetailsButton=button("エラー詳細",NEON_GREEN); shareErrorButton=button("ChatGPTへ共有",NEON_GREEN); rerunFailedButton=button("失敗Job再実行",NEON_GREEN);
        errorDetailsButton.setTextColor(Color.BLACK); shareErrorButton.setTextColor(Color.BLACK); rerunFailedButton.setTextColor(Color.BLACK);
        errorDetailsButton.setVisibility(View.GONE); shareErrorButton.setVisibility(View.GONE); rerunFailedButton.setVisibility(View.GONE);
        actionRow.addView(errorDetailsButton,new LinearLayout.LayoutParams(0,dp(STATUS_ACTION_HEIGHT_DP),1f)); actionRow.addView(gap()); actionRow.addView(shareErrorButton,new LinearLayout.LayoutParams(0,dp(STATUS_ACTION_HEIGHT_DP),1f)); actionRow.addView(gap()); actionRow.addView(rerunFailedButton,new LinearLayout.LayoutParams(0,dp(STATUS_ACTION_HEIGHT_DP),1f));
        runApkButton=diagnosticButton("実行", NEON_GREEN); runApkButton.setTextColor(Color.BLACK); runApkButton.setVisibility(View.GONE); runApkButton.setOnClickListener(v->runLastApk());
        actionRow.addView(runApkButton,new LinearLayout.LayoutParams(dp(58),dp(DIAGNOSTIC_BUTTON_HEIGHT_DP)));
        LinearLayout.LayoutParams actionLp=new LinearLayout.LayoutParams(-1,dp(STATUS_ACTION_HEIGHT_DP)); statusContent.addView(actionRow,actionLp);
        errorDetailsButton.setOnClickListener(v->showLastFailureReport()); shareErrorButton.setOnClickListener(v->shareLastFailureToChatGPT()); rerunFailedButton.setOnClickListener(v->rerunLastFailedJobs());
        LinearLayout.LayoutParams statusLp=new LinearLayout.LayoutParams(-1,dp(24+STATUS_DETAIL_HEIGHT_DP+STATUS_ACTION_HEIGHT_DP+16)); root.addView(statusContent,statusLp);

        root.addView(space(BUTTON_GAP_DP));
        LinearLayout stopClearRow=row();
        emergencyStopButton=button("緊急停止", DGRAY);
        setEmergencyStopActive(false);
        clearButton=button("クリア", RED); clearButton.setOnClickListener(v->clearMainState());
        stopClearRow.addView(emergencyStopButton,new LinearLayout.LayoutParams(0,dp(CONTROL_HEIGHT_DP),1f));
        stopClearRow.addView(hGap(BUTTON_GAP_DP));
        stopClearRow.addView(clearButton,new LinearLayout.LayoutParams(0,dp(CONTROL_HEIGHT_DP),1f));
        root.addView(stopClearRow,new LinearLayout.LayoutParams(-1,dp(CONTROL_HEIGHT_DP)));
        root.addView(space(BUTTON_GAP_DP));
        LinearLayout recoveryRow=row(); recoveryRow.setGravity(Gravity.CENTER_VERTICAL|Gravity.START);
        recoverySwitch=new NToggleSwitch(this); recoverySwitch.setOnThumbColor(RED); recoverySwitch.setChecked(true,false);
        TextView recoveryLabel=text("緊急停止時、前の状態にリカバリー",14,false);
        recoveryRow.addView(recoverySwitch,new LinearLayout.LayoutParams(dp(44),dp(26)));
        recoveryRow.addView(hGap(UI_GAP_DP)); recoveryRow.addView(recoveryLabel,new LinearLayout.LayoutParams(0,dp(TOGGLE_ROW_HEIGHT_DP),1f));
        recoveryLabel.setOnClickListener(v->recoverySwitch.toggle());
        root.addView(recoveryRow,new LinearLayout.LayoutParams(-1,dp(TOGGLE_ROW_HEIGHT_DP)));
        renameRepoButton.setOnClickListener(v->renameRepoDialog()); create.setOnClickListener(v->createRepoDialog()); buildButton.setOnClickListener(v->startBuild());
        emergencyStopButton.setOnClickListener(v->requestEmergencyStop());
        ScrollView sv=new ScrollView(this); sv.addView(root); setContentView(sv);
        refreshFiles();
    }

    private void acceptIntent(Intent intent) {
        if(intent==null) return;
        String a=intent.getAction();
        Uri viewData=intent.getData();
        String viewScheme=viewData==null?null:viewData.getScheme();
        boolean sharedIntent=Intent.ACTION_SEND.equals(a)||Intent.ACTION_SEND_MULTIPLE.equals(a);
        boolean viewIntent=Intent.ACTION_VIEW.equals(a) && ("content".equalsIgnoreCase(viewScheme)||"file".equalsIgnoreCase(viewScheme));
        if(!sharedIntent && !viewIntent) return;
        DiagnosticLog.log((viewIntent?"OPEN":"SHARE")+" receive action="+a+" type="+intent.getType()+" data="+safeIntentData(intent));
        if(activeBuildThread!=null || buildBusy){
            DiagnosticLog.log("RECEIVE ignored while build active");
            toast("ビルド中は新しい受信ファイルに切り替えられません");
            return;
        }
        clearSourceZipCache();
        clearSelectedRepo(viewIntent?"open":"share");
        shared.clear();
        resetSourceAnalysisState();
        resetBuildStatusForIncoming();
        if(Intent.ACTION_SEND.equals(a)) {
            Uri u=intent.getParcelableExtra(Intent.EXTRA_STREAM); if(u!=null) addUriValidated(u);
        } else if(Intent.ACTION_SEND_MULTIPLE.equals(a)) {
            ArrayList<Uri> us=intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM); if(us!=null) for(Uri u:us) addUriValidated(u);
        } else {
            Uri u=viewData;
            if(u!=null) {
                SharedItem item=itemFromUri(u);
                String lower=item.name==null?"":item.name.toLowerCase(Locale.ROOT);
                if(lower.endsWith(".zip")||lower.endsWith(".yml")||lower.endsWith(".yaml")) addUriValidated(u);
                else {
                    DiagnosticLog.log("OPEN ignored unsupported name="+item.name+" type="+intent.getType());
                    toast("GitBuildで開けるのはZIP / YMLファイルです");
                }
            }
        }
        refreshFiles();
        scheduleSourceIdentityAnalysis();
        maybeAutoSelectRepo(viewIntent?"open":"share");
    }
    private SharedItem itemFromUri(Uri u) {
        String name=null; long size=-1;
        try(Cursor c=getContentResolver().query(u,new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE},null,null,null)) {
            if(c!=null&&c.moveToFirst()){ name=c.getString(0); size=c.isNull(1)?-1:c.getLong(1); }
        } catch(Exception ignored){}
        if(!notEmpty(name) && u!=null){
            String last=u.getLastPathSegment();
            if(notEmpty(last)){ int slash=last.lastIndexOf('/'); name=slash>=0?last.substring(slash+1):last; }
        }
        if(!notEmpty(name)) name="shared_file";
        return new SharedItem(u,name,size);
    }
    private void addUriValidated(Uri u) {
        SharedItem item=itemFromUri(u);
        String lower=item.name==null?"":item.name.toLowerCase(Locale.ROOT);
        boolean zip=lower.endsWith(".zip"), yaml=lower.endsWith(".yml")||lower.endsWith(".yaml");
        if(!zip&&!yaml){ DiagnosticLog.log("SHARE ignored unsupported name="+item.name); return; }
        for(SharedItem existing:shared){
            String e=existing.name==null?"":existing.name.toLowerCase(Locale.ROOT);
            if(zip&&e.endsWith(".zip")){ DiagnosticLog.log("SHARE ignored extra zip name="+item.name); return; }
            if(yaml&&(e.endsWith(".yml")||e.endsWith(".yaml"))){ DiagnosticLog.log("SHARE ignored extra yaml name="+item.name); return; }
        }
        shared.add(item);
        DiagnosticLog.log("SHARE item name="+item.name+" size="+item.size+" uriScheme="+(u==null?"null":u.getScheme()));
    }
    private void refreshFiles(){
        if(filesContent==null)return;
        filesContent.removeAllViews();
        if(shared.isEmpty()){
            if(filesFieldContent!=null) filesFieldContent.setShimmering(false);
            TextView empty=text("タップして source ZIP / .yml を選択",15,false); empty.setTextColor(NEON_GREEN); empty.setIncludeFontPadding(false); empty.setGravity(Gravity.TOP|Gravity.START);
            filesContent.addView(empty,new LinearLayout.LayoutParams(-1,dp(40)));
            if(sourceIdentityText!=null) sourceIdentityText.setVisibility(View.GONE);
            if(sourcePrecheckText!=null) sourcePrecheckText.setVisibility(View.GONE);
            refreshBuildButtonState();
            refreshClearButtonState();
            return;
        }
        final boolean compact=shared.size()>1;
        if(filesFieldContent!=null) filesFieldContent.setShimmering(true);
        for(int i=0;i<shared.size();i++){
            SharedItem f=shared.get(i);
            String lower=f.name==null?"":f.name.toLowerCase(Locale.ROOT);
            boolean zip=lower.endsWith(".zip");
            ShimmerRow line=new ShimmerRow(this); line.setGravity(Gravity.TOP); line.setShimmering(false);
            int rowH=dp(40);
            GreenCheckView check=new GreenCheckView(this); check.setColors(NEON_GREEN,Color.BLACK); check.setShimmering(false); line.addView(check,new LinearLayout.LayoutParams(dp(CHECK_ICON_DP),dp(CHECK_ICON_DP))); line.addView(hGap(compact?5:7));
            TextView kind=text(zip?"SOURCE":"WORKFLOW",compact?9:10,true); kind.setTextColor(Color.BLACK); kind.setGravity(Gravity.CENTER); kind.setBackground(round(NEON_GREEN,6));
            line.addView(kind,new LinearLayout.LayoutParams(dp(zip?64:82),compact?dp(18):dp(22))); line.addView(hGap(compact?5:7));
            ShimmerTextView t=shimmerText(f.name+(f.size>=0?"   "+human(f.size):""),compact?12:14,false); t.setShimmering(false); t.setIncludeFontPadding(false); t.setGravity(Gravity.TOP|Gravity.START); t.setPadding(0,dp(2),0,0); t.setSingleLine(true); t.setEllipsize(android.text.TextUtils.TruncateAt.END); line.addView(t,new LinearLayout.LayoutParams(0,rowH,1f));
            filesContent.addView(line,new LinearLayout.LayoutParams(-1,rowH));
        }
        renderSourceIdentity();
        renderSourcePrecheck();
        refreshBuildButtonState();
        refreshClearButtonState();
    }



    private static final class ExplorerStorage {
        final String label; final File root;
        ExplorerStorage(String label, File root){ this.label=label; this.root=root; }
    }

    private void showFileExplorer(){
        if(Build.VERSION.SDK_INT>=30 && !Environment.isExternalStorageManager()){
            pendingExplorerAfterPermission=true;
            try{
                Intent i=new Intent(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:"+getPackageName()));
                startActivity(i);
                toast("ファイル参照を許可するとDownloadを直接開けます");
            }catch(Exception e){
                try{ startActivity(new Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)); }
                catch(Exception ex){ DiagnosticLog.error("EXPLORER permission settings",ex); error(ex); }
            }
            return;
        }
        List<ExplorerStorage> storages=getExplorerStorages();
        if(storages.isEmpty()){ toast("利用できるストレージがありません"); return; }
        int initial=0;
        for(int i=0;i<storages.size();i++){
            if(storages.get(i).root!=null && storages.get(i).root.getAbsolutePath().contains("/emulated/0")){ initial=i; break; }
        }
        final ExplorerStorage[] active={storages.get(initial)};
        File download=new File(active[0].root,"Download");
        final File[] currentDir={download.isDirectory()?download:active[0].root};
        final SharedItem[] selectedZip={null};
        final SharedItem[] selectedYaml={null};

        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(14),dp(4),dp(14),dp(10)); box.setBackground(round(GRAY,12));
        TextView title=text("受信ファイルを選択",18,true); box.addView(title,new LinearLayout.LayoutParams(-1,dp(42)));

        Spinner storageSpinner=new Spinner(this);
        List<String> labels=new ArrayList<>(); for(ExplorerStorage st:storages) labels.add(st.label);
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,labels){
            @Override public View getView(int position, View convertView, android.view.ViewGroup parent){
                TextView v=(TextView)super.getView(position,convertView,parent); v.setTextColor(TEXT); v.setTextSize(16); v.setGravity(Gravity.CENTER_VERTICAL); v.setPadding(dp(10),0,dp(10),0); return v;
            }
            @Override public View getDropDownView(int position, View convertView, android.view.ViewGroup parent){
                TextView v=(TextView)super.getDropDownView(position,convertView,parent); v.setTextColor(TEXT); v.setTextSize(15); v.setBackgroundColor(DGRAY); v.setPadding(dp(12),0,dp(12),0); return v;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        storageSpinner.setAdapter(adapter); storageSpinner.setBackground(round(DGRAY,10));
        box.addView(storageSpinner,new LinearLayout.LayoutParams(-1,dp(CONTROL_HEIGHT_DP)));

        TextView pathView=text(currentDir[0].getAbsolutePath(),12,false); pathView.setTextColor(WHITE); pathView.setPadding(dp(2),dp(5),dp(2),dp(5)); box.addView(pathView,new LinearLayout.LayoutParams(-1,dp(34)));
        ScrollView scroll=new ScrollView(this); LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); scroll.addView(list,new ScrollView.LayoutParams(-1,-2)); box.addView(scroll,new LinearLayout.LayoutParams(-1,dp(360)));

        LinearLayout footer=row(); footer.setGravity(Gravity.CENTER_VERTICAL|Gravity.END); TextView count=text("0件選択",12,false); count.setTextColor(WHITE); footer.addView(count,new LinearLayout.LayoutParams(0,dp(CONTROL_HEIGHT_DP),1f));
        Button cancel=button("キャンセル",DGRAY), choose=button("選択",BLUE); choose.setEnabled(false); choose.setTextColor(WHITE); footer.addView(cancel,new LinearLayout.LayoutParams(dp(92),dp(CONTROL_HEIGHT_DP))); footer.addView(gap()); footer.addView(choose,new LinearLayout.LayoutParams(dp(76),dp(CONTROL_HEIGHT_DP))); box.addView(footer,new LinearLayout.LayoutParams(-1,dp(CONTROL_HEIGHT_DP)));

        AlertDialog dialog=new AlertDialog.Builder(this).setView(box).create();
        final int[] generation={0};
        final Runnable[] render={null};
        render[0]=()->{
            final File dir=currentDir[0];
            final int gen=++generation[0];
            pathView.setText(dir.getAbsolutePath());
            list.removeAllViews(); TextView loading=text("読み込み中…",13,false); loading.setTextColor(WHITE); loading.setPadding(dp(8),dp(12),dp(8),dp(12)); list.addView(loading);
            fileIo.execute(()->{
                List<File> folders=new ArrayList<>(), files=new ArrayList<>();
                try{
                    File[] entries=dir.listFiles();
                    if(entries!=null){
                        for(File f:entries){
                            if(f==null) continue;
                            if(f.isDirectory()) folders.add(f);
                            else if(isAcceptedInputName(f.getName())) files.add(f);
                        }
                    }
                    folders.sort((a,b)->a.getName().compareToIgnoreCase(b.getName())); files.sort((a,b)->{ long ta=explorerCreationTime(a), tb=explorerCreationTime(b); int byTime=Long.compare(tb,ta); return byTime!=0?byTime:a.getName().compareToIgnoreCase(b.getName()); });
                }catch(Throwable e){ DiagnosticLog.error("EXPLORER list path="+dir.getAbsolutePath(),new Exception(e)); }
                final List<File> ff=folders, fi=files;
                ui.post(()->{
                    if(!dialog.isShowing()||gen!=generation[0]||!samePath(currentDir[0],dir)) return;
                    list.removeAllViews();
                    File parent=dir.getParentFile();
                    if(parent!=null && isWithinStorage(parent,active[0].root)) list.addView(makeExplorerParentRow(()->{ currentDir[0]=parent; render[0].run(); }));
                    for(File folder:ff) list.addView(makeExplorerFolderRow(folder.getName(),()->{ currentDir[0]=folder; render[0].run(); }));
                    for(File file:fi){
                        String lower=file.getName().toLowerCase(Locale.ROOT); boolean zip=lower.endsWith(".zip");
                        SharedItem current=zip?selectedZip[0]:selectedYaml[0];
                        boolean selected=current!=null && Uri.fromFile(file).equals(current.uri);
                        boolean blocked=current!=null && !selected;
                        list.addView(makeExplorerFileRow(file,zip,selected,blocked,()->{
                            if(blocked) return;
                            if(zip){ selectedZip[0]=selected?null:new SharedItem(Uri.fromFile(file),file.getName(),file.length()); }
                            else { selectedYaml[0]=selected?null:new SharedItem(Uri.fromFile(file),file.getName(),file.length()); }
                            int c=(selectedZip[0]==null?0:1)+(selectedYaml[0]==null?0:1); count.setText(c+"件選択"); choose.setEnabled(c>0); choose.setTextColor(c>0?TEXT:WHITE); render[0].run();
                        }));
                    }
                    if(ff.isEmpty()&&fi.isEmpty()){
                        TextView empty=text("選択できるZIP / YAMLはありません",13,false); empty.setTextColor(WHITE); empty.setPadding(dp(8),dp(16),dp(8),dp(16)); list.addView(empty);
                    }
                });
            });
        };
        final int[] lastStoragePosition={initial};
        storageSpinner.setSelection(initial,false);
        storageSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(android.widget.AdapterView<?> parent,View view,int position,long id){
                if(position==lastStoragePosition[0]) return;
                lastStoragePosition[0]=position; active[0]=storages.get(position); currentDir[0]=active[0].root; DiagnosticLog.log("EXPLORER storage selected label="+active[0].label+" root="+active[0].root); render[0].run();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent){}
        });
        cancel.setOnClickListener(v->dialog.dismiss());
        choose.setOnClickListener(v->{
            ArrayList<SharedItem> picked=new ArrayList<>(); if(selectedZip[0]!=null)picked.add(selectedZip[0]); if(selectedYaml[0]!=null)picked.add(selectedYaml[0]);
            if(picked.isEmpty()){ toast("ZIPまたはYAMLを選択してください"); return; }
            clearSourceZipCache(); clearSelectedRepo("explorer"); shared.clear(); shared.addAll(picked); resetSourceAnalysisState(); refreshFiles(); scheduleSourceIdentityAnalysis(); dialog.dismiss();
            DiagnosticLog.log("EXPLORER selected files="+shared.size()+" zip="+(selectedZip[0]!=null)+" yaml="+(selectedYaml[0]!=null));
            maybeAutoSelectRepo("explorer");
        });
        dialog.setOnShowListener(v->{ styleNDialog(dialog); render[0].run(); });
        dialog.show(); if(dialog.getWindow()!=null) dialog.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels*0.94f),-2);
    }

    private long explorerCreationTime(File file){
        if(file==null) return 0L;
        try{
            BasicFileAttributes attrs=Files.readAttributes(file.toPath(),BasicFileAttributes.class);
            long created=attrs.creationTime().toMillis();
            if(created>0L) return created;
        }catch(Throwable ignored){}
        long modified=file.lastModified();
        return Math.max(0L,modified);
    }

    private List<ExplorerStorage> getExplorerStorages(){
        ArrayList<ExplorerStorage> out=new ArrayList<>();
        try{
            StorageManager sm=(StorageManager)getSystemService(STORAGE_SERVICE);
            if(sm!=null){
                for(StorageVolume v:sm.getStorageVolumes()){
                    if(v==null || !Environment.MEDIA_MOUNTED.equals(v.getState())) continue;
                    File root=null;
                    if(Build.VERSION.SDK_INT>=30) root=v.getDirectory();
                    if(root==null && v.isPrimary()) root=Environment.getExternalStorageDirectory();
                    if(root==null) continue;
                    String label=v.isPrimary()?"内蔵ストレージ":v.getDescription(this);
                    if(!notEmpty(label)) label=v.isRemovable()?"SDカード":"外部ストレージ";
                    out.add(new ExplorerStorage(label,root));
                }
            }
        }catch(Throwable e){ DiagnosticLog.error("EXPLORER storages",new Exception(e)); }
        if(out.isEmpty()) out.add(new ExplorerStorage("内蔵ストレージ",Environment.getExternalStorageDirectory()));
        return out;
    }

    private View makeExplorerParentRow(Runnable open){
        LinearLayout row=row(); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(4),0,dp(4),0); ImageView icon=new ImageView(this); icon.setImageResource(R.drawable.ic_folder); row.addView(icon,new LinearLayout.LayoutParams(dp(32),dp(32))); row.addView(hGap(8)); TextView t=text("..",14,false); row.addView(t,new LinearLayout.LayoutParams(0,dp(46),1f)); row.setOnClickListener(v->open.run()); return row;
    }
    private View makeExplorerFolderRow(String name,Runnable open){
        LinearLayout row=row(); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(4),0,dp(4),0); ImageView icon=new ImageView(this); icon.setImageResource(R.drawable.ic_folder); row.addView(icon,new LinearLayout.LayoutParams(dp(32),dp(32))); row.addView(hGap(8)); TextView t=text(name,14,false); row.addView(t,new LinearLayout.LayoutParams(0,dp(46),1f)); row.setOnClickListener(v->open.run()); return row;
    }
    private View makeExplorerFileRow(File file,boolean zip,boolean selected,boolean blocked,Runnable click){
        LinearLayout row=row(); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(8),0,dp(8),0); if(selected) row.setBackground(round(LBLUE,8)); row.setAlpha(blocked?0.32f:1f);
        TextView kind=text(zip?"ZIP":"YML",11,true); kind.setTextColor(WHITE); kind.setGravity(Gravity.CENTER); kind.setBackground(round(DGRAY,7)); row.addView(kind,new LinearLayout.LayoutParams(dp(44),dp(28))); row.addView(hGap(8));
        TextView name=text(file.getName(),14,false); name.setTextColor(blocked?WHITE:TEXT); row.addView(name,new LinearLayout.LayoutParams(0,dp(46),1f)); TextView size=text(human(file.length()),11,false); size.setTextColor(WHITE); size.setGravity(Gravity.END|Gravity.CENTER_VERTICAL); row.addView(size,new LinearLayout.LayoutParams(dp(66),dp(46))); row.setClickable(!blocked); if(!blocked) row.setOnClickListener(v->click.run()); return row;
    }
    private boolean isAcceptedInputName(String name){ if(name==null)return false; String n=name.toLowerCase(Locale.ROOT); return n.endsWith(".zip")||n.endsWith(".yml")||n.endsWith(".yaml"); }
    private boolean samePath(File a,File b){ try{return a.getCanonicalFile().equals(b.getCanonicalFile());}catch(Exception e){return a.getAbsolutePath().equals(b.getAbsolutePath());} }
    private boolean isWithinStorage(File candidate,File root){ try{String c=candidate.getCanonicalPath(),r=root.getCanonicalPath();return c.equals(r)||c.startsWith(r+File.separator);}catch(Exception e){return false;} }

    private boolean isConfigured(){ return notEmpty(store.getString("client_id")) && notEmpty(store.getSecret("client_secret")); }
    private boolean isLoggedIn(){ return notEmpty(store.getSecret("access_token")); }
    private void refreshAuthUi(){
        boolean logged=isLoggedIn();
        if(authCheck!=null){ authCheck.setVisibility(logged?View.VISIBLE:View.GONE); authCheck.setShimmering(false); }
        if(authText!=null){ authText.setTextColor(NEON_GREEN); authText.setShimmering(false); }
        if(authContent!=null) authContent.setShimmering(logged);
        if(authButton!=null){ authButton.setBackground(buttonBackground(LBLUE)); authButton.setTextColor(TEXT); }
        if(logged) { String login=store.getString("login"); authText.setText("ログイン中"+(notEmpty(login)?" : "+login:"")); authButton.setText("ログアウト"); }
        else if(notEmpty(store.getString("oauth_state"))) { authText.setText("GitHub認証処理中…"); authButton.setText("GitHubでログイン"); }
        else { authText.setText(isConfigured()?"未ログイン":"OAuth App未設定"); authButton.setText("GitHubでログイン"); }
    }

    private void showOAuthStateIfNeeded() {
        if(isLoggedIn()) return;
        String err=store.getString("oauth_last_error");
        if(notEmpty(err)) status("OAuthエラー\n"+err);
        else if(notEmpty(store.getString("oauth_state"))) status("GitHubログイン処理中…");
    }

    private void handleReturnIntent(Intent intent) {
        Uri d=intent==null?null:intent.getData();
        if(d==null || !"gitbuild".equalsIgnoreCase(d.getScheme()) || !"oauth".equalsIgnoreCase(d.getHost())) return;
        DiagnosticLog.log("OAUTH return intent path="+d.getPath()+" loggedIn="+isLoggedIn()+" lastError="+notEmpty(store.getString("oauth_last_error")));
        refreshAuthUi();
        if(isLoggedIn()) statusSuccess("GitHubログイン完了",false);
        else if(notEmpty(store.getString("oauth_last_error"))) status("OAuthエラー\n"+store.getString("oauth_last_error"));
        else status("GitHubログイン処理中…");
    }

    private void oauthSettingsDialog() {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(18),dp(4),dp(18),0);
        TextView info=text("GitHub OAuth Appを1つ作成し、下のRedirect URIを登録してください。GitHubのログイン名・パスワードではありません。PATも不要です。",13,false); info.setTextColor(WHITE); box.addView(info);
        TextView cb=text(CALLBACK_BASE,13,false); cb.setTextColor(TEXT); cb.setPadding(0,dp(10),0,dp(10)); cb.setTextIsSelectable(true); box.addView(cb);
        EditText id=input("Client ID", false); String oldId=store.getString("client_id"); if(oldId!=null)id.setText(oldId); box.addView(id,new LinearLayout.LayoutParams(-1,dp(CONTROL_HEIGHT_DP)));
        box.addView(space(8));
        EditText secret=input("Client Secret", true); String oldSecret=store.getSecret("client_secret"); if(oldSecret!=null)secret.setText(oldSecret); box.addView(secret,new LinearLayout.LayoutParams(-1,dp(CONTROL_HEIGHT_DP)));
        AlertDialog d=new AlertDialog.Builder(this).setTitle("OAuth設定").setView(box)
                .setNegativeButton("キャンセル",null)
                .setNeutralButton("OAuth App作成",null)
                .setPositiveButton("保存",null).create();
        d.setOnShowListener(x->{
            styleNDialog(d);
            d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->openUrl("https://github.com/settings/applications/new"));
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
                String nid=id.getText().toString().trim(), ns=secret.getText().toString().trim();
                if(nid.isEmpty()||ns.isEmpty()){toast("Client ID と Client Secret を入力してください");return;}
                try {
                    boolean changed=!nid.equals(store.getString("client_id")) || !ns.equals(store.getSecret("client_secret"));
                    DiagnosticLog.log("OAUTH settings save changed="+changed+" clientIdTail="+tail(nid,4)+" secretPresent="+(!ns.isEmpty()));
                    store.putString("client_id",nid); store.putSecret("client_secret",ns);
                    if(changed) { store.clearTokens(); store.clearOAuthPending(); store.remove("oauth_last_error"); }
                    refreshAuthUi(); d.dismiss(); toast("OAuth設定を保存しました");
                } catch(Exception e){error(e);}
            });
        }); d.show();
    }

    private void beginLogin() {
        DiagnosticLog.log("OAUTH begin configured="+isConfigured()+" loggedIn="+isLoggedIn());
        if(!isConfigured()){ DiagnosticLog.log("OAUTH begin blocked: not configured"); oauthSettingsDialog(); return; }
        try {
            if(oauthServer!=null) oauthServer.close();
            String state=randomUrlSafe(32), verifier=randomUrlSafe(64);
            String challenge=Base64.encodeToString(MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII)), Base64.URL_SAFE|Base64.NO_PADDING|Base64.NO_WRAP);
            oauthServer=new OAuthLoopbackServer(RETURN_URI,(code,returnedState,err)->ui.post(()->handleOAuthCallback(code,returnedState,err)));
            String redirect="http://127.0.0.1:"+oauthServer.port()+"/callback";
            DiagnosticLog.log("OAUTH loopback started port="+oauthServer.port()+" returnUri="+RETURN_URI);
            store.putString("oauth_state",state);
            store.putString("oauth_redirect",redirect);
            store.putSecret("oauth_verifier",verifier);
            store.putLong("oauth_started_at",System.currentTimeMillis());
            store.remove("oauth_last_error");
            String url="https://github.com/login/oauth/authorize?client_id="+enc(store.getString("client_id"))+
                    "&redirect_uri="+enc(redirect)+"&scope="+enc("repo workflow offline_access")+
                    "&state="+enc(state)+"&code_challenge="+enc(challenge)+"&code_challenge_method=S256&prompt=select_account";
            refreshAuthUi(); status("GitHub認証待ち…"); DiagnosticLog.log("OAUTH browser launch redirect="+redirect+" stateLen="+state.length()+" verifierLen="+verifier.length()); openUrl(url);
        } catch(Exception e){oauthFailure(e);}
    }

    private void handleOAuthCallback(String code,String state,String err) {
        String expected=store.getString("oauth_state");
        DiagnosticLog.log("OAUTH callback codePresent="+notEmpty(code)+" statePresent="+notEmpty(state)+" errorPresent="+notEmpty(err)+" expectedStatePresent="+notEmpty(expected));
        String redirect=store.getString("oauth_redirect");
        String verifier=store.getSecret("oauth_verifier");
        if(err!=null){oauthFailure(new Exception("OAuth: "+err));return;}
        if(code==null||state==null||!state.equals(expected)){ DiagnosticLog.log("OAUTH state validation failed match="+(state!=null&&state.equals(expected))); oauthFailure(new Exception("OAuth stateが一致しません"));return;}
        if(!notEmpty(redirect)||!notEmpty(verifier)){ DiagnosticLog.log("OAUTH pending session lost redirect="+notEmpty(redirect)+" verifier="+notEmpty(verifier)); oauthFailure(new Exception("OAuthセッション情報が失われました。もう一度ログインしてください"));return;}
        DiagnosticLog.log("OAUTH callback validated redirect="+redirect+" verifierPresent=true");
        status("GitHubログイン処理中…");
        io.execute(()->{ try {
            DiagnosticLog.log("OAUTH token exchange start clientIdTail="+tail(store.getString("client_id"),4));
            GitHubOAuth.TokenResult t=GitHubOAuth.exchange(store.getString("client_id"),store.getSecret("client_secret"),code,redirect,verifier);
            DiagnosticLog.log("OAUTH token exchange success refreshPresent="+notEmpty(t.refreshToken)+" accessExpiresAt="+t.accessExpiresAt);
            GitHubApi a=new GitHubApi(t.accessToken);
            DiagnosticLog.log("OAUTH /user lookup start");
            String login=a.getLogin();
            DiagnosticLog.log("OAUTH /user lookup success login="+login);
            saveTokens(t);
            store.putString("login",login);
            store.clearOAuthPending();
            store.remove("oauth_last_error");
            ui.post(()->{refreshAuthUi();statusSuccess("GitHubログイン完了",false);toast("GitHubにログインしました"); DiagnosticLog.log("OAUTH login completed"); maybeAutoSelectRepo("login");});
        } catch(Exception e){ui.post(()->oauthFailure(e));} });
    }

    private void oauthFailure(Exception e) {
        DiagnosticLog.error("OAUTH",e);
        String msg=e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();
        store.clearOAuthPending();
        store.putString("oauth_last_error",msg);
        refreshAuthUi();
        status("OAuthエラー\n"+msg);
    }

    private void logout(){ DiagnosticLog.log("AUTH logout"); store.clearTokens(); store.clearOAuthPending(); store.remove("oauth_last_error"); clearSelectedRepo("logout"); refreshAuthUi(); status("ログアウトしました"); }

    private void saveTokens(GitHubOAuth.TokenResult t) throws Exception {
        store.putSecret("access_token",t.accessToken); store.putLong("access_expires_at",t.accessExpiresAt);
        store.putSecret("refresh_token",t.refreshToken); store.putLong("refresh_expires_at",t.refreshExpiresAt);
    }

    private GitHubApi api() throws Exception {
        String token=store.getSecret("access_token"); if(!notEmpty(token)) throw new Exception("先に「GitHubでログイン」してください");
        long exp=store.getLong("access_expires_at",0); String refresh=store.getSecret("refresh_token");
        if(exp>0 && System.currentTimeMillis()>exp-300000L && notEmpty(refresh)) {
            DiagnosticLog.log("OAUTH access token refresh start");
            GitHubOAuth.TokenResult t=GitHubOAuth.refresh(store.getString("client_id"),store.getSecret("client_secret"),refresh); saveTokens(t); token=t.accessToken; DiagnosticLog.log("OAUTH access token refresh success");
        }
        return new GitHubApi(token);
    }


    private void clearSelectedRepo(String reason){
        selectedRepo=null;
        if(repoText!=null) repoText.setText("未選択");
        refreshRepoSelectionVisual();
        updateRenameRepoButton();
        refreshBuildButtonState();
        refreshClearButtonState();
        DiagnosticLog.log("REPO cleared reason="+reason);
    }

    private SharedItem sourceZipItem(){
        for(SharedItem item:shared){
            if(item!=null && item.name!=null && item.name.toLowerCase(Locale.ROOT).endsWith(".zip")) return item;
        }
        return null;
    }

    private SharedItem workflowItem(){
        for(SharedItem item:shared){
            if(item==null||item.name==null) continue;
            String n=item.name.toLowerCase(Locale.ROOT);
            if(n.endsWith(".yml")||n.endsWith(".yaml")) return item;
        }
        return null;
    }

    private SourceIdentity inspectReceivedIdentity(SharedItem source, SharedItem workflow) throws Exception {
        SourceIdentity sourceId=null, workflowId=null;
        Exception sourceError=null, workflowError=null;
        if(source!=null){
            try{ sourceId=inspectSourceIdentity(source); }catch(Exception e){ sourceError=e; }
        }
        if(workflow!=null){
            try{ workflowId=inspectWorkflowIdentity(workflow); }catch(Exception e){ workflowError=e; }
        }
        SourceIdentity merged=mergeSourceIdentity(sourceId,workflowId);
        if(merged!=null && !merged.candidates.isEmpty()) return merged;
        if(sourceError!=null) throw sourceError;
        if(workflowError!=null) throw workflowError;
        return merged==null?new SourceIdentity(new ArrayList<>(),null,null,null,null):merged;
    }

    private SourceIdentity mergeSourceIdentity(SourceIdentity primary, SourceIdentity secondary){
        if(primary==null) return secondary;
        if(secondary==null) return primary;
        LinkedHashSet<String> candidates=new LinkedHashSet<>();
        candidates.addAll(primary.candidates); candidates.addAll(secondary.candidates);
        return new SourceIdentity(new ArrayList<>(candidates),
                notEmpty(primary.appName)?primary.appName:secondary.appName,
                notEmpty(primary.projectName)?primary.projectName:secondary.projectName,
                notEmpty(primary.versionName)?primary.versionName:secondary.versionName,
                notEmpty(primary.packageName)?primary.packageName:secondary.packageName);
    }

    private SourceIdentity inspectWorkflowIdentity(SharedItem workflow) throws Exception {
        InputStream raw=getContentResolver().openInputStream(workflow.uri);
        if(raw==null) throw new Exception("workflow YAMLを開けません");
        String yaml;
        try(InputStream in=raw){ yaml=readText(in,1024*1024); }
        if(!yaml.isEmpty() && yaml.charAt(0)=='\uFEFF') yaml=yaml.substring(1);
        LinkedHashSet<String> candidates=new LinkedHashSet<>();

        // Explicit repository/app metadata is the strongest hint and must stay first.
        Matcher explicit=Pattern.compile("(?im)^\\s*(?:REPO_NAME|PROJECT_NAME|APP_NAME)\\s*:\\s*[\"']?([^\\r\\n#\"']{2,120})").matcher(yaml);
        while(explicit.find()) addWorkflowCandidate(candidates,explicit.group(1));

        Matcher repo=Pattern.compile("(?im)^\\s*repository\\s*:\\s*[\"']?([^\\s\"'#]+/[^\\s\"'#]+)").matcher(yaml);
        while(repo.find()){
            String full=repo.group(1); int slash=full.lastIndexOf('/');
            addWorkflowCandidate(candidates,slash>=0?full.substring(slash+1):full);
        }

        // Prefer the workflow-level name before filename and step-name fallbacks.
        Matcher workflowName=Pattern.compile("(?im)^name\\s*:\\s*[\"']?([^\\r\\n#\"']{3,100})").matcher(yaml);
        if(workflowName.find()) addWorkflowCandidate(candidates,workflowName.group(1));

        // A descriptive incoming filename may also identify the repository. Generic build-apk.yml is filtered below.
        addWorkflowCandidate(candidates,workflow.name);

        Matcher file=Pattern.compile("(?i)([A-Za-z0-9][A-Za-z0-9._${}-]{2,120})\\.(?:apk|zip)").matcher(yaml);
        while(file.find()) addWorkflowCandidate(candidates,file.group(1));

        Matcher name=Pattern.compile("(?im)^\\s*name\\s*:\\s*[\"']?([^\\r\\n#\"']{3,100})").matcher(yaml);
        int nameCount=0;
        while(name.find() && nameCount<8){ addWorkflowCandidate(candidates,name.group(1)); nameCount++; }

        Matcher wd=Pattern.compile("(?im)^\\s*working-directory\\s*:\\s*[\"']?([^\\r\\n#\"']{2,160})").matcher(yaml);
        while(wd.find()){
            String v=wd.group(1).trim().replace('\\','/'); int slash=v.lastIndexOf('/');
            addWorkflowCandidate(candidates,slash>=0?v.substring(slash+1):v);
        }

        Matcher env=Pattern.compile("(?im)^\\s*(?:ARTIFACT_NAME|APK_NAME)\\s*:\\s*[\"']?([^\\r\\n#\"']{2,120})").matcher(yaml);
        while(env.find()) addWorkflowCandidate(candidates,env.group(1));

        String best=candidates.isEmpty()?null:candidates.iterator().next();
        DiagnosticLog.log("YAML identity file="+workflow.name+" candidates="+candidates);
        return new SourceIdentity(new ArrayList<>(candidates),best,null,null,null);
    }

    private static void addWorkflowCandidate(LinkedHashSet<String> out,String raw){
        if(raw==null)return; String v=raw.trim();
        v=v.replaceAll("\\$\\{\\{.*?}}","").replaceAll("\\$\\{[^}]+}","").trim();
        v=v.replaceAll("(?i)\\.(?:apk|zip|ya?ml)$","");
        v=v.replaceAll("(?i)^build[-_ ]+","");
        v=v.replaceAll("(?i)(?:[-_ ]+(?:apk|android|build|workflow|artifact|debug|release|unsigned|signed))+$","");
        v=v.replaceAll("[-_ .]+$","");
        v=v.replaceAll("^[\"']+|[\"']+$","").trim();
        if(v.length()<3 || v.length()>100) return;
        String n=normalizeRepoName(v);
        if(n.length()<3) return;
        if(n.equals("build")||n.equals("androidbuild")||n.equals("buildapk")||n.equals("uploadartifact")||n.equals("artifact")) return;
        out.add(v);
    }

    private static String readText(InputStream in,int maxBytes) throws Exception {
        ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] b=new byte[8192]; int n,total=0;
        while((n=in.read(b))!=-1){ if(n<=0)continue; int use=Math.min(n,maxBytes-total); if(use>0)out.write(b,0,use); total+=n; if(total>=maxBytes)break; }
        return out.toString(StandardCharsets.UTF_8.name());
    }

    private static final class SourceIdentity {
        final List<String> candidates; final String appName; final String projectName; final String versionName; final String packageName;
        SourceIdentity(List<String> candidates,String appName,String projectName,String versionName,String packageName){
            this.candidates=candidates; this.appName=appName; this.projectName=projectName; this.versionName=versionName; this.packageName=packageName;
        }
    }
    private static final class PrecheckResult {
        final int level; final String summary; final String details;
        PrecheckResult(int level,String summary,String details){ this.level=level; this.summary=summary; this.details=details; }
    }

    private static final class RepoMatch {
        final GitHubApi.Repo repo; final double score; final String candidate;
        RepoMatch(GitHubApi.Repo repo,double score,String candidate){this.repo=repo;this.score=score;this.candidate=candidate;}
    }

    private void maybeAutoSelectRepo(String origin){
        if(autoRepoSwitch==null || !autoRepoSwitch.isChecked()){
            DiagnosticLog.log("REPO auto-match skipped toggle off origin="+origin); return;
        }
        if(selectedRepo!=null){ DiagnosticLog.log("REPO auto-match skipped already selected origin="+origin); return; }
        if(!isLoggedIn()){ DiagnosticLog.log("REPO auto-match deferred not logged in origin="+origin); return; }
        final SharedItem source=sourceZipItem();
        final SharedItem workflow=workflowItem();
        if(source==null && workflow==null){ DiagnosticLog.log("REPO auto-match skipped no received file origin="+origin); return; }
        final Uri expectedSource=source==null?null:source.uri;
        final Uri expectedWorkflow=workflow==null?null:workflow.uri;
        DiagnosticLog.log("REPO auto-match start origin="+origin+" source="+(source==null?"none":source.name)+" workflow="+(workflow==null?"none":workflow.name));
        io.execute(()->{
            try{
                SourceIdentity identity=inspectReceivedIdentity(source,workflow);
                DiagnosticLog.log("REPO auto-match received candidates="+identity.candidates+" version="+identity.versionName);
                if(identity.candidates.isEmpty()) return;
                List<GitHubApi.Repo> repos=api().listRepos();
                RepoMatch match=findRepoMatch(identity.candidates,repos);
                if(match==null){ DiagnosticLog.log("REPO auto-match no confident match"); return; }
                ui.post(()->{
                    if(selectedRepo!=null) return;
                    SharedItem nowSource=sourceZipItem(), nowWorkflow=workflowItem();
                    Uri nowSourceUri=nowSource==null?null:nowSource.uri, nowWorkflowUri=nowWorkflow==null?null:nowWorkflow.uri;
                    if(!Objects.equals(expectedSource,nowSourceUri)||!Objects.equals(expectedWorkflow,nowWorkflowUri)) return;
                    if(autoRepoSwitch==null || !autoRepoSwitch.isChecked()) return;
                    selectedRepo=match.repo;
                    repoText.setText(match.repo.fullName);
                    refreshRepoSelectionVisual();
                    updateRenameRepoButton();
                    refreshBuildButtonState();
                    refreshClearButtonState();
                    DiagnosticLog.log("REPO auto-match selected "+match.repo.fullName+" score="+String.format(Locale.US,"%.3f",match.score)+" candidate="+match.candidate);
                });
            }catch(Exception e){ DiagnosticLog.error("REPO auto-match",e); }
        });
    }

    private SourceIdentity inspectSourceIdentity(SharedItem source) throws Exception {
        String manifest=null, strings=null, settingsText=null, gradle=null;
        InputStream raw=getContentResolver().openInputStream(source.uri);
        if(raw==null) throw new Exception("source ZIPを開けません");
        try(InputStream input=raw; ZipInputStream zin=new ZipInputStream(input)){
            ZipEntry e;
            while((e=zin.getNextEntry())!=null){
                if(e.isDirectory()){zin.closeEntry();continue;}
                String n=e.getName().replace('\\','/').toLowerCase(Locale.ROOT);
                boolean want=n.endsWith("/app/src/main/androidmanifest.xml")||n.equals("app/src/main/androidmanifest.xml")||
                        n.endsWith("/app/src/main/res/values/strings.xml")||n.equals("app/src/main/res/values/strings.xml")||
                        n.endsWith("/settings.gradle")||n.equals("settings.gradle")||n.endsWith("/settings.gradle.kts")||n.equals("settings.gradle.kts")||
                        n.endsWith("/app/build.gradle")||n.equals("app/build.gradle")||n.endsWith("/app/build.gradle.kts")||n.equals("app/build.gradle.kts");
                if(want){
                    String text=readZipText(zin,1024*1024);
                    if(n.endsWith("androidmanifest.xml") && manifest==null) manifest=text;
                    else if(n.endsWith("res/values/strings.xml") && strings==null) strings=text;
                    else if((n.endsWith("settings.gradle")||n.endsWith("settings.gradle.kts")) && settingsText==null) settingsText=text;
                    else if((n.endsWith("app/build.gradle")||n.endsWith("app/build.gradle.kts")) && gradle==null) gradle=text;
                }
                zin.closeEntry();
            }
        }
        LinkedHashSet<String> candidates=new LinkedHashSet<>();
        String label=findGroup(manifest,"android:label\\s*=\\s*[\\\"']([^\\\"']+)[\\\"']");
        if(label!=null && label.startsWith("@string/")){
            String key=label.substring("@string/".length());
            String resolved=findXmlString(strings,key); if(notEmpty(resolved)) label=resolved;
        }
        if(notEmpty(label) && !label.startsWith("@")) candidates.add(label.trim());
        String project=findGroup(settingsText,"rootProject\\.name\\s*=\\s*[\\\"']([^\\\"']+)[\\\"']");
        if(notEmpty(project)) candidates.add(project.trim());
        String appId=findGroup(gradle,"\\bapplicationId\\s*(?:=\\s*)?[\\\"']([^\\\"']+)[\\\"']");
        String namespace=findGroup(gradle,"\\bnamespace\\s*(?:=\\s*)?[\\\"']([^\\\"']+)[\\\"']");
        if(notEmpty(appId)) candidates.add(lastPackagePart(appId));
        if(notEmpty(namespace)) candidates.add(lastPackagePart(namespace));
        String version=findGroup(gradle,"\\bversionName\\s*(?:=\\s*)?[\\\"']([^\\\"']+)[\\\"']");
        String appName=notEmpty(label)&&!label.startsWith("@")?label.trim():(notEmpty(project)?project.trim():(notEmpty(appId)?lastPackagePart(appId):lastPackagePart(namespace)));
        String packageName=notEmpty(appId)?appId:namespace;
        return new SourceIdentity(new ArrayList<>(candidates),appName,project,version,packageName);
    }

    private static String readZipText(ZipInputStream zin,int maxBytes) throws Exception{
        ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] b=new byte[8192]; int n,total=0;
        while((n=zin.read(b))!=-1){ if(n<=0)continue; int use=Math.min(n,maxBytes-total); if(use>0)out.write(b,0,use); total+=n; if(total>=maxBytes)break; }
        return out.toString(StandardCharsets.UTF_8.name());
    }
    private static String findGroup(String text,String regex){
        if(text==null)return null; Matcher m=Pattern.compile(regex,Pattern.CASE_INSENSITIVE|Pattern.MULTILINE|Pattern.DOTALL).matcher(text); return m.find()?m.group(1):null;
    }
    private static String findXmlString(String xml,String key){
        if(xml==null||key==null)return null;
        String q=Pattern.quote(key); Matcher m=Pattern.compile("<string\\s+name\\s*=\\s*[\\\"']"+q+"[\\\"'][^>]*>(.*?)</string>",Pattern.CASE_INSENSITIVE|Pattern.DOTALL).matcher(xml);
        if(!m.find())return null; String v=m.group(1).replaceAll("<[^>]+>","").trim(); return v.replace("&amp;","&").replace("&lt;","<").replace("&gt;",">").replace("&quot;","\"").replace("&apos;","'");
    }
    private static String lastPackagePart(String s){ if(s==null)return null; int i=s.lastIndexOf('.'); return i>=0&&i+1<s.length()?s.substring(i+1):s; }

    private void scheduleSourceIdentityAnalysis(){
        SharedItem source=sourceZipItem();
        SharedItem workflow=workflowItem();
        if(source==null && workflow==null){
            lastSourceIdentity=null; lastSourceIdentityUri=null; sourceIdentityPending=false;
            lastPrecheckResult=null; lastPrecheckUri=null; sourcePrecheckPending=false;
            renderSourceIdentity(); renderSourcePrecheck(); refreshBuildButtonState(); return;
        }
        final Uri expectedSource=source==null?null:source.uri;
        final Uri expectedWorkflow=workflow==null?null:workflow.uri;
        sourceIdentityPending=true; sourcePrecheckPending=source!=null;
        lastSourceIdentity=null; lastSourceIdentityUri=null;
        lastPrecheckResult=null; lastPrecheckUri=null;
        renderSourceIdentity(); renderSourcePrecheck(); refreshBuildButtonState();
        fileIo.execute(()->{
            SourceIdentity id=null; PrecheckResult precheck=null;
            Exception identityError=null;
            try{ id=inspectReceivedIdentity(source,workflow); }
            catch(Exception e){ identityError=e; DiagnosticLog.error("SOURCE identity",e); }
            if(source!=null){
                try{ precheck=inspectSourcePrecheck(source); }
                catch(Exception e){
                    DiagnosticLog.error("SOURCE precheck",e);
                    String msg=e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();
                    precheck=new PrecheckResult(PRECHECK_ERROR,"エラー 1件","結果: エラー\n\n[エラー]\n・プリチェックを完了できませんでした: "+msg+"\n\nGradleの実ビルドはまだ実行していません。");
                }
            }
            final SourceIdentity resultId=id;
            final PrecheckResult resultPrecheck=precheck;
            final Exception resultIdentityError=identityError;
            ui.post(()->{
                SharedItem nowSource=sourceZipItem(), nowWorkflow=workflowItem();
                Uri nowSourceUri=nowSource==null?null:nowSource.uri, nowWorkflowUri=nowWorkflow==null?null:nowWorkflow.uri;
                if(!Objects.equals(expectedSource,nowSourceUri)||!Objects.equals(expectedWorkflow,nowWorkflowUri)) return;
                lastSourceIdentity=resultId; lastSourceIdentityUri=expectedSource!=null?expectedSource:expectedWorkflow; sourceIdentityPending=false;
                lastPrecheckResult=resultPrecheck; lastPrecheckUri=expectedSource; sourcePrecheckPending=false;
                if(resultId!=null) DiagnosticLog.log("SOURCE identity app="+resultId.appName+" version="+resultId.versionName+" package="+resultId.packageName+" project="+resultId.projectName+" candidates="+resultId.candidates);
                else if(resultIdentityError!=null) DiagnosticLog.log("SOURCE identity unavailable after error");
                if(resultPrecheck!=null) DiagnosticLog.log("SOURCE precheck level="+resultPrecheck.level+" summary="+resultPrecheck.summary);
                renderSourceIdentity(); renderSourcePrecheck(); refreshBuildButtonState();
                if(autoRepoSwitch!=null && autoRepoSwitch.isChecked() && selectedRepo==null) maybeAutoSelectRepo("analysis_complete");
            });
        });
    }

    private void renderSourceIdentity(){
        if(sourceIdentityText==null) return;
        SharedItem source=sourceZipItem();
        SharedItem workflow=workflowItem();
        if(source==null && workflow==null){ sourceIdentityText.setVisibility(View.GONE); return; }
        sourceIdentityText.setVisibility(View.VISIBLE);
        if(sourceIdentityPending){ sourceIdentityText.setText(source!=null?"受信ファイル解析中…":"YAML解析中…"); return; }
        SourceIdentity id=lastSourceIdentity;
        if(id==null){ sourceIdentityText.setText(source!=null?"source.zip: アプリ情報を取得できませんでした":"YAML: リポジトリ候補を取得できませんでした"); return; }
        if(source==null){
            String candidate=id.candidates.isEmpty()?"候補なし":id.candidates.get(0);
            sourceIdentityText.setText("YAML: リポジトリ候補 "+candidate);
            return;
        }
        ArrayList<String> parts=new ArrayList<>();
        if(notEmpty(id.appName)) parts.add(id.appName);
        if(notEmpty(id.versionName)) parts.add(id.versionName);
        if(notEmpty(id.packageName)) parts.add(id.packageName);
        sourceIdentityText.setText("source.zip: "+(parts.isEmpty()?"解析済み":String.join(" / ",parts)));
    }

    private void renderSourcePrecheck(){
        if(sourcePrecheckText==null) return;
        SharedItem source=sourceZipItem();
        if(source==null){ sourcePrecheckText.setVisibility(View.GONE); return; }
        sourcePrecheckText.setVisibility(View.VISIBLE);
        sourcePrecheckText.setTextColor(NEON_GREEN);
        if(sourcePrecheckPending){ sourcePrecheckText.setText("プリチェック: 確認中…"); return; }
        PrecheckResult r=currentPrecheckResult();
        if(r==null){ sourcePrecheckText.setText("プリチェック: 未完了"); return; }
        String suffix=r.level==PRECHECK_OK?"":"  （タップで詳細）";
        sourcePrecheckText.setText("プリチェック: "+r.summary+suffix);
    }

    private PrecheckResult currentPrecheckResult(){
        SharedItem source=sourceZipItem();
        if(source==null||source.uri==null||lastPrecheckUri==null||!source.uri.equals(lastPrecheckUri)) return null;
        return lastPrecheckResult;
    }

    private boolean precheckBlocksBuild(){
        if(sourcePrecheckPending) return true;
        PrecheckResult r=currentPrecheckResult();
        return r!=null && r.level==PRECHECK_ERROR;
    }

    private void showPrecheckDetails(){
        PrecheckResult r=currentPrecheckResult();
        if(sourcePrecheckPending){ toast("プリチェック中です"); return; }
        if(r==null){ toast("プリチェック結果がありません"); return; }
        AlertDialog d=new AlertDialog.Builder(this).setTitle("ビルド前プリチェック: "+r.summary).setMessage(r.details).setPositiveButton("閉じる",null).create(); d.show(); styleNDialog(d);
    }

    private void resetSourceAnalysisState(){
        lastSourceIdentity=null; lastSourceIdentityUri=null; sourceIdentityPending=false;
        lastPrecheckResult=null; lastPrecheckUri=null; sourcePrecheckPending=false;
        renderSourceIdentity(); renderSourcePrecheck(); refreshBuildButtonState();
    }

    private PrecheckResult inspectSourcePrecheck(SharedItem source) throws Exception {
        ArrayList<String> errors=new ArrayList<>(), warnings=new ArrayList<>(), info=new ArrayList<>();
        LinkedHashSet<String> names=new LinkedHashSet<>();
        HashMap<String,String> lowerToActual=new HashMap<>();
        HashMap<String,String> textByLower=new HashMap<>();
        long totalBytes=0L; int entryCount=0;
        InputStream raw=getContentResolver().openInputStream(source.uri);
        if(raw==null) throw new Exception("source ZIPを開けません");
        try(InputStream input=raw; ZipInputStream zin=new ZipInputStream(input)){
            ZipEntry e; byte[] buf=new byte[8192];
            while((e=zin.getNextEntry())!=null){
                entryCount++;
                if(entryCount>20000) throw new Exception("ZIP内の項目数が多すぎます（20,000件超）");
                String normalized=normalizeZipEntryPath(e.getName());
                if(normalized==null){ errors.add("ZIP内に不正なパスがあります: "+e.getName()); normalized=e.getName()==null?"":e.getName().replace('\\','/'); }
                String lower=normalized.toLowerCase(Locale.ROOT);
                if(!e.isDirectory()){
                    if(lowerToActual.containsKey(lower)) warnings.add("大文字小文字だけが異なる重複パスがあります: "+normalized);
                    names.add(normalized); lowerToActual.put(lower,normalized);
                    boolean capture=isPrecheckTextName(lower);
                    ByteArrayOutputStream out=capture?new ByteArrayOutputStream():null;
                    int n; long entryBytes=0L;
                    while((n=zin.read(buf))!=-1){
                        if(n<=0) continue;
                        totalBytes+=n; entryBytes+=n;
                        if(totalBytes>768L*1024L*1024L) throw new Exception("展開サイズが大きすぎます（768MB超）");
                        if(capture && out.size()<2*1024*1024){ int use=Math.min(n,2*1024*1024-out.size()); if(use>0) out.write(buf,0,use); }
                    }
                    if(capture) textByLower.put(lower,out.toString(StandardCharsets.UTF_8.name()));
                    if(entryBytes>256L*1024L*1024L) warnings.add("非常に大きいファイルがあります: "+normalized);
                }
                zin.closeEntry();
            }
        }
        if(entryCount==0 || names.isEmpty()) errors.add("ZIPにファイルが入っていません");
        info.add("ZIP: "+entryCount+"項目 / 展開約"+humanBytes(totalBytes));

        ArrayList<String> settingsPaths=new ArrayList<>();
        for(String n:names){ String l=n.toLowerCase(Locale.ROOT); if(l.endsWith("settings.gradle")||l.endsWith("settings.gradle.kts")) settingsPaths.add(l); }
        String settingsPath=null, rootDir="";
        if(settingsPaths.isEmpty()) errors.add("settings.gradle / settings.gradle.kts が見つかりません");
        else{
            settingsPaths.sort((a,b)->{ int da=pathDepth(a), db=pathDepth(b); return da!=db?Integer.compare(da,db):Integer.compare(a.length(),b.length()); });
            settingsPath=settingsPaths.get(0); rootDir=parentZipPath(settingsPath);
            if(settingsPaths.size()>1) warnings.add("settings.gradle が複数あります。最上位のものを対象にしました");
            info.add("Project root: "+(rootDir.isEmpty()?"/":"/"+rootDir));
        }
        String prefix=rootDir.isEmpty()?"":rootDir+"/";
        String settingsText=settingsPath==null?null:textByLower.get(settingsPath);
        boolean rootBuild=lowerToActual.containsKey(prefix+"build.gradle")||lowerToActual.containsKey(prefix+"build.gradle.kts");
        if(settingsPath!=null && !rootBuild) warnings.add("プロジェクト直下の build.gradle(.kts) が見つかりません");

        ArrayList<String> moduleBuilds=new ArrayList<>();
        if(settingsPath!=null){
            for(String n:names){
                String l=n.toLowerCase(Locale.ROOT);
                if(!l.startsWith(prefix)) continue;
                String rel=l.substring(prefix.length());
                if(!rel.contains("/")) continue;
                if(rel.endsWith("/build.gradle")||rel.endsWith("/build.gradle.kts")) moduleBuilds.add(l);
            }
        }
        String moduleBuild=null; boolean pluginVerified=false;
        for(String b:moduleBuilds){
            String t=textByLower.get(b);
            if(isAndroidApplicationGradle(t)){
                if(moduleBuild==null || parentZipPath(b).endsWith("/app") || "app".equals(parentZipPath(b))){ moduleBuild=b; pluginVerified=true; }
                if(parentZipPath(b).endsWith("/app") || "app".equals(parentZipPath(b))) break;
            }
        }
        if(moduleBuild==null){
            for(String b:moduleBuilds){ String dir=parentZipPath(b); if((dir.endsWith("/app")||"app".equals(dir)||dir.equals(prefix+"app"))){ moduleBuild=b; break; } }
            if(moduleBuild!=null) warnings.add("Android applicationプラグインを直接確認できません（version catalog等の可能性）");
        }
        if(moduleBuild==null){
            for(String b:moduleBuilds){ String manifest=parentZipPath(b)+"/src/main/androidmanifest.xml"; if(lowerToActual.containsKey(manifest)){ moduleBuild=b; warnings.add("applicationモジュールを推定しました: "+parentZipPath(b)); break; } }
        }
        if(moduleBuild==null) errors.add("Android applicationモジュールの build.gradle(.kts) が見つかりません");

        String moduleDir=moduleBuild==null?null:parentZipPath(moduleBuild);
        String gradle=moduleBuild==null?null:textByLower.get(moduleBuild);
        if(moduleDir!=null){
            info.add("Module: /"+moduleDir+(pluginVerified?"":" (推定)"));
            String manifestPath=moduleDir+"/src/main/androidmanifest.xml";
            if(!lowerToActual.containsKey(manifestPath)) errors.add("AndroidManifest.xml が見つかりません: /"+manifestPath);
            else{
                String manifest=textByLower.get(manifestPath);
                if(manifest==null || !manifest.toLowerCase(Locale.ROOT).contains("<manifest")) errors.add("AndroidManifest.xml を正しく読めません");
            }
            if(settingsText!=null){
                String moduleName=moduleDir.substring(moduleDir.lastIndexOf('/')+1);
                if(!settingsMentionsModule(settingsText,moduleName)) warnings.add("settings.gradle でモジュール '"+moduleName+"' の include を確認できません");
            }
        }

        if(gradle!=null){
            String compile=findGroup(gradle,"\\bcompileSdk(?:Version)?\\s*(?:=\\s*)?(\\d+)");
            if(notEmpty(compile)){
                try{ int sdk=Integer.parseInt(compile); info.add("compileSdk: "+sdk); if(sdk>36) errors.add("compileSdk "+sdk+" は現在のGitBuild環境（SDK 36）を超えています"); }
                catch(Exception ignored){ warnings.add("compileSdkを数値として判定できません"); }
            }else warnings.add("compileSdkを静的に判定できません");
            String appId=findGroup(gradle,"\\bapplicationId\\s*(?:=\\s*)?[\\\"']([^\\\"']+)[\\\"']");
            String namespace=findGroup(gradle,"\\bnamespace\\s*(?:=\\s*)?[\\\"']([^\\\"']+)[\\\"']");
            String versionName=findGroup(gradle,"\\bversionName\\s*(?:=\\s*)?[\\\"']([^\\\"']+)[\\\"']");
            String versionCode=findGroup(gradle,"\\bversionCode\\s*(?:=\\s*)?(\\d+)");
            if(notEmpty(appId)) info.add("applicationId: "+appId); else if(notEmpty(namespace)) info.add("namespace: "+namespace); else warnings.add("applicationId / namespaceを静的に判定できません");
            if(notEmpty(versionName)) info.add("versionName: "+versionName); else warnings.add("versionNameを静的に判定できません");
            if(notEmpty(versionCode)) info.add("versionCode: "+versionCode);

            Matcher sm=Pattern.compile("storeFile\\s*(?:=\\s*)?(?:file\\s*\\(\\s*)?[\\\"']([^\\\"']+)[\\\"']",Pattern.CASE_INSENSITIVE).matcher(gradle);
            while(sm.find()){
                String ref=sm.group(1).trim();
                if(ref.contains("$")||ref.contains("(")){ warnings.add("署名ファイルの参照を静的に確認できません: "+ref); continue; }
                String resolved=resolveZipRelativePath(moduleDir,ref);
                if(resolved==null){ errors.add("署名ファイルのパスがプロジェクト外を指しています: "+ref); continue; }
                if(!lowerToActual.containsKey(resolved.toLowerCase(Locale.ROOT))){
                    if(Pattern.compile("\\bsigningConfig\\b",Pattern.CASE_INSENSITIVE).matcher(gradle).find()) errors.add("参照される署名ファイルがZIP内にありません: "+ref);
                    else warnings.add("署名ファイルがZIP内にありません: "+ref);
                }else info.add("Signing file: /"+resolved);
            }
        }

        int level=!errors.isEmpty()?PRECHECK_ERROR:(!warnings.isEmpty()?PRECHECK_WARNING:PRECHECK_OK);
        String summary=level==PRECHECK_ERROR?"エラー "+errors.size()+"件":(level==PRECHECK_WARNING?"警告 "+warnings.size()+"件":"OK");
        StringBuilder detail=new StringBuilder("結果: ").append(summary).append("\n");
        if(!errors.isEmpty()){ detail.append("\n[エラー]\n"); for(String x:errors) detail.append("・").append(x).append("\n"); }
        if(!warnings.isEmpty()){ detail.append("\n[警告]\n"); for(String x:warnings) detail.append("・").append(x).append("\n"); }
        if(!info.isEmpty()){ detail.append("\n[確認]\n"); for(String x:info) detail.append("・").append(x).append("\n"); }
        detail.append("\n※ 依存関係の解決やGradleタスク実行時にだけ判明するエラーまでは、このプリチェックでは保証できません。");
        return new PrecheckResult(level,summary,detail.toString());
    }

    private static boolean isPrecheckTextName(String lower){
        return lower.endsWith("settings.gradle")||lower.endsWith("settings.gradle.kts")||lower.endsWith("build.gradle")||lower.endsWith("build.gradle.kts")||lower.endsWith("androidmanifest.xml")||lower.endsWith("gradle.properties");
    }
    private static String normalizeZipEntryPath(String raw){
        if(raw==null) return null; String s=raw.replace('\\','/');
        while(s.startsWith("./")) s=s.substring(2);
        if(s.startsWith("/")||s.matches("^[A-Za-z]:.*")) return null;
        StringBuilder out=new StringBuilder();
        for(String part:s.split("/")){ if(part.isEmpty()||".".equals(part)) continue; if("..".equals(part)) return null; if(out.length()>0) out.append('/'); out.append(part); }
        return out.toString();
    }
    private static int pathDepth(String p){ if(p==null||p.isEmpty()) return 0; int n=0; for(int i=0;i<p.length();i++) if(p.charAt(i)=='/') n++; return n; }
    private static String parentZipPath(String p){ if(p==null)return ""; int i=p.lastIndexOf('/'); return i<0?"":p.substring(0,i); }
    private static boolean isAndroidApplicationGradle(String text){
        if(text==null)return false; String l=text.toLowerCase(Locale.ROOT); return l.contains("com.android.application")||l.contains("android.application");
    }
    private static boolean settingsMentionsModule(String settings,String module){
        if(settings==null||module==null)return false; String q=Pattern.quote(module); return Pattern.compile("include\\s*(?:\\(|\\s).*?[\\\"']:?"+q+"[\\\"']",Pattern.CASE_INSENSITIVE|Pattern.DOTALL).matcher(settings).find();
    }
    private static String resolveZipRelativePath(String base,String rel){
        if(rel==null)return null; String r=rel.replace('\\','/'); if(r.startsWith("/")||r.matches("^[A-Za-z]:.*"))return null;
        ArrayDeque<String> stack=new ArrayDeque<>();
        if(base!=null&&!base.isEmpty()) for(String p:base.split("/")) if(!p.isEmpty()) stack.addLast(p);
        for(String p:r.split("/")){ if(p.isEmpty()||".".equals(p))continue; if("..".equals(p)){ if(stack.isEmpty())return null; stack.removeLast(); } else stack.addLast(p); }
        return String.join("/",stack);
    }
    private static String humanBytes(long bytes){
        if(bytes<1024)return bytes+"B"; double v=bytes/1024d; if(v<1024)return String.format(Locale.US,"%.1fKB",v); v/=1024d; return String.format(Locale.US,"%.1fMB",v);
    }

    private double selectedRepoSourceSimilarity(){
        if(selectedRepo==null||lastSourceIdentity==null||lastSourceIdentity.candidates.isEmpty()) return 1d;
        String full=selectedRepo.fullName; int slash=full.lastIndexOf('/'); String repoName=slash>=0?full.substring(slash+1):full;
        double best=0d; for(String c:lastSourceIdentity.candidates) best=Math.max(best,repoSimilarity(c,repoName));
        return best;
    }

    private RepoMatch findRepoMatch(List<String> candidates,List<GitHubApi.Repo> repos){
        RepoMatch best=null, second=null;
        for(GitHubApi.Repo repo:repos){
            String full=repo.fullName; int slash=full.lastIndexOf('/'); String repoName=slash>=0?full.substring(slash+1):full;
            double repoBest=-1d; String repoCandidate=null;
            for(String candidate:candidates){
                double score=repoSimilarity(candidate,repoName);
                if(score>repoBest){ repoBest=score; repoCandidate=candidate; }
            }
            RepoMatch rm=new RepoMatch(repo,repoBest,repoCandidate);
            if(best==null || rm.score>best.score){ second=best; best=rm; }
            else if(second==null || rm.score>second.score) second=rm;
        }
        if(best==null || best.score<0.82d) return null;
        if(best.score<0.97d && second!=null && best.score-second.score<0.04d) return null;
        return best;
    }
    private static double repoSimilarity(String a,String b){
        String x=normalizeRepoName(a),y=normalizeRepoName(b); if(x.isEmpty()||y.isEmpty())return 0d; if(x.equals(y))return 1d;
        if((x.contains(y)||y.contains(x)) && Math.min(x.length(),y.length())>=4) return 0.92d;
        int d=levenshtein(x,y), max=Math.max(x.length(),y.length()); return max==0?0d:1d-(double)d/(double)max;
    }
    private static String normalizeRepoName(String s){
        if(s==null)return ""; String x=Normalizer.normalize(s,Normalizer.Form.NFKC).toLowerCase(Locale.ROOT);
        x=x.replaceAll("[-_ ]?v?\\d+(?:\\.\\d+){1,4}$","");
        x=x.replaceAll("(?:[-_ ]?(?:source|sources|android|app))+$","");
        StringBuilder b=new StringBuilder(); for(int i=0;i<x.length();i++){char c=x.charAt(i);if(Character.isLetterOrDigit(c))b.append(c);} return b.toString();
    }
    private static int levenshtein(String a,String b){
        int[] prev=new int[b.length()+1],cur=new int[b.length()+1]; for(int j=0;j<=b.length();j++)prev[j]=j;
        for(int i=1;i<=a.length();i++){cur[0]=i;for(int j=1;j<=b.length();j++){int cost=a.charAt(i-1)==b.charAt(j-1)?0:1;cur[j]=Math.min(Math.min(cur[j-1]+1,prev[j]+1),prev[j-1]+cost);}int[] t=prev;prev=cur;cur=t;} return prev[b.length()];
    }

    private void loadRepos() {
        if(!isLoggedIn()){toast("先にGitHubへログインしてください");return;}
        DiagnosticLog.log("REPO list start"); status("リポジトリ取得中…"); io.execute(()->{ try { List<GitHubApi.Repo> repos=api().listRepos(); DiagnosticLog.log("REPO list success count="+repos.size()); ui.post(()->showRepoPicker(repos)); } catch(Exception e){ DiagnosticLog.error("REPO list",e); ui.post(()->error(e)); } });
    }
    private void showRepoPicker(List<GitHubApi.Repo> repos) {
        status("待機中"); if(repos.isEmpty()){toast("リポジトリがありません");return;} String[] names=new String[repos.size()]; for(int i=0;i<names.length;i++) names[i]=repos.get(i).fullName;
        AlertDialog d=new AlertDialog.Builder(this).setTitle("リポジトリ選択").setItems(names,(x,which)->{selectedRepo=repos.get(which); repoText.setText(selectedRepo.fullName); refreshRepoSelectionVisual(); updateRenameRepoButton(); refreshBuildButtonState(); refreshClearButtonState(); DiagnosticLog.log("REPO selected "+selectedRepo.fullName+" private="+selectedRepo.isPrivate);}).setNegativeButton("キャンセル",null).create(); d.show(); styleNDialog(d);
    }
    private void refreshRepoSelectionVisual(){
        boolean selected=selectedRepo!=null;
        if(repoCheck!=null){ repoCheck.setVisibility(selected?View.VISIBLE:View.GONE); repoCheck.setShimmering(false); }
        if(repoText!=null){ repoText.setTextColor(NEON_GREEN); repoText.setShimmering(false); }
        if(repoContent!=null) repoContent.setShimmering(selected);
    }

    private void updateRenameRepoButton() {
        if(renameRepoButton==null) return;
        boolean enabled=selectedRepo!=null;
        renameRepoButton.setEnabled(enabled);
        renameRepoButton.setBackground(buttonBackground(enabled?LBLUE:DGRAY));
        renameRepoButton.setTextColor(enabled?TEXT:WHITE);
    }

    private void renameRepoDialog() {
        if(!isLoggedIn()){toast("先にGitHubへログインしてください");return;}
        if(selectedRepo==null){toast("リポジトリを選択してください");updateRenameRepoButton();return;}
        final GitHubApi.Repo target=selectedRepo;
        String currentName=target.fullName;
        int slash=currentName.indexOf('/');
        if(slash>=0 && slash+1<currentName.length()) currentName=currentName.substring(slash+1);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(18),dp(2),dp(18),0);
        TextView note=text("リポジトリ名と公開状態を変更します。",12,false);
        note.setTextColor(WHITE); note.setPadding(0,0,0,dp(8)); box.addView(note);
        EditText e=input("新しいリポジトリ名",false); e.setText(currentName); e.setSelectAllOnFocus(true);
        box.addView(e,new LinearLayout.LayoutParams(-1,dp(CONTROL_HEIGHT_DP)));
        box.addView(space(10));

        LinearLayout visibilityRow=row(); visibilityRow.setGravity(Gravity.CENTER_VERTICAL|Gravity.START);
        NToggleSwitch visibilitySwitch=new NToggleSwitch(this);
        visibilitySwitch.setOnThumbColor(ORANGE);
        visibilitySwitch.setChecked(target.isPrivate,false);
        TextView visibilityLabel=text(target.isPrivate?"Private":"Public",14,false);
        visibilitySwitch.setOnCheckedChangeListener((view,checked)->visibilityLabel.setText(checked?"Private":"Public"));
        visibilityRow.addView(visibilitySwitch,new LinearLayout.LayoutParams(dp(44),dp(26)));
        visibilityRow.addView(hGap(8));
        visibilityRow.addView(visibilityLabel,new LinearLayout.LayoutParams(-2,dp(CONTROL_HEIGHT_DP)));
        visibilityLabel.setOnClickListener(v->visibilitySwitch.toggle());
        box.addView(visibilityRow,new LinearLayout.LayoutParams(-1,dp(CONTROL_HEIGHT_DP)));

        AlertDialog d=new AlertDialog.Builder(this).setTitle("リポジトリ設定を変更").setView(box)
                .setNegativeButton("キャンセル",null).setPositiveButton("変更",null).create();
        final String originalName=currentName;
        final boolean originalPrivate=target.isPrivate;
        d.setOnShowListener(x->{
            styleNDialog(d);
            e.requestFocus(); e.selectAll();
            Window w=d.getWindow(); if(w!=null)w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
                String newName=e.getText().toString().trim();
                boolean newPrivate=visibilitySwitch.isChecked();
                if(newName.isEmpty()){toast("リポジトリ名を入力してください");return;}
                if(newName.equals(originalName) && newPrivate==originalPrivate){toast("変更はありません");return;}
                DiagnosticLog.log("REPO update start from="+target.fullName+" to="+newName+" private="+originalPrivate+"->"+newPrivate);
                status("リポジトリ設定を変更中…"); d.dismiss();
                io.execute(()->{
                    try {
                        GitHubApi.Repo updated=api().updateRepo(target,newName,newPrivate);
                        ui.post(()->{
                            selectedRepo=updated;
                            repoText.setText(updated.fullName);
                            refreshRepoSelectionVisual();
                            updateRenameRepoButton();
                            refreshBuildButtonState();
                            status("リポジトリ設定を変更しました");
                            DiagnosticLog.log("REPO update success "+updated.fullName+" private="+updated.isPrivate);
                        });
                    } catch(Exception ex) {
                        DiagnosticLog.error("REPO update",ex);
                        ui.post(()->error(ex));
                    }
                });
            });
        });
        d.show();
    }

    private void createRepoDialog() {
        if(!isLoggedIn()){toast("先にGitHubへログインしてください");return;}
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(18),dp(2),dp(18),0);
        TextView note=text("新しいリポジトリを作成します。既存リポジトリ名は変更しません。",12,false);
        note.setTextColor(WHITE); note.setPadding(0,0,0,dp(8)); box.addView(note);
        EditText e=input("新規リポジトリ名",false); e.setText(""); e.setSelectAllOnFocus(false);
        box.addView(e,new LinearLayout.LayoutParams(-1,dp(CONTROL_HEIGHT_DP)));
        box.addView(space(10));

        LinearLayout visibilityRow=row(); visibilityRow.setGravity(Gravity.CENTER_VERTICAL|Gravity.START);
        NToggleSwitch visibilitySwitch=new NToggleSwitch(this);
        visibilitySwitch.setOnThumbColor(ORANGE);
        visibilitySwitch.setChecked(false,false);
        TextView visibilityLabel=text("Public",14,false);
        visibilitySwitch.setOnCheckedChangeListener((view,checked)->visibilityLabel.setText(checked?"Private":"Public"));
        visibilityRow.addView(visibilitySwitch,new LinearLayout.LayoutParams(dp(44),dp(26)));
        visibilityRow.addView(hGap(8));
        visibilityRow.addView(visibilityLabel,new LinearLayout.LayoutParams(-2,dp(CONTROL_HEIGHT_DP)));
        visibilityLabel.setOnClickListener(v->visibilitySwitch.toggle());
        box.addView(visibilityRow,new LinearLayout.LayoutParams(-1,dp(CONTROL_HEIGHT_DP)));

        AlertDialog d=new AlertDialog.Builder(this).setTitle("新しいリポジトリを作成").setView(box)
                .setNegativeButton("キャンセル",null).setPositiveButton("作成",null).create();
        d.setOnShowListener(x->{
            styleNDialog(d);
            e.requestFocus();
            Window w=d.getWindow(); if(w!=null)w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
                String name=e.getText().toString().trim(); if(name.isEmpty()){toast("新規リポジトリ名を入力してください");return;}
                final boolean makePrivate=visibilitySwitch.isChecked();
                DiagnosticLog.log("REPO create new start name="+name+" private="+makePrivate); status("新規リポジトリ作成中…"); d.dismiss();
                io.execute(()->{try{GitHubApi.Repo r=api().createRepo(name,makePrivate); ui.post(()->{selectedRepo=r; repoText.setText(r.fullName); refreshRepoSelectionVisual(); updateRenameRepoButton(); refreshBuildButtonState(); status("新規リポジトリ作成完了"); DiagnosticLog.log("REPO create new success "+r.fullName+" private="+r.isPrivate);});}catch(Exception ex){DiagnosticLog.error("REPO create new",ex);ui.post(()->error(ex));}});
            });
        });
        d.show();
    }

    private boolean ensurePrecheckAllowsBuild(){
        SharedItem source=sourceZipItem();
        if(source==null){
            // YAML-only updates are valid. The repository-side source.zip is checked after the workflow update.
            return hasWorkflowItem();
        }
        if(sourcePrecheckPending){ toast("ビルド前プリチェック中です"); return false; }
        PrecheckResult r=currentPrecheckResult();
        if(r==null){ scheduleSourceIdentityAnalysis(); toast("プリチェックを開始しました"); return false; }
        if(r.level==PRECHECK_ERROR){ showPrecheckDetails(); toast("プリチェックエラーを修正してください"); return false; }
        return true;
    }

    private boolean hasWorkflowItem(){
        for(SharedItem item:shared){
            if(item==null||item.name==null) continue;
            String n=item.name.toLowerCase(Locale.ROOT);
            if(n.endsWith(".yml")||n.endsWith(".yaml")) return true;
        }
        return false;
    }

    private void startBuild(){
        if(!isLoggedIn()){toast("先にGitHubへログインしてください");return;}
        if(shared.isEmpty()){toast("source ZIP または .yml を選択してください");return;}
        if(!ensurePrecheckAllowsBuild()) return;
        if(selectedRepo==null){toast("リポジトリを選択してください");return;}
        double sim=selectedRepoSourceSimilarity();
        if(lastSourceIdentity!=null && !lastSourceIdentity.candidates.isEmpty() && sim<0.60d){
            String sourceName=notEmpty(lastSourceIdentity.appName)?lastSourceIdentity.appName:lastSourceIdentity.candidates.get(0);
            String identityLabel=sourceZipItem()!=null?"source.zip":"受信YAML";
            AlertDialog mismatchDialog=new AlertDialog.Builder(this)
                    .setTitle("リポジトリ名が一致していません")
                    .setMessage(identityLabel+": "+sourceName+"\n選択中: "+selectedRepo.fullName+"\n\n別のリポジトリへアップロードする可能性があります。続行しますか？")
                    .setNegativeButton("キャンセル",null)
                    .setPositiveButton("続行",(d,w)->startBuildConfirmed())
                    .create();
            mismatchDialog.show(); styleNDialog(mismatchDialog);
            DiagnosticLog.log("BUILD repo mismatch warning similarity="+String.format(Locale.US,"%.3f",sim)+" repo="+selectedRepo.fullName+" source="+sourceName);
            return;
        }
        startBuildConfirmed();
    }

    private void startBuildConfirmed() {
        if(!isLoggedIn()){toast("先にGitHubへログインしてください");return;}
        if(shared.isEmpty()){toast("source ZIP または .yml を選択してください");return;}
        if(!ensurePrecheckAllowsBuild()) return;
        if(selectedRepo==null){toast("リポジトリを選択してください");return;}

        final GitHubApi.Repo buildRepo=selectedRepo;
        activeBuildRepo=buildRepo;
        final List<SharedItem> buildFiles=new ArrayList<>(shared);
        final boolean yamlOnly=sourceZipItem()==null && hasWorkflowItem();
        final boolean recoverOnEmergency=recoverySwitch!=null && recoverySwitch.isChecked();
        cancelRequested=false; activeRunId=-1L;
        lastFailureReport=null; lastFailureRunId=-1L; lastFailureRepo=null;
        setFailureActionsVisible(false);
        maybeRequestNotificationPermission();
        startBuildElapsedTimer();
        setEmergencyStopActive(true);
        setBuildButtonBusy(true);
        startBuildHoldService(buildRepo.fullName);
        status("アップロード中…");
        DiagnosticLog.log("BUILD start repo="+buildRepo.fullName+" files="+buildFiles.size()+" yamlOnly="+yamlOnly+" recoveryOnEmergency="+recoverOnEmergency);

        io.execute(()->{
            activeBuildThread=Thread.currentThread();
            GitHubApi.CommitResult commitResult=null;
            long completedRunId=-1L;
            try {
                checkCancelled();
                GitHubApi a=api();
                if(!yamlOnly) ensureSourceZipCache();
                commitResult=a.commitFiles(buildRepo,buildFiles,getContentResolver());
                checkCancelled();
                String sha=commitResult.commitSha;
                DiagnosticLog.log("BUILD upload resolved sha="+tail(sha,8)+" previous="+tail(commitResult.previousSha,8)+
                        " tree="+tail(commitResult.treeSha,8)+" changed="+commitResult.contentChanged+" yamlOnly="+yamlOnly);

                if(yamlOnly && !a.repoFileExists(buildRepo,"source.zip")){
                    String updateState=commitResult.contentChanged?"Workflow更新完了":"Workflow変更なし";
                    DiagnosticLog.log("BUILD yaml-only finished without build: repository source.zip missing");
                    ui.post(()->{
                        status(updateState+" / repoにsource.zipがありません");
                        stopBuildElapsedTimer();
                        setBuildButtonBusy(false);
                        setEmergencyStopActive(false);
                        stopBuildWatchService();
                        toast("YAMLは更新しました。source.zipが無いためビルドは開始していません");
                    });
                    return;
                }

                GitHubApi.DispatchResult dispatch=null;
                GitHubApi.Run run=null;
                if(yamlOnly){
                    if(commitResult.contentChanged){
                        postStatus("Workflow更新完了 / Actions確認中…");
                        for(int i=0;i<3&&run==null;i++){
                            checkCancelled();
                            if(i>0)sleepCancelable(2000);
                            run=a.findRun(buildRepo.fullName,sha);
                        }
                    }
                    if(run==null){
                        postStatus(commitResult.contentChanged?"Workflow更新完了 / Actions直接起動中…":"Workflow変更なし / Actions直接起動中…");
                        dispatch=a.dispatchBuildWorkflow(buildRepo);
                        DiagnosticLog.log("BUILD yaml-only workflow_dispatch path="+dispatch.workflowPath+" workflowId="+dispatch.workflowId+" sha="+tail(sha,8));
                        postStatus("Actions直接起動済み / 待機中…");
                    }
                }else if(!commitResult.contentChanged){
                    postStatus("同一source.zip / コミット省略 / Actions起動中…");
                    dispatch=a.dispatchBuildWorkflow(buildRepo);
                    DiagnosticLog.log("BUILD identical source; commit skipped, workflow_dispatch path="+dispatch.workflowPath+" workflowId="+dispatch.workflowId+" sha="+tail(sha,8));
                    postStatus("Actions直接起動済み / 待機中…");
                }else{
                    postStatus("コミット完了 / Actions確認中…");
                    // A commit may contain only workflow maintenance while source.zip itself is unchanged.
                    // In that case a workflow with `push.paths: source.zip` will not start.
                    // Give push a few seconds, then fall back to workflow_dispatch instead of waiting ~2 minutes.
                    for(int i=0;i<3&&run==null;i++){
                        checkCancelled();
                        if(i>0)sleepCancelable(2000);
                        checkCancelled();
                        run=a.findRun(buildRepo.fullName,sha);
                    }
                    if(run==null){
                        postStatus("push未検出 / Actions直接起動中…");
                        dispatch=a.dispatchBuildWorkflow(buildRepo);
                        DiagnosticLog.log("BUILD push run not detected; fallback workflow_dispatch path="+dispatch.workflowPath+
                                " workflowId="+dispatch.workflowId+" sha="+tail(sha,8));
                        postStatus("Actions直接起動済み / 待機中…");
                    }
                }

                for(int i=0;i<40&&run==null;i++){
                    checkCancelled();
                    if(i>0)sleepCancelable(3000);
                    checkCancelled();
                    run=dispatch==null ? a.findRun(buildRepo.fullName,sha) : a.findWorkflowDispatchRun(buildRepo,dispatch,sha);
                }
                if(run==null) throw new Exception("Actions Runを検出できませんでした。GitHub Actionsの状態を確認してください");

                long id=run.id; activeRunId=id; completedRunId=id;
                startBuildWatchService(buildRepo,id);
                DiagnosticLog.log("BUILD actions run found id="+id+" status="+run.status);
                while(!"completed".equals(run.status)){
                    checkCancelled();
                    DiagnosticLog.log("BUILD actions status id="+id+" status="+run.status);
                    postStatus("Actions: "+run.status+"  #"+id);
                    sleepCancelable(5000);
                    checkCancelled();
                    a=api();
                    run=a.getRun(buildRepo.fullName,id);
                }
                checkCancelled();
                DiagnosticLog.log("BUILD actions completed id="+id+" conclusion="+run.conclusion);
                if(!"success".equals(run.conclusion)){
                    try{
                        lastFailureReport=a.failureReport(buildRepo.fullName,id);
                        DiagnosticLog.log("BUILD failure report collected chars="+(lastFailureReport==null?0:lastFailureReport.length()));
                    }catch(Exception logError){
                        DiagnosticLog.error("BUILD failure report",logError);
                        lastFailureReport="GitBuild Actions failure report\nRepository: "+buildRepo.fullName+"\nRun: #"+id+"\n\nログ取得失敗: "+(logError.getMessage()==null?logError.getClass().getSimpleName():logError.getMessage());
                    }
                    lastFailureRunId=id; lastFailureRepo=buildRepo.fullName;
                    throw new Exception("Actions終了: "+run.conclusion+"  (#"+id+")");
                }

                postStatus("ビルド成功 / APK取得中…");
                checkCancelled();
                List<GitHubApi.Artifact> arts=a.artifacts(buildRepo.fullName,id);
                if(arts.isEmpty()) throw new Exception("Artifactがありません");
                GitHubApi.Artifact chosen=arts.get(0);
                for(GitHubApi.Artifact x:arts) if(x.name.toLowerCase(Locale.ROOT).contains("apk")){chosen=x;break;}
                DiagnosticLog.log("BUILD artifact selected id="+chosen.id+" name="+chosen.name);
                byte[] zip=a.downloadArtifact(buildRepo.fullName,chosen.id);
                checkCancelled();
                DiagnosticLog.log("BUILD artifact downloaded bytes="+zip.length);
                List<SavedApk> saved=saveApks(zip);
                checkCancelled();
                if(saved.isEmpty()) throw new Exception("Artifact内に.apkがありません");

                String recoveryNote="";
                // Recovery is emergency-stop only. Successful builds keep the uploaded repository state.

                List<String> savedNames=new ArrayList<>();
                for(SavedApk aapk:saved)savedNames.add(aapk.name);
                String names=String.join(", ",savedNames);
                SavedApk primary=saved.get(0);
                String sourceCopyNote="";
                String sourceCopyName=null;
                try{
                    boolean renameSourceOnComplete=!"0".equals(store.getString("rename_source_on_complete"));
                    sourceCopyName=saveSourceCopy(primary.appName,primary.versionName,renameSourceOnComplete);
                    if(notEmpty(sourceCopyName)){
                        sourceCopyNote="\nSource保存: Download/"+sourceCopyName;
                        DiagnosticLog.log("SOURCE copy complete name="+sourceCopyName+" app="+primary.appName+" version="+primary.versionName);
                    }
                }catch(Exception se){
                    DiagnosticLog.error("SOURCE copy",se);
                    sourceCopyNote="\nSource: 保存失敗 - "+(se.getMessage()==null?se.getClass().getSimpleName():se.getMessage());
                }
                String finalRecoveryNote=recoveryNote;
                String finalSourceCopyNote=sourceCopyNote;
                String finalSourceCopyName=sourceCopyName;
                long finalRunId=id;
                DiagnosticLog.log("BUILD complete apk="+names+" recoveryOnEmergency="+recoverOnEmergency+" sourceCopy="+finalSourceCopyNote.replace('\n',' '));
                ui.post(()->{
                    lastApkUri=primary.uri;
                    lastApkName=primary.name;
                    statusSuccess("完了\nDownload: "+names+finalSourceCopyNote+finalRecoveryNote,true);
                    stopBuildElapsedTimer();
                    if(notEmpty(finalSourceCopyNote)) toast(finalSourceCopyNote.substring(1));
                    setBuildButtonBusy(false);
                    setEmergencyStopActive(false);
                    stopBuildWatchService();
                    notifyBuildSuccess(primary.appName,primary.versionName,primary.name,primary.uri,finalRunId,buildRepo.fullName);
                });
            } catch(Exception e){
                boolean cancelled=cancelRequested || e instanceof InterruptedException || e instanceof BuildCancelledException;
                String recoveryNote="";
                if(cancelled && recoverOnEmergency && commitResult!=null && commitResult.contentChanged){
                    try{
                        postStatus("停止 / 前の状態へリカバリー中…");
                        boolean restored=api().recoverPreviousState(buildRepo,commitResult);
                        recoveryNote=restored?"\n前の状態へリカバリー済み":"\nリカバリー保留（HEAD変更を検出）";
                        DiagnosticLog.log("BUILD recovery after error restored="+restored);
                    }catch(Exception re){
                        DiagnosticLog.error("BUILD recovery after error",re);
                        recoveryNote="\nリカバリー失敗: "+(re.getMessage()==null?re.getClass().getSimpleName():re.getMessage());
                    }
                }
                String original=e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();
                String finalRecoveryNote=recoveryNote;
                if(cancelled) DiagnosticLog.log("BUILD emergency stop completed recovery="+recoverOnEmergency+" note="+finalRecoveryNote.replace('\n',' '));
                else DiagnosticLog.error("BUILD",e);

                if(!cancelled){
                    if(lastFailureReport==null && completedRunId>0){
                        try{ lastFailureReport=api().failureReport(buildRepo.fullName,completedRunId); }
                        catch(Exception ignored){}
                        lastFailureRunId=completedRunId; lastFailureRepo=buildRepo.fullName;
                    }
                }
                ui.post(()->{
                    setBuildButtonBusy(false);
                    setEmergencyStopActive(false);
                    stopBuildWatchService();
                    if(cancelled){
                        if(finalRecoveryNote.contains("リカバリー済み")) status("停止・リカバリー完了");
                        else status("停止しました"+finalRecoveryNote);
                    } else {
                        status("エラー\n"+original+finalRecoveryNote);
                        setFailureActionsVisible(lastFailureReport!=null);
                        notifyBuildFailure(original,lastFailureRunId,buildRepo.fullName);
                    }
                    stopBuildElapsedTimer();
                });
            } finally {
                activeRunId=-1L;
                activeBuildThread=null;
                activeBuildRepo=null;
                cancelRequested=false;
                if(!activityDestroyed) ui.post(this::refreshClearButtonState);
                if(activityDestroyed){ try{fileIo.shutdownNow();}catch(Exception ignored){} try{controlIo.shutdownNow();}catch(Exception ignored){} io.shutdown(); }
            }
        });
    }

    private static final class BuildCancelledException extends Exception {
        BuildCancelledException(){ super("緊急停止"); }
    }

    private void checkCancelled() throws BuildCancelledException {
        if(cancelRequested) throw new BuildCancelledException();
    }

    private void sleepCancelable(long millis) throws Exception {
        try { Thread.sleep(millis); }
        catch(InterruptedException e){
            if(cancelRequested) throw new BuildCancelledException();
            Thread.currentThread().interrupt();
            throw e;
        }
    }

    private void setEmergencyStopActive(boolean active) {
        if(emergencyStopButton==null) return;
        emergencyStopButton.setEnabled(active);
        emergencyStopButton.setBackground(buttonBackground(active?RED:DGRAY));
        emergencyStopButton.setTextColor(active?TEXT:WHITE);
    }

    private void requestEmergencyStop() {
        if(emergencyStopButton==null || !emergencyStopButton.isEnabled()) return;
        if(cancelRequested) return;
        cancelRequested=true;
        status("停止中…");
        DiagnosticLog.log("BUILD emergency stop requested runId="+activeRunId);
        setEmergencyStopActive(false);
        Thread t=activeBuildThread;
        if(t!=null) t.interrupt();
        final long runId=activeRunId;
        final GitHubApi.Repo repo=activeBuildRepo!=null?activeBuildRepo:selectedRepo;
        if(runId>0 && repo!=null){
            controlIo.execute(()->{
                try {
                    api().cancelRun(repo.fullName,runId);
                    DiagnosticLog.log("BUILD actions cancel requested id="+runId);
                } catch(Exception e) {
                    DiagnosticLog.error("BUILD actions cancel",e);
                }
            });
        }
    }

    private List<SavedApk> saveApks(byte[] zipBytes) throws Exception {
        List<SavedApk> saved=new ArrayList<>();
        try(ZipInputStream zin=new ZipInputStream(new ByteArrayInputStream(zipBytes))) {
            ZipEntry z; byte[] buf=new byte[32768];
            while((z=zin.getNextEntry())!=null){
                if(z.isDirectory()||!z.getName().toLowerCase().endsWith(".apk")){ zin.closeEntry(); continue; }
                String name=z.getName(); int slash=name.lastIndexOf('/'); if(slash>=0)name=name.substring(slash+1);
                long declaredSize=z.getSize(), declaredCrc=z.getCrc();
                ByteArrayOutputStream apkOut=new ByteArrayOutputStream(declaredSize>0&&declaredSize<Integer.MAX_VALUE?(int)declaredSize:1024*1024);
                CRC32 extractedCrc=new CRC32(); long extractedSize=0; int n;
                while((n=zin.read(buf))!=-1){ if(n==0)continue; apkOut.write(buf,0,n); extractedCrc.update(buf,0,n); extractedSize+=n; }
                zin.closeEntry();
                long crc=extractedCrc.getValue();
                DiagnosticLog.log("APK extract entry="+name+" bytes="+extractedSize+" declared="+declaredSize+" crc="+Long.toHexString(crc));
                if(declaredSize>=0&&declaredSize!=extractedSize) throw new Exception("APK展開サイズ不一致: "+name+" expected="+declaredSize+" actual="+extractedSize);
                if(declaredCrc>=0&&declaredCrc!=crc) throw new Exception("APK展開CRC不一致: "+name);
                byte[] apkBytes=apkOut.toByteArray();
                validateApkArchive(name,apkBytes);
                ApkIdentity identity=inspectApkIdentity(apkBytes);
                saved.add(saveVerifiedApk(name,apkBytes,crc,identity));
            }
        }
        return saved;
    }

    private void validateApkArchive(String name, byte[] apkBytes) throws Exception {
        boolean manifest=false; int entries=0; byte[] buf=new byte[32768];
        try(ZipInputStream apk=new ZipInputStream(new ByteArrayInputStream(apkBytes))){
            ZipEntry e; while((e=apk.getNextEntry())!=null){
                if(!e.isDirectory()){ entries++; if("AndroidManifest.xml".equals(e.getName()))manifest=true; int n; while((n=apk.read(buf))!=-1){ /* force CRC validation */ } }
                apk.closeEntry();
            }
        }
        if(!manifest) throw new Exception("APK検証失敗: AndroidManifest.xmlがありません: "+name);
        DiagnosticLog.log("APK archive verified name="+name+" entries="+entries+" bytes="+apkBytes.length);
    }

    private SavedApk saveVerifiedApk(String requestedName, byte[] apkBytes, long expectedCrc, ApkIdentity identity) throws Exception {
        ContentResolver resolver=getContentResolver(); Uri u=null;
        try{
            ContentValues v=new ContentValues();
            v.put(MediaStore.Downloads.DISPLAY_NAME,requestedName);
            v.put(MediaStore.Downloads.MIME_TYPE,"application/vnd.android.package-archive");
            v.put(MediaStore.Downloads.RELATIVE_PATH,"Download");
            v.put(MediaStore.Downloads.IS_PENDING,1);
            u=resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
            if(u==null)throw new Exception("Downloadへ保存できません");
            try(OutputStream out=resolver.openOutputStream(u,"w")){
                if(out==null)throw new Exception("Downloadの出力ストリームを開けません");
                int off=0; while(off<apkBytes.length){ int len=Math.min(32768,apkBytes.length-off); out.write(apkBytes,off,len); off+=len; }
                out.flush();
            }
            long[] verify=readBackStats(u);
            DiagnosticLog.log("APK readback uri="+u+" sourceBytes="+apkBytes.length+" targetBytes="+verify[0]+" sourceCrc="+Long.toHexString(expectedCrc)+" targetCrc="+Long.toHexString(verify[1]));
            if(verify[0]!=apkBytes.length) throw new Exception("APK保存サイズ不一致: source="+apkBytes.length+", target="+verify[0]);
            if(verify[1]!=expectedCrc) throw new Exception("APK保存CRC不一致: "+requestedName);
            ContentValues done=new ContentValues(); done.put(MediaStore.Downloads.IS_PENDING,0); resolver.update(u,done,null,null);
            String actualName=queryDisplayName(u,requestedName);
            DiagnosticLog.log("APK saved verified Download/"+actualName+" bytes="+verify[0]+" uri="+u);
            return new SavedApk(actualName,u,identity.appName,identity.versionName);
        }catch(Exception e){
            if(u!=null){ try{resolver.delete(u,null,null);}catch(Exception ignored){} }
            DiagnosticLog.error("APK save verify",e);
            throw e;
        }
    }

    private ApkIdentity inspectApkIdentity(byte[] apkBytes) throws Exception {
        File tmp=File.createTempFile("gitbuild_apk_",".apk",getCacheDir());
        try{
            try(FileOutputStream out=new FileOutputStream(tmp)){ out.write(apkBytes); out.flush(); }
            PackageManager pm=getPackageManager();
            PackageInfo info=pm.getPackageArchiveInfo(tmp.getAbsolutePath(),PackageManager.GET_META_DATA);
            if(info==null)throw new Exception("生成APKのアプリ情報を取得できません");
            String packageName=notEmpty(info.packageName)?info.packageName:"app";
            String versionName=notEmpty(info.versionName)?info.versionName:String.valueOf(info.getLongVersionCode());
            String appName=packageName;
            try{
                ApplicationInfo ai=info.applicationInfo;
                if(ai!=null){
                    ai.sourceDir=tmp.getAbsolutePath(); ai.publicSourceDir=tmp.getAbsolutePath();
                    CharSequence label=pm.getApplicationLabel(ai);
                    if(label!=null&&notEmpty(label.toString().trim()))appName=label.toString().trim();
                }
            }catch(Exception labelError){ DiagnosticLog.error("APK label inspect",labelError); }
            DiagnosticLog.log("APK identity app="+appName+" version="+versionName+" package="+packageName);
            return new ApkIdentity(appName,versionName,packageName);
        }finally{
            if(!tmp.delete())tmp.deleteOnExit();
        }
    }

    private void clearSourceZipCache() {
        File f=cachedSourceZipFile;
        cachedSourceZipFile=null;
        cachedSourceZipOriginalName=null;
        lastSourceIdentity=null; lastSourceIdentityUri=null; sourceIdentityPending=false;
        if(sourceIdentityText!=null) sourceIdentityText.setVisibility(View.GONE);
        if(f!=null && f.exists() && !f.delete()) DiagnosticLog.log("SOURCE cache old delete deferred path="+f.getName());
    }

    private void ensureSourceZipCache() throws Exception {
        if(cachedSourceZipFile!=null && cachedSourceZipFile.isFile() && cachedSourceZipFile.length()>0) return;
        SharedItem source=null;
        for(SharedItem item:shared){
            if(item!=null&&item.name!=null&&item.name.toLowerCase(Locale.ROOT).endsWith(".zip")){ source=item; break; }
        }
        if(source==null){ DiagnosticLog.log("SOURCE cache skipped no shared zip"); return; }
        File target=new File(getCacheDir(),"gitbuild_shared_source.zip");
        if(target.exists()&&!target.delete()) DiagnosticLog.log("SOURCE cache replacing existing file");
        CRC32 crc=new CRC32(); long total=0; byte[] buf=new byte[32768];
        try(InputStream in=getContentResolver().openInputStream(source.uri); FileOutputStream out=new FileOutputStream(target)){
            if(in==null)throw new Exception("共有source ZIPを開けません");
            int n; while((n=in.read(buf))!=-1){ if(n<=0)continue; out.write(buf,0,n); crc.update(buf,0,n); total+=n; }
            out.flush();
        }catch(Exception e){
            if(target.exists())target.delete();
            DiagnosticLog.error("SOURCE cache",e);
            throw e;
        }
        if(total<=0){ target.delete(); throw new Exception("共有source ZIPが空です"); }
        cachedSourceZipFile=target;
        cachedSourceZipOriginalName=source.name;
        DiagnosticLog.log("SOURCE cache ready original="+source.name+" bytes="+total+" crc="+Long.toHexString(crc.getValue()));
    }

    private byte[] readSourceCopyBytes(SharedItem source) throws Exception {
        File cached=cachedSourceZipFile;
        if(cached!=null&&cached.isFile()&&cached.length()>0){
            try(FileInputStream in=new FileInputStream(cached); ByteArrayOutputStream out=new ByteArrayOutputStream((int)Math.min(cached.length(),Integer.MAX_VALUE))){
                byte[] buf=new byte[32768]; int n; while((n=in.read(buf))!=-1){ if(n>0)out.write(buf,0,n); }
                byte[] bytes=out.toByteArray();
                DiagnosticLog.log("SOURCE copy input cache bytes="+bytes.length+" original="+(cachedSourceZipOriginalName==null?source.name:cachedSourceZipOriginalName));
                return bytes;
            }
        }
        DiagnosticLog.log("SOURCE copy cache unavailable; URI fallback name="+source.name);
        return readSharedBytes(source.uri);
    }

    private String saveSourceCopy(String appName,String versionName,boolean renameOnComplete) throws Exception {
        SharedItem source=null;
        for(SharedItem item:shared){
            if(item!=null&&item.name!=null&&item.name.toLowerCase(Locale.ROOT).endsWith(".zip")){ source=item; break; }
        }
        if(source==null){ DiagnosticLog.log("SOURCE copy skipped no shared zip"); return null; }
        byte[] bytes=readSourceCopyBytes(source);
        String safeApp=safeFilePart(notEmpty(appName)?appName:"App");
        String safeVersion=safeFilePart(notEmpty(versionName)?versionName:"unknown");
        String requested=renameOnComplete ? safeApp+"_"+safeVersion+"_source.zip" : "source.zip";
        CRC32 crc=new CRC32(); crc.update(bytes,0,bytes.length);
        ContentResolver resolver=getContentResolver(); Uri u=null;
        try{
            ContentValues v=new ContentValues();
            v.put(MediaStore.Downloads.DISPLAY_NAME,requested);
            v.put(MediaStore.Downloads.MIME_TYPE,"application/zip");
            v.put(MediaStore.Downloads.RELATIVE_PATH,"Download");
            v.put(MediaStore.Downloads.IS_PENDING,1);
            u=resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
            if(u==null)throw new Exception("source ZIPをDownloadへ保存できません");
            try(OutputStream out=resolver.openOutputStream(u,"w")){
                if(out==null)throw new Exception("source ZIPの出力ストリームを開けません");
                int off=0; while(off<bytes.length){ int len=Math.min(32768,bytes.length-off); out.write(bytes,off,len); off+=len; }
                out.flush();
            }
            long[] verify=readBackStats(u);
            if(verify[0]!=bytes.length)throw new Exception("source ZIP保存サイズ不一致: source="+bytes.length+", target="+verify[0]);
            if(verify[1]!=crc.getValue())throw new Exception("source ZIP保存CRC不一致");
            ContentValues done=new ContentValues(); done.put(MediaStore.Downloads.IS_PENDING,0); resolver.update(u,done,null,null);
            String actual=queryDisplayName(u,requested);
            DiagnosticLog.log("SOURCE saved verified Download/"+actual+" bytes="+verify[0]+" crc="+Long.toHexString(verify[1])+" original="+source.name+" renameOnComplete="+renameOnComplete);
            return actual;
        }catch(Exception e){
            if(u!=null){try{resolver.delete(u,null,null);}catch(Exception ignored){}}
            throw e;
        }
    }

    private byte[] readSharedBytes(Uri uri) throws Exception {
        try(InputStream in=getContentResolver().openInputStream(uri); ByteArrayOutputStream out=new ByteArrayOutputStream()){
            if(in==null)throw new Exception("共有source ZIPを開けません");
            byte[] buf=new byte[32768]; int n; while((n=in.read(buf))!=-1){ if(n>0)out.write(buf,0,n); }
            return out.toByteArray();
        }
    }

    private static String safeFilePart(String value){
        String s=value==null?"":value.trim();
        s=s.replaceAll("[\\\\/:*?\"<>|]+","_").replaceAll("\\s+","_");
        s=s.replaceAll("_+","_");
        while(s.startsWith("."))s=s.substring(1);
        return s.isEmpty()?"App":s;
    }

    private long[] readBackStats(Uri u) throws Exception {
        CRC32 crc=new CRC32(); long count=0; byte[] buf=new byte[32768];
        try(InputStream in=getContentResolver().openInputStream(u)){
            if(in==null)throw new Exception("保存APKを再読込できません");
            int n; while((n=in.read(buf))!=-1){ if(n==0)continue; crc.update(buf,0,n); count+=n; }
        }
        return new long[]{count,crc.getValue()};
    }

    private String queryDisplayName(Uri u,String fallback){
        try(Cursor c=getContentResolver().query(u,new String[]{MediaStore.Downloads.DISPLAY_NAME},null,null,null)){
            if(c!=null&&c.moveToFirst()){ int i=c.getColumnIndex(MediaStore.Downloads.DISPLAY_NAME); if(i>=0){String s=c.getString(i);if(s!=null&&!s.isEmpty())return s;} }
        }catch(Exception ignored){}
        return fallback;
    }

    private void runLastApk(){
        if(lastApkUri==null){toast("実行できるAPKがありません");return;}
        try{
            DiagnosticLog.log("APK run requested name="+lastApkName+" uri="+lastApkUri);
            Intent i=new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(lastApkUri,"application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        }catch(Exception e){DiagnosticLog.error("APK run",e);error(e);}
    }

    private void startBuildHoldService(String repo){
        if(!notEmpty(repo))return;
        try{Intent i=new Intent(this,BuildWatchService.class);i.setAction(BuildWatchService.ACTION_HOLD);i.putExtra(BuildWatchService.EXTRA_REPO,repo);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);DiagnosticLog.log("WATCH service hold requested repo="+repo);}catch(Exception e){DiagnosticLog.error("WATCH service hold",e);}
    }

    private void startBuildWatchService(GitHubApi.Repo repo,long runId){
        if(repo==null||runId<=0)return;
        try{
            Intent i=new Intent(this,BuildWatchService.class); i.setAction(BuildWatchService.ACTION_WATCH); i.putExtra(BuildWatchService.EXTRA_REPO,repo.fullName); i.putExtra(BuildWatchService.EXTRA_RUN,runId);
            if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
            DiagnosticLog.log("WATCH service requested repo="+repo.fullName+" run="+runId);
        }catch(Exception e){DiagnosticLog.error("WATCH service start",e);}
    }

    private void startBuildWatchService(String repo,long runId){
        if(!notEmpty(repo)||runId<=0)return;
        try{Intent i=new Intent(this,BuildWatchService.class);i.setAction(BuildWatchService.ACTION_WATCH);i.putExtra(BuildWatchService.EXTRA_REPO,repo);i.putExtra(BuildWatchService.EXTRA_RUN,runId);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);DiagnosticLog.log("WATCH service requested repo="+repo+" run="+runId);}catch(Exception e){DiagnosticLog.error("WATCH service start",e);}
    }

    private void stopBuildWatchService(){
        try{Intent i=new Intent(this,BuildWatchService.class);i.setAction(BuildWatchService.ACTION_STOP);startService(i);}catch(Exception ignored){try{stopService(new Intent(this,BuildWatchService.class));}catch(Exception ignored2){}}
    }

    private void setBuildButtonBusy(boolean busy){
        buildBusy=busy;
        if(statusText!=null) statusText.setShimmering(busy);
        refreshBuildButtonState();
        if(buildSpinner!=null) buildSpinner.setVisibility(busy?View.VISIBLE:View.GONE);
        refreshClearButtonState();
    }

    private boolean hasClearableState(){
        boolean hasFiles=!shared.isEmpty();
        boolean hasRepo=selectedRepo!=null;
        boolean hasBuildState=lastApkUri!=null || lastFailureReport!=null || lastFailureRunId>0L ||
                buildTimerRunning || (statusBaseText!=null && !"待機中".equals(statusBaseText));
        return hasFiles || hasRepo || hasBuildState;
    }

    private void refreshClearButtonState(){
        if(clearButton==null) return;
        boolean enabled=!buildBusy && activeBuildThread==null && hasClearableState();
        clearButton.setEnabled(enabled);
        clearButton.setBackground(buttonBackground(enabled?RED:DGRAY));
        clearButton.setTextColor(enabled?TEXT:WHITE);
    }

    private void refreshBuildButtonState(){
        if(buildButton==null) return;
        boolean hasFiles=!shared.isEmpty();
        boolean hasRepo=selectedRepo!=null;
        boolean blocked=precheckBlocksBuild();
        boolean enabled=!buildBusy && hasFiles && hasRepo && !blocked;
        buildButton.setEnabled(enabled);
        buildButton.setText(buildBusy?"":"アップロード＆ビルド");
        buildButton.setBackground(buttonBackground(enabled?NEON_GREEN:DGRAY));
        buildButton.setTextColor(enabled?Color.BLACK:WHITE);
    }

    private void resetBuildStatusForIncoming(){
        lastApkUri=null; lastApkName=null;
        lastFailureReport=null; lastFailureRunId=-1L; lastFailureRepo=null;
        setFailureActionsVisible(false);
        buildTimerRunning=false; ui.removeCallbacks(buildElapsedTicker);
        statusBaseText="待機中";
        if(statusText!=null) statusText.setShimmering(false);
        renderStatusText();
        if(elapsedText!=null) elapsedText.setText("");
        if(statusCheck!=null) statusCheck.setVisibility(View.GONE);
        if(runApkButton!=null) runApkButton.setVisibility(View.GONE);
        stopBuildWatchService();
        refreshBuildButtonState();
        refreshClearButtonState();
        DiagnosticLog.log("UI build status cleared for new receive");
    }

    private void clearMainState(){
        if(activeBuildThread!=null || buildBusy) return;
        clearSourceZipCache();
        shared.clear();
        resetSourceAnalysisState();
        refreshFiles();
        clearSelectedRepo("clear");
        resetBuildStatusForIncoming();
        DiagnosticLog.log("UI clear received files / repository / build status");
    }

    private void setFailureActionsVisible(boolean visible){
        if(errorDetailsButton!=null) errorDetailsButton.setVisibility(visible?View.VISIBLE:View.GONE);
        if(shareErrorButton!=null) shareErrorButton.setVisibility(visible?View.VISIBLE:View.GONE);
        if(rerunFailedButton!=null) rerunFailedButton.setVisibility(visible&&lastFailureRunId>0?View.VISIBLE:View.GONE);
    }

    private void showLastFailureReport(){
        if(!notEmpty(lastFailureReport)){toast("取得済みのエラーログがありません");return;}
        TextView body=text(lastFailureReport,11,false); body.setTypeface(android.graphics.Typeface.MONOSPACE); body.setTextIsSelectable(true); body.setGravity(Gravity.TOP|Gravity.START); body.setPadding(dp(12),dp(12),dp(12),dp(12)); body.setBackground(round(DGRAY,8));
        ScrollView scroll=new ScrollView(this); scroll.addView(body,new ScrollView.LayoutParams(-1,-2));
        AlertDialog d=new AlertDialog.Builder(this).setTitle("Actions エラー詳細").setView(scroll)
                .setNeutralButton("コピー",(x,w)->{ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE); cm.setPrimaryClip(ClipData.newPlainText("GitBuild Actions error",lastFailureReport)); toast("エラー詳細をコピーしました");})
                .setNegativeButton("閉じる",null).setPositiveButton("ChatGPTへ共有",(x,w)->shareLastFailureToChatGPT()).create();
        d.show(); styleNDialog(d); if(d.getWindow()!=null)d.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels*0.96f),(int)(getResources().getDisplayMetrics().heightPixels*0.82f));
    }

    private void shareLastFailureToChatGPT(){
        if(!notEmpty(lastFailureReport)){toast("取得済みのエラーログがありません");return;}
        try{
            Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain");
            i.putExtra(Intent.EXTRA_SUBJECT,"GitBuild Actions error");
            i.putExtra(Intent.EXTRA_TEXT,"GitBuildのビルドエラーを解析してください。\n\n"+lastFailureReport);
            i.setPackage("com.openai.chatgpt");
            if(i.resolveActivity(getPackageManager())!=null) startActivity(i);
            else { i.setPackage(null); startActivity(Intent.createChooser(i,"エラーを共有")); }
            DiagnosticLog.log("BUILD failure shared chars="+lastFailureReport.length());
        }catch(Exception e){DiagnosticLog.error("BUILD failure share",e);error(e);}
    }

    private void rerunLastFailedJobs(){
        if(lastFailureRunId<=0||!notEmpty(lastFailureRepo)){toast("再実行できる失敗Runがありません");return;}
        final long id=lastFailureRunId; final String repo=lastFailureRepo;
        rerunFailedButton.setEnabled(false); rerunFailedButton.setAlpha(0.55f); rerunFailedButton.setBackground(buttonBackground(NEON_GREEN)); rerunFailedButton.setTextColor(Color.BLACK);
        status("失敗Jobを再実行中… #"+id);
        io.execute(()->{
            try{
                api().rerunFailedJobs(repo,id);
                ui.post(()->{ status("失敗Jobを再実行しました  #"+id); toast("source.zipを再アップロードせず再実行しました"); rerunFailedButton.setEnabled(true); rerunFailedButton.setAlpha(1f); rerunFailedButton.setBackground(buttonBackground(NEON_GREEN)); rerunFailedButton.setTextColor(Color.BLACK); startBuildWatchService(repo,id); });
            }catch(Exception e){ DiagnosticLog.error("BUILD rerun failed jobs",e); ui.post(()->{ rerunFailedButton.setEnabled(true); rerunFailedButton.setAlpha(1f); rerunFailedButton.setBackground(buttonBackground(NEON_GREEN)); rerunFailedButton.setTextColor(Color.BLACK); error(e); setFailureActionsVisible(true); }); }
        });
    }

    private void ensureNotificationChannel(){
        if(Build.VERSION.SDK_INT<26)return;
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE); if(nm==null)return;
        NotificationChannel ch=new NotificationChannel(NOTIFICATION_CHANNEL,"GitBuild ビルド",NotificationManager.IMPORTANCE_DEFAULT);
        ch.setDescription("GitHub Actionsのビルド完了・失敗"); nm.createNotificationChannel(ch);
    }

    private void maybeRequestNotificationPermission(){
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            try{ requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},9201); }catch(Exception ignored){}
        }
    }

    private boolean canNotify(){ return Build.VERSION.SDK_INT<33 || checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED; }

    private void notifyBuildSuccess(String appName,String version,String apkName,Uri apkUri,long runId,String repo){
        if(!canNotify())return;
        try{
            NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE); if(nm==null)return;
            Intent install=new Intent(Intent.ACTION_VIEW); install.setDataAndType(apkUri,"application/vnd.android.package-archive"); install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);
            PendingIntent pi=PendingIntent.getActivity(this,(int)(runId&0x7fffffff),install,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            String title=(notEmpty(appName)?appName:"APK")+(notEmpty(version)?" "+version:"")+" ビルド完了";
            Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,NOTIFICATION_CHANNEL):new Notification.Builder(this);
            b.setSmallIcon(android.R.drawable.stat_sys_download_done).setContentTitle(title).setContentText(apkName).setAutoCancel(true).setContentIntent(pi).addAction(android.R.drawable.ic_menu_view,"インストール",pi);
            nm.notify((int)(runId&0x7fffffff),b.build());
            DiagnosticLog.log("NOTIFY success run="+runId+" repo="+repo+" apk="+apkName);
        }catch(Exception e){DiagnosticLog.error("NOTIFY success",e);}
    }

    private void notifyBuildFailure(String message,long runId,String repo){
        if(!canNotify())return;
        try{
            NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE); if(nm==null)return;
            Intent open=new Intent(this,MainActivity.class); open.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi=PendingIntent.getActivity(this,(int)((runId>0?runId:System.currentTimeMillis())&0x7fffffff),open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,NOTIFICATION_CHANNEL):new Notification.Builder(this);
            b.setSmallIcon(android.R.drawable.stat_notify_error).setContentTitle("GitBuild ビルド失敗").setContentText(message).setStyle(new Notification.BigTextStyle().bigText(message)).setAutoCancel(true).setContentIntent(pi).addAction(android.R.drawable.ic_menu_view,"開く",pi);
            nm.notify((int)((runId>0?runId:System.currentTimeMillis())&0x7fffffff),b.build());
            DiagnosticLog.log("NOTIFY failure run="+runId+" repo="+repo);
        }catch(Exception e){DiagnosticLog.error("NOTIFY failure",e);}
    }

    private void showUsage(){
        final Dialog d=new Dialog(this);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(18),dp(18),dp(18),dp(18)); box.setBackground(round(GRAY,12));
        TextView title=text("使用方法",20,true); box.addView(title,new LinearLayout.LayoutParams(-1,dp(42)));
        String guide=
                "基本の使い方\n\n"+
                "1. source用ZIPとGitHub Actionsの .yml / .yaml をGitBuildへ共有します。ChatGPTからDownloadしたsource.zipは「開く」からGitBuildを選ぶこともできます。受信ファイル欄をタップしたエクスプローラはDownloadから開き、対象ファイルは作成日時の新しい順に並びます。ZIPの元ファイル名は自由です。GitHubへ送る際は自動で source.zip に統一します。\n\n"+
                "2. 「受信ファイルからリポジトリ名の近似値を取得」がONなら、source.zipに加えてYAML内のworkflow名・APK/ZIP名・repository指定なども候補にしてリポジトリを自動選択します。十分に一致しない場合は未選択のままです。「リポジトリ」欄をタップして手動選択もできます。既存リポジトリを選択すると「名前変更」が有効になり、名前とPublic / Privateを変更できます。「新規作成」にも同じ位置にPublic / Privateトグルがあり、初期値はPublicです。\n\n"+
                "3. 「緊急停止時、前の状態にリカバリー」は緊急停止ボタンの下にあり、初期値はONです。緊急停止した場合のみ、GitBuildが投入する直前と同じリポジトリ内容へ戻します。通常のビルド成功時は戻しません。途中で別の更新を検出した場合は上書きしません。\n\n"+
                "4. 「アップロード＆ビルド」を押すと、source.zipやworkflowをGitHubへ更新し、Actionsの完了まで監視します。YAML単体でもworkflow更新できます。受信YAMLは .github/workflows/build-apk.yml に統一し、setup-android@v1〜v3はv4へ補正します。同じsource.zipをビルドする旧workflowが残っている場合は重複発火しないよう自動整理します。ボタン直下の「ビルド完了時、source.zipをリネーム」は初期値ONです。\n\n"+
                "5. 成功するとArtifact内のAPKを検証してDownloadへ保存します。共有されたsource ZIPの保存コピーもDownloadへ保存します。リネームONなら <AppName>_<version>_source.zip（例: GitBuild_0.1.36_source.zip）、OFFなら source.zip のまま保存します。完了時はビルド状態とトーストに最終ファイル名を表示します。共有元ファイルそのものとGitHubへ送る source.zip の名前は変更しません。ビルド状態欄の「実行」からAPKを開けます。\n\n"+
                "6. source.zipは受信時にアプリ名 / versionName / package名を解析し、YAML単体ではリポジトリ名候補を解析します。選択リポジトリとの一致度が低い場合は、アップロード前に警告します。同じsource内容が既にリポジトリにある場合は空コミットを作らず、workflow_dispatchで直接ビルドします。\n\n"+
                "7. Actionsが失敗した場合は失敗Job・失敗Step・ログ末尾を自動取得し、「エラー詳細」「ChatGPTへ共有」「失敗Job再実行」を表示します。再実行ではsource.zipを再アップロードしません。\n\n"+
                "8. source.zip更新後のpushでActions Runが数秒以内に見つからない場合は、workflow_dispatchへ自動で切り替えてビルドを開始します。Actions Runを検出後はバックグラウンド監視サービスでも監視し、アプリ画面を閉じても継続します。完了時は通知し、成功通知の「インストール」からAPKを開けます。「アップロード＆ビルド」の下は左が「緊急停止」、右が「クリア」です。「クリア」で受信ファイル・リポジトリ・ビルド状態をまとめて初期化できます。ビルド中はクリアできません。\n\n"+
                "GitHub OAuth Appの作成\n\n"+
                "1. GitHubを開き、Settings → Developer settings → OAuth Apps → New OAuth App へ進みます。\n\n"+
                "2. Application name: GitBuild\n"+
                "   Homepage URL: https://github.com\n"+
                "   Redirect URI: "+CALLBACK_BASE+"\n"+
                "   Wildcard matching: OFF\n"+
                "   Device Flow: OFF\n\n"+
                "3. Register application後に表示されるClient IDをコピーします。\n\n"+
                "4. Generate a new client secretでClient Secretを生成します。Secretはパスワードと同様の秘密情報です。スクリーンショットや共有をせず、GitBuildへ直接貼り付けてください。\n\n"+
                "5. GitBuildの「OAuth設定」にClient ID / Client Secretを保存し、「GitHubでログイン」から認証します。GitHubのログイン名・パスワードをGitBuildへ入力する必要はありません。";
        TextView body=text(guide,14,false); body.setGravity(Gravity.TOP|Gravity.START); body.setLineSpacing(0,1.08f); body.setTextIsSelectable(true);
        ScrollView scroll=new ScrollView(this); scroll.addView(body,new ScrollView.LayoutParams(-1,-2)); box.addView(scroll,new LinearLayout.LayoutParams(-1,0,1f));
        box.addView(space(12));
        LinearLayout buttons=row(); Button open=button("OAuth Appsを開く",ORANGE), close=button("閉じる",DGRAY);
        buttons.addView(open,new LinearLayout.LayoutParams(0,dp(CONTROL_HEIGHT_DP),1f)); buttons.addView(gap()); buttons.addView(close,new LinearLayout.LayoutParams(dp(88),dp(CONTROL_HEIGHT_DP))); box.addView(buttons);
        open.setOnClickListener(v->openUrl("https://github.com/settings/developers")); close.setOnClickListener(v->d.dismiss());
        d.setContentView(box); d.show(); Window w=d.getWindow(); if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.setLayout((int)(getResources().getDisplayMetrics().widthPixels*0.94f),(int)(getResources().getDisplayMetrics().heightPixels*0.84f));}
    }

    private void openUrl(String url){
        try{
            Uri u=Uri.parse(url); DiagnosticLog.log("OPEN_URL host="+u.getHost()+" path="+u.getPath());
            startActivity(new Intent(Intent.ACTION_VIEW,u));
        }catch(Exception e){DiagnosticLog.error("OPEN_URL",e);error(e);}
    }

    private void showDiagnosticLog() {
        final Dialog d=new Dialog(this);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(18),dp(18),dp(18),dp(18)); box.setBackground(round(GRAY,12));
        TextView title=text("診断ログ",20,true); box.addView(title,new LinearLayout.LayoutParams(-1,dp(42)));
        TextView body=text(DiagnosticLog.report(this),12,false); body.setTextIsSelectable(true); body.setTypeface(android.graphics.Typeface.MONOSPACE); body.setGravity(Gravity.TOP|Gravity.START); body.setPadding(dp(12),dp(12),dp(12),dp(12)); body.setBackground(round(DGRAY,8));
        ScrollView scroll=new ScrollView(this); scroll.addView(body,new ScrollView.LayoutParams(-1,-2)); box.addView(scroll,new LinearLayout.LayoutParams(-1,0,1f));
        box.addView(space(12));
        LinearLayout buttons=row(); buttons.setGravity(Gravity.CENTER_VERTICAL);
        Button clear=diagnosticButton("ログ消去", RED); buttons.addView(clear,new LinearLayout.LayoutParams(dp(76),dp(DIAGNOSTIC_BUTTON_HEIGHT_DP)));
        Space stretch=new Space(this); buttons.addView(stretch,new LinearLayout.LayoutParams(0,1,1f));
        Button share=diagnosticButton(".txtを共有", LBLUE), copy=diagnosticButton("コピー", GRAY), close=diagnosticButton("閉じる", DGRAY);
        buttons.addView(share,new LinearLayout.LayoutParams(dp(86),dp(DIAGNOSTIC_BUTTON_HEIGHT_DP))); buttons.addView(hGap(5)); buttons.addView(copy,new LinearLayout.LayoutParams(dp(58),dp(DIAGNOSTIC_BUTTON_HEIGHT_DP))); buttons.addView(hGap(5)); buttons.addView(close,new LinearLayout.LayoutParams(dp(58),dp(DIAGNOSTIC_BUTTON_HEIGHT_DP))); box.addView(buttons,new LinearLayout.LayoutParams(-1,dp(DIAGNOSTIC_BUTTON_HEIGHT_DP)));
        clear.setOnClickListener(v->{ DiagnosticLog.clear(); DiagnosticLog.log("LOG cleared by user"); body.setText(DiagnosticLog.report(this)); });
        copy.setOnClickListener(v->{ ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE); cm.setPrimaryClip(ClipData.newPlainText("GitBuild diagnostic",DiagnosticLog.report(this))); toast("診断ログをコピーしました"); DiagnosticLog.log("LOG copied"); });
        share.setOnClickListener(v->shareDiagnosticLog()); close.setOnClickListener(v->d.dismiss());
        d.setContentView(box); Window w=d.getWindow(); if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent); w.setLayout((int)(getResources().getDisplayMetrics().widthPixels*0.96f),(int)(getResources().getDisplayMetrics().heightPixels*0.88f));} d.show(); if(d.getWindow()!=null)d.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels*0.96f),(int)(getResources().getDisplayMetrics().heightPixels*0.88f));
    }

    private void shareDiagnosticLog() {
        try {
            DiagnosticLog.log("LOG share requested");
            Uri u=Uri.parse("content://com.cmyk.gitbuild.diag/GitBuild_diagnostic.txt");
            Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_STREAM,u); i.putExtra(Intent.EXTRA_SUBJECT,"GitBuild diagnostic report"); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i,"診断ログを共有"));
        } catch(Exception e){ DiagnosticLog.error("LOG share",e); error(e); }
    }

    private static String safeIntentData(Intent i){
        if(i==null||i.getData()==null)return "null"; Uri u=i.getData(); return u.getScheme()+"://"+u.getHost()+u.getPath();
    }
    private static String tail(String s,int n){ if(s==null)return "null"; return s.length()<=n?s:s.substring(s.length()-n); }
    private static String randomUrlSafe(int bytes){byte[] b=new byte[bytes];new SecureRandom().nextBytes(b);return Base64.encodeToString(b,Base64.URL_SAFE|Base64.NO_PADDING|Base64.NO_WRAP);}
    private static String enc(String s) throws Exception{return URLEncoder.encode(s,"UTF-8").replace("+","%20");}
    private static boolean notEmpty(String s){return s!=null&&!s.isEmpty();}
    private void postStatus(String s){ui.post(()->status(s));}
    private void startBuildElapsedTimer(){
        buildStartedElapsedRealtime=SystemClock.elapsedRealtime();
        buildTimerRunning=true;
        ui.removeCallbacks(buildElapsedTicker);
        renderStatusText();
        ui.postDelayed(buildElapsedTicker,1000L);
    }
    private void stopBuildElapsedTimer(){
        if(buildTimerRunning) renderStatusText();
        buildTimerRunning=false;
        ui.removeCallbacks(buildElapsedTicker);
    }
    private String buildElapsedText(){
        long seconds=Math.max(0L,(SystemClock.elapsedRealtime()-buildStartedElapsedRealtime)/1000L);
        return String.format(Locale.US,"%02ds",seconds);
    }
    private void renderStatusText(){
        if(statusText==null) return;
        String base=statusBaseText==null?"":statusBaseText;
        int nl=base.indexOf('\n');
        String headline=nl>=0?base.substring(0,nl):base;
        String detail=nl>=0?base.substring(nl+1):"";
        statusText.setText(headline);
        if(statusDetailText!=null) statusDetailText.setText(detail);
        if(elapsedText!=null){
            if(buildTimerRunning) elapsedText.setText(buildElapsedText());
        }
    }
    private void status(String s){
        statusBaseText=s;
        if(!buildTimerRunning && elapsedText!=null) elapsedText.setText("");
        renderStatusText();
        if(statusCheck!=null)statusCheck.setVisibility(View.GONE);
        if(runApkButton!=null)runApkButton.setVisibility(View.GONE);
        refreshClearButtonState();
    }
    private void statusSuccess(String s, boolean allowRun){
        statusBaseText=s;
        if(!buildTimerRunning && elapsedText!=null) elapsedText.setText("");
        renderStatusText();
        if(statusCheck!=null)statusCheck.setVisibility(View.VISIBLE);
        if(runApkButton!=null)runApkButton.setVisibility(allowRun&&lastApkUri!=null?View.VISIBLE:View.GONE);
        refreshClearButtonState();
    }
    private void error(Exception e){DiagnosticLog.error("UI",e); status("エラー\n"+(e.getMessage()==null?e.getClass().getSimpleName():e.getMessage()));}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    private ShimmerTextView shimmerText(String s,int sp,boolean bold){ShimmerTextView v=new ShimmerTextView(this);v.setText(s);v.setTextColor(NEON_GREEN);v.setTextSize(sp);if(bold)v.setTypeface(null,1);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    private void styleNDialog(Dialog d){
        if(d==null)return;
        Window w=d.getWindow();
        if(w!=null){
            w.setBackgroundDrawable(round(GRAY,12));
            WindowManager.LayoutParams lp=w.getAttributes(); lp.dimAmount=0.58f; w.setAttributes(lp); w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        }
        if(d instanceof AlertDialog){
            AlertDialog a=(AlertDialog)d;
            int[] ids={AlertDialog.BUTTON_POSITIVE,AlertDialog.BUTTON_NEGATIVE,AlertDialog.BUTTON_NEUTRAL};
            for(int id:ids){Button b=a.getButton(id);if(b!=null){b.setTextColor(TEXT);b.setAllCaps(false);}}
            TextView msg=a.findViewById(android.R.id.message);if(msg!=null)msg.setTextColor(TEXT);
            int titleId=getResources().getIdentifier("alertTitle","id","android");View tv=titleId==0?null:a.findViewById(titleId);if(tv instanceof TextView)((TextView)tv).setTextColor(TEXT);
            ListView list=a.getListView();if(list!=null){list.setBackgroundColor(Color.TRANSPARENT);list.setDivider(new android.graphics.drawable.ColorDrawable(DGRAY));list.setDividerHeight(dp(1));}
        }
    }
    private TextView text(String s,int sp,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextColor(TEXT);v.setTextSize(sp);if(bold)v.setTypeface(null,1);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    private TextView label(String s){TextView v=text(s,12,false);v.setTextColor(WHITE);v.setPadding(0,0,0,dp(6));return v;}
    private EditText input(String hint,boolean password){EditText e=new EditText(this);e.setHint(hint);e.setTextColor(TEXT);e.setHintTextColor(WHITE);e.setSingleLine(true);e.setPadding(dp(12),0,dp(12),0);e.setBackground(round(DGRAY,8));if(password)e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);return e;}
    private View card(TextView content){ return mainFieldView(content,GRAY); }
    private View cardView(View content){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(14),dp(12),dp(14),dp(12));l.setBackground(round(GRAY,10));l.addView(content,new LinearLayout.LayoutParams(-1,-2));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(8));l.setLayoutParams(p);return l;}
    private View mainFieldView(View content,int color){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setGravity(Gravity.CENTER_VERTICAL);l.setPadding(dp(14),0,dp(14),0);l.setBackground(round(color,10));l.addView(content,new LinearLayout.LayoutParams(-1,-1));l.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(CONTROL_HEIGHT_DP)));return l;}
    private ImageButton menuIcon(){ImageButton v=new ImageButton(this);v.setImageResource(com.cmyk.gitbuild.R.drawable.ic_more_vert);v.setScaleType(ImageView.ScaleType.CENTER);v.setPadding(0,0,0,0);GradientDrawable g=new GradientDrawable();g.setColor(DGRAY);g.setShape(GradientDrawable.OVAL);v.setBackground(g);v.setElevation(0f);if(Build.VERSION.SDK_INT>=21)v.setStateListAnimator(null);v.setClickable(true);v.setFocusable(true);v.setContentDescription("メニュー");return v;}
    private Button button(String s,int color){Button b=new Button(this);b.setText(s);b.setTextColor(TEXT);b.setTextSize(14);b.setAllCaps(false);b.setGravity(Gravity.CENTER);b.setIncludeFontPadding(false);b.setPadding(dp(10),0,dp(10),0);b.setMinHeight(0);b.setMinimumHeight(0);b.setMinWidth(0);b.setMinimumWidth(0);b.setElevation(0f);if(Build.VERSION.SDK_INT>=21)b.setStateListAnimator(null);b.setBackground(buttonBackground(color));return b;}
    private Button diagnosticButton(String s,int color){Button b=button(s,color);b.setTextSize(11);b.setPadding(dp(9),0,dp(9),0);return b;}
    private GradientDrawable buttonBackground(int color){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(CONTROL_HEIGHT_DP)/2f);return g;}
    private GradientDrawable round(int c,int r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));return g;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);return l;} private LinearLayout.LayoutParams weight(){return new LinearLayout.LayoutParams(0,dp(CONTROL_HEIGHT_DP),1f);} private View gap(){return hGap(BUTTON_GAP_DP);} private View hGap(int w){Space s=new Space(this);s.setLayoutParams(new LinearLayout.LayoutParams(dp(w),1));return s;} private View space(int h){Space s=new Space(this);s.setLayoutParams(new LinearLayout.LayoutParams(1,dp(h)));return s;}
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);} private static String human(long b){if(b<1024)return b+" B";if(b<1024*1024)return String.format(Locale.US,"%.1f KB",b/1024f);return String.format(Locale.US,"%.1f MB",b/1048576f);}
}
