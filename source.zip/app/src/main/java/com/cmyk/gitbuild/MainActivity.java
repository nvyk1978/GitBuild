package com.cmyk.gitbuild;

import android.app.*;
import android.content.*;
import android.content.ContentValues;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.view.*;
import android.widget.*;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class MainActivity extends Activity {
    private static final int BG=Color.rgb(48,48,48), DGRAY=Color.rgb(37,32,32), GRAY=Color.rgb(69,64,64),
            LGRAY=Color.rgb(101,96,96), BLUE=Color.rgb(34,51,85), LBLUE=Color.rgb(68,85,119),
            ORANGE=Color.rgb(119,85,0), WHITE=Color.rgb(169,169,153), GREEN=Color.rgb(34,119,51), TEXT=Color.WHITE;
    private final List<SharedItem> shared = new ArrayList<>();
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private SecureTokenStore tokenStore;
    private GitHubApi.Repo selectedRepo;
    private TextView filesText, repoText, statusText;
    private Button buildButton;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b); tokenStore = new SecureTokenStore(this); buildUi(); acceptIntent(getIntent());
    }
    @Override protected void onNewIntent(Intent i) { super.onNewIntent(i); setIntent(i); acceptIntent(i); }
    @Override protected void onDestroy() { io.shutdownNow(); super.onDestroy(); }

    private void buildUi() {
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(18),dp(18),dp(18)); root.setBackgroundColor(BG);
        TextView title=text("GitBuild",24,true); root.addView(title,new LinearLayout.LayoutParams(-1,-2));
        root.addView(space(14));
        root.addView(label("受信ファイル")); filesText=text("source.zip と .yml を共有してください",15,false); root.addView(card(filesText));
        root.addView(space(12));
        root.addView(label("リポジトリ")); repoText=text("未選択",15,false); root.addView(card(repoText));
        LinearLayout repoButtons=row(); Button select=button("選択", LBLUE), create=button("新規作成", ORANGE); repoButtons.addView(select,weight()); repoButtons.addView(gap()); repoButtons.addView(create,weight()); root.addView(repoButtons);
        root.addView(space(12));
        root.addView(label("ビルド状態")); statusText=text("待機中",15,false); root.addView(card(statusText));
        root.addView(space(12));
        buildButton=button("アップロード＆ビルド", BLUE); root.addView(buildButton,new LinearLayout.LayoutParams(-1,dp(48)));
        root.addView(space(10)); Button settings=button("GitHub設定", GRAY); root.addView(settings,new LinearLayout.LayoutParams(-1,dp(44)));
        select.setOnClickListener(v->loadRepos()); create.setOnClickListener(v->createRepoDialog()); settings.setOnClickListener(v->tokenDialog()); buildButton.setOnClickListener(v->startBuild());
        ScrollView sv=new ScrollView(this); sv.addView(root); setContentView(sv);
    }

    private void acceptIntent(Intent intent) {
        String a=intent.getAction(); if(!Intent.ACTION_SEND.equals(a)&&!Intent.ACTION_SEND_MULTIPLE.equals(a)) return;
        shared.clear();
        if(Intent.ACTION_SEND.equals(a)) { Uri u=intent.getParcelableExtra(Intent.EXTRA_STREAM); if(u!=null) addUri(u); }
        else { ArrayList<Uri> us=intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM); if(us!=null) for(Uri u:us) addUri(u); }
        refreshFiles();
    }
    private void addUri(Uri u) {
        String name="shared_file"; long size=-1;
        try(Cursor c=getContentResolver().query(u,new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE},null,null,null)) {
            if(c!=null&&c.moveToFirst()){ name=c.getString(0); size=c.isNull(1)?-1:c.getLong(1); }
        } catch(Exception ignored){}
        shared.add(new SharedItem(u,name,size));
    }
    private void refreshFiles(){ StringBuilder s=new StringBuilder(); for(SharedItem f:shared) s.append("✓ ").append(f.name).append(f.size>=0?"   "+human(f.size):"").append("\n"); filesText.setText(s.length()==0?"source.zip と .yml を共有してください":s.toString().trim()); }

    private void tokenDialog() {
        final EditText e=new EditText(this); e.setTextColor(TEXT); e.setHintTextColor(WHITE); e.setHint("Fine-grained PAT"); e.setSingleLine(true); e.setInputType(0x81); e.setPadding(dp(12),0,dp(12),0); e.setBackgroundColor(GRAY);
        String t=tokenStore.load(); if(t!=null&&!t.isEmpty()) e.setText(t);
        new AlertDialog.Builder(this).setTitle("GitHub認証").setMessage("Contents / Workflows / Actions を操作できるPATを設定します。端末内ではAndroid Keystoreで暗号化します。")
                .setView(e).setNegativeButton("キャンセル",null).setPositiveButton("保存",(d,w)->{try{tokenStore.save(e.getText().toString().trim()); toast("保存しました");}catch(Exception ex){error(ex);}}).show();
    }

    private GitHubApi api() throws Exception { String t=tokenStore.load(); if(t==null||t.isEmpty()) throw new Exception("GitHub設定でPATを登録してください"); return new GitHubApi(t); }
    private void loadRepos() {
        status("リポジトリ取得中…"); io.execute(()->{ try { List<GitHubApi.Repo> repos=api().listRepos(); ui.post(()->showRepoPicker(repos)); } catch(Exception e){ ui.post(()->error(e)); } });
    }
    private void showRepoPicker(List<GitHubApi.Repo> repos) {
        status("待機中"); String[] names=new String[repos.size()]; for(int i=0;i<names.length;i++) names[i]=repos.get(i).fullName;
        new AlertDialog.Builder(this).setTitle("リポジトリ選択").setItems(names,(d,which)->{selectedRepo=repos.get(which); repoText.setText(selectedRepo.fullName);}).setNegativeButton("キャンセル",null).show();
    }
    private void createRepoDialog() {
        EditText e=new EditText(this); e.setHint("repository-name"); e.setSingleLine(true);
        new AlertDialog.Builder(this).setTitle("新規リポジトリ").setMessage("初期版ではPrivate + README初期化で作成します。")
                .setView(e).setNegativeButton("キャンセル",null).setPositiveButton("作成",(d,w)->{String name=e.getText().toString().trim(); if(name.isEmpty())return; status("作成中…"); io.execute(()->{try{GitHubApi.Repo r=api().createRepo(name,true); ui.post(()->{selectedRepo=r; repoText.setText(r.fullName); status("作成完了");});}catch(Exception ex){ui.post(()->error(ex));}});}).show();
    }

    private void startBuild() {
        if(shared.isEmpty()){toast("source.zip と .yml を共有してください");return;} if(selectedRepo==null){toast("リポジトリを選択してください");return;}
        buildButton.setEnabled(false); status("アップロード中…");
        io.execute(()->{ try {
            GitHubApi a=api(); String sha=a.commitFiles(selectedRepo,shared,getContentResolver()); postStatus("コミット完了 / Actions待機中…");
            GitHubApi.Run run=null; for(int i=0;i<30&&run==null;i++){ if(i>0)Thread.sleep(3000); run=a.findRun(selectedRepo.fullName,sha); }
            if(run==null) throw new Exception("このコミットから起動したActionsが見つかりません。workflowの on: push を確認してください");
            long id=run.id;
            while(!"completed".equals(run.status)){ postStatus("Actions: "+run.status+"  #"+id); Thread.sleep(5000); run=a.getRun(selectedRepo.fullName,id); }
            if(!"success".equals(run.conclusion)) throw new Exception("Actions終了: "+run.conclusion+"  (#"+id+")");
            postStatus("ビルド成功 / APK取得中…"); List<GitHubApi.Artifact> arts=a.artifacts(selectedRepo.fullName,id); if(arts.isEmpty()) throw new Exception("Artifactがありません");
            GitHubApi.Artifact chosen=arts.get(0); for(GitHubApi.Artifact x:arts) if(x.name.toLowerCase().contains("apk")){chosen=x;break;}
            byte[] zip=a.downloadArtifact(selectedRepo.fullName,chosen.id); List<String> saved=saveApks(zip); if(saved.isEmpty()) throw new Exception("Artifact内に.apkがありません");
            String names=String.join(", ",saved); ui.post(()->{status("✓ 完了\nDownloads: "+names); buildButton.setEnabled(true);});
        } catch(Exception e){ ui.post(()->{buildButton.setEnabled(true); error(e);}); } });
    }

    private List<String> saveApks(byte[] zipBytes) throws Exception {
        List<String> saved=new ArrayList<>(); try(ZipInputStream zin=new ZipInputStream(new ByteArrayInputStream(zipBytes))) {
            ZipEntry z; byte[] buf=new byte[32768]; while((z=zin.getNextEntry())!=null){ if(z.isDirectory()||!z.getName().toLowerCase().endsWith(".apk"))continue; String name=z.getName(); int slash=name.lastIndexOf('/'); if(slash>=0)name=name.substring(slash+1);
                ContentValues v=new ContentValues(); v.put(MediaStore.Downloads.DISPLAY_NAME,name); v.put(MediaStore.Downloads.MIME_TYPE,"application/vnd.android.package-archive"); v.put(MediaStore.Downloads.RELATIVE_PATH,"Download");
                Uri u=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v); if(u==null)throw new Exception("Downloadsへ保存できません");
                try(OutputStream out=getContentResolver().openOutputStream(u)){int n;while((n=zin.read(buf))>=0)out.write(buf,0,n);} saved.add(name);
            }
        } return saved;
    }

    private void postStatus(String s){ui.post(()->status(s));} private void status(String s){statusText.setText(s);} private void error(Exception e){status("エラー\n"+e.getMessage());}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    private TextView text(String s,int sp,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextColor(TEXT);v.setTextSize(sp);if(bold)v.setTypeface(null,1);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    private TextView label(String s){TextView v=text(s,12,false);v.setTextColor(WHITE);v.setPadding(0,0,0,dp(6));return v;}
    private View card(TextView content){LinearLayout l=new LinearLayout(this);l.setPadding(dp(14),dp(12),dp(14),dp(12));l.setBackground(round(GRAY,10));l.addView(content,new LinearLayout.LayoutParams(-1,-2));return l;}
    private Button button(String s,int color){Button b=new Button(this);b.setText(s);b.setTextColor(TEXT);b.setTextSize(14);b.setAllCaps(false);b.setBackground(round(color,24));return b;}
    private GradientDrawable round(int c,int r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));return g;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setPadding(0,dp(8),0,0);return l;} private LinearLayout.LayoutParams weight(){return new LinearLayout.LayoutParams(0,dp(44),1);} private View gap(){View v=new View(this);v.setLayoutParams(new LinearLayout.LayoutParams(dp(8),1));return v;} private View space(int h){Space s=new Space(this);s.setLayoutParams(new LinearLayout.LayoutParams(1,dp(h)));return s;}
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);} private static String human(long b){if(b<1024)return b+" B";if(b<1024*1024)return String.format(Locale.US,"%.1f KB",b/1024f);return String.format(Locale.US,"%.1f MB",b/1048576f);}
}
