package com.cmyk.gitbuild;

import android.app.*;
import android.content.*;
import android.content.ContentValues;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.util.Base64;
import android.view.*;
import android.widget.*;

import java.io.ByteArrayInputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class MainActivity extends Activity {
    private static final int BG=Color.rgb(48,48,48), DGRAY=Color.rgb(37,32,32), GRAY=Color.rgb(69,64,64),
            LGRAY=Color.rgb(101,96,96), BLUE=Color.rgb(34,51,85), LBLUE=Color.rgb(68,85,119),
            ORANGE=Color.rgb(119,85,0), WHITE=Color.rgb(169,169,153), GREEN=Color.rgb(34,119,51), TEXT=Color.WHITE;
    private static final String CALLBACK_BASE = "http://127.0.0.1/callback";
    private static final String RETURN_URI = "gitbuild://oauth/return";
    private final List<SharedItem> shared = new ArrayList<>();
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private SecureStore store;
    private GitHubApi.Repo selectedRepo;
    private TextView filesText, repoText, statusText, authText;
    private Button buildButton, authButton;
    private OAuthLoopbackServer oauthServer;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        DiagnosticLog.init(this);
        DiagnosticLog.log("APP onCreate action="+(getIntent()==null?"null":getIntent().getAction())+" data="+safeIntentData(getIntent()));
        store = new SecureStore(this); buildUi(); acceptIntent(getIntent()); handleReturnIntent(getIntent()); refreshAuthUi();
        DiagnosticLog.log("AUTH startup configured="+isConfigured()+" loggedIn="+isLoggedIn()+" pending="+notEmpty(store.getString("oauth_state")));
    }
    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i); setIntent(i);
        DiagnosticLog.log("APP onNewIntent action="+(i==null?"null":i.getAction())+" data="+safeIntentData(i));
        acceptIntent(i); handleReturnIntent(i);
    }
    @Override protected void onResume() {
        super.onResume();
        DiagnosticLog.log("APP onResume loggedIn="+isLoggedIn()+" pending="+notEmpty(store.getString("oauth_state")));
        refreshAuthUi(); showOAuthStateIfNeeded();
    }
    @Override protected void onDestroy() {
        DiagnosticLog.log("APP onDestroy changingConfig="+isChangingConfigurations()+" server="+(oauthServer!=null));
        if(oauthServer!=null) oauthServer.close(); io.shutdownNow(); super.onDestroy();
    }

    private void buildUi() {
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(18),dp(18),dp(18)); root.setBackgroundColor(BG);
        LinearLayout titleRow=row();
        TextView title=text("GitBuild",24,true); titleRow.addView(title,new LinearLayout.LayoutParams(0,dp(44),1f));
        Button menu=button("⋮", DGRAY); menu.setTextColor(WHITE); menu.setTextSize(22); menu.setPadding(0,0,0,0);
        titleRow.addView(menu,new LinearLayout.LayoutParams(dp(44),dp(44))); root.addView(titleRow,new LinearLayout.LayoutParams(-1,dp(44)));
        menu.setOnClickListener(v->{ PopupMenu pm=new PopupMenu(this,menu); pm.getMenu().add("診断ログ"); pm.setOnMenuItemClickListener(item->{showDiagnosticLog();return true;}); pm.show(); });
        TextView ver=text("0.1.3",12,false); ver.setTextColor(WHITE); root.addView(ver);
        root.addView(space(14));

        root.addView(label("GitHub")); authText=text("未ログイン",15,false); root.addView(card(authText));
        LinearLayout authButtons=row(); authButton=button("GitHubでログイン", LBLUE); Button settings=button("OAuth設定", GRAY);
        authButtons.addView(authButton,weight()); authButtons.addView(gap()); authButtons.addView(settings,weight()); root.addView(authButtons);
        authButton.setOnClickListener(v->{ if(isLoggedIn()) logout(); else beginLogin(); });
        settings.setOnClickListener(v->oauthSettingsDialog());

        root.addView(space(14));
        root.addView(label("受信ファイル")); filesText=text("source.zip と .yml を共有してください",15,false); root.addView(card(filesText));
        root.addView(space(12));
        root.addView(label("リポジトリ")); repoText=text("未選択",15,false); root.addView(card(repoText));
        LinearLayout repoButtons=row(); Button select=button("選択", LBLUE), create=button("新規作成", ORANGE); repoButtons.addView(select,weight()); repoButtons.addView(gap()); repoButtons.addView(create,weight()); root.addView(repoButtons);
        root.addView(space(12));
        root.addView(label("ビルド状態")); statusText=text("待機中",15,false); root.addView(card(statusText));
        root.addView(space(12));
        buildButton=button("アップロード＆ビルド", BLUE); root.addView(buildButton,new LinearLayout.LayoutParams(-1,dp(48)));
        select.setOnClickListener(v->loadRepos()); create.setOnClickListener(v->createRepoDialog()); buildButton.setOnClickListener(v->startBuild());
        ScrollView sv=new ScrollView(this); sv.addView(root); setContentView(sv);
    }

    private void acceptIntent(Intent intent) {
        if(intent==null) return;
        String a=intent.getAction(); if(!Intent.ACTION_SEND.equals(a)&&!Intent.ACTION_SEND_MULTIPLE.equals(a)) return;
        DiagnosticLog.log("SHARE receive action="+a+" type="+intent.getType());
        shared.clear();
        if(Intent.ACTION_SEND.equals(a)) { Uri u=intent.getParcelableExtra(Intent.EXTRA_STREAM); if(u!=null) addUri(u); }
        else { ArrayList<Uri> us=intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM); if(us!=null) for(Uri u:us) addUri(u); }
        refreshFiles();
    }
    private void addUri(Uri u) {
        String name="shared_file"; long size=-1;
        try(Cursor c=getContentResolver().query(u,new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE},null,null,null)) {
            if(c!=null&&c.moveToFirst()){ name=c.getString(0); size=c.isNull(1)?-1:c.getLong(1); }
        } catch(Exception ignored){}
        shared.add(new SharedItem(u,name,size));
        DiagnosticLog.log("SHARE item name="+name+" size="+size+" uriScheme="+(u==null?"null":u.getScheme()));
    }
    private void refreshFiles(){ StringBuilder s=new StringBuilder(); for(SharedItem f:shared) s.append("✓ ").append(f.name).append(f.size>=0?"   "+human(f.size):"").append("\n"); filesText.setText(s.length()==0?"source.zip と .yml を共有してください":s.toString().trim()); }

    private boolean isConfigured(){ return notEmpty(store.getString("client_id")) && notEmpty(store.getSecret("client_secret")); }
    private boolean isLoggedIn(){ return notEmpty(store.getSecret("access_token")); }
    private void refreshAuthUi(){
        if(isLoggedIn()) { String login=store.getString("login"); authText.setText("✓ ログイン中"+(notEmpty(login)?" : "+login:"")); authButton.setText("ログアウト"); authButton.setBackground(round(DGRAY,10)); }
        else if(notEmpty(store.getString("oauth_state"))) { authText.setText("GitHub認証処理中…"); authButton.setText("GitHubでログイン"); authButton.setBackground(round(LBLUE,10)); }
        else { authText.setText(isConfigured()?"未ログイン":"OAuth App未設定"); authButton.setText("GitHubでログイン"); authButton.setBackground(round(LBLUE,10)); }
    }

    private void showOAuthStateIfNeeded() {
        if(isLoggedIn()) return;
        String err=store.getString("oauth_last_error");
        if(notEmpty(err)) status("OAuthエラー\n"+err);
        else if(notEmpty(store.getString("oauth_state"))) status("GitHubログイン処理中…");
    }

    private void handleReturnIntent(Intent intent) {
        Uri d=intent==null?null:intent.getData();
        if(d==null || !"gitbuild".equalsIgnoreCase(d.getScheme()) || !"oauth".equalsIgnoreCase(d.getHost())) return;
        DiagnosticLog.log("OAUTH return intent path="+d.getPath()+" loggedIn="+isLoggedIn()+" lastError="+notEmpty(store.getString("oauth_last_error")));
        refreshAuthUi();
        if(isLoggedIn()) status("✓ GitHubログイン完了");
        else if(notEmpty(store.getString("oauth_last_error"))) status("OAuthエラー\n"+store.getString("oauth_last_error"));
        else status("GitHubログイン処理中…");
    }

    private void oauthSettingsDialog() {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(18),dp(4),dp(18),0);
        TextView info=text("GitHub OAuth Appを1つ作成し、下のRedirect URIを登録してください。GitHubのログイン名・パスワードではありません。PATも不要です。",13,false); info.setTextColor(WHITE); box.addView(info);
        TextView cb=text(CALLBACK_BASE,13,false); cb.setTextColor(TEXT); cb.setPadding(0,dp(10),0,dp(10)); cb.setTextIsSelectable(true); box.addView(cb);
        EditText id=input("Client ID", false); String oldId=store.getString("client_id"); if(oldId!=null)id.setText(oldId); box.addView(id,new LinearLayout.LayoutParams(-1,dp(52)));
        box.addView(space(8));
        EditText secret=input("Client Secret", true); String oldSecret=store.getSecret("client_secret"); if(oldSecret!=null)secret.setText(oldSecret); box.addView(secret,new LinearLayout.LayoutParams(-1,dp(52)));
        AlertDialog d=new AlertDialog.Builder(this).setTitle("OAuth設定").setView(box)
                .setNegativeButton("キャンセル",null)
                .setNeutralButton("OAuth App作成",null)
                .setPositiveButton("保存",null).create();
        d.setOnShowListener(x->{
            d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->openUrl("https://github.com/settings/applications/new"));
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
                String nid=id.getText().toString().trim(), ns=secret.getText().toString().trim();
                if(nid.isEmpty()||ns.isEmpty()){toast("Client ID と Client Secret を入力してください");return;}
                try {
                    boolean changed=!nid.equals(store.getString("client_id")) || !ns.equals(store.getSecret("client_secret"));
                    DiagnosticLog.log("OAUTH settings save changed="+changed+" clientIdTail="+tail(nid,4)+" secretPresent="+(!ns.isEmpty()));
                    store.putString("client_id",nid); store.putSecret("client_secret",ns);
                    if(changed) { store.clearTokens(); store.clearOAuthPending(); store.remove("oauth_last_error"); }
                    refreshAuthUi(); d.dismiss(); toast("OAuth設定を保存しました");
                } catch(Exception e){error(e);}
            });
        }); d.show();
    }

    private void beginLogin() {
        DiagnosticLog.log("OAUTH begin configured="+isConfigured()+" loggedIn="+isLoggedIn());
        if(!isConfigured()){ DiagnosticLog.log("OAUTH begin blocked: not configured"); oauthSettingsDialog(); return; }
        try {
            if(oauthServer!=null) oauthServer.close();
            String state=randomUrlSafe(32), verifier=randomUrlSafe(64);
            String challenge=Base64.encodeToString(MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII)), Base64.URL_SAFE|Base64.NO_PADDING|Base64.NO_WRAP);
            oauthServer=new OAuthLoopbackServer(RETURN_URI,(code,returnedState,err)->ui.post(()->handleOAuthCallback(code,returnedState,err)));
            String redirect="http://127.0.0.1:"+oauthServer.port()+"/callback";
            DiagnosticLog.log("OAUTH loopback started port="+oauthServer.port()+" returnUri="+RETURN_URI);
            store.putString("oauth_state",state);
            store.putString("oauth_redirect",redirect);
            store.putSecret("oauth_verifier",verifier);
            store.putLong("oauth_started_at",System.currentTimeMillis());
            store.remove("oauth_last_error");
            String url="https://github.com/login/oauth/authorize?client_id="+enc(store.getString("client_id"))+
                    "&redirect_uri="+enc(redirect)+"&scope="+enc("repo workflow offline_access")+
                    "&state="+enc(state)+"&code_challenge="+enc(challenge)+"&code_challenge_method=S256&prompt=select_account";
            refreshAuthUi(); status("GitHub認証待ち…"); DiagnosticLog.log("OAUTH browser launch redirect="+redirect+" stateLen="+state.length()+" verifierLen="+verifier.length()); openUrl(url);
        } catch(Exception e){oauthFailure(e);}
    }

    private void handleOAuthCallback(String code,String state,String err) {
        String expected=store.getString("oauth_state");
        DiagnosticLog.log("OAUTH callback codePresent="+notEmpty(code)+" statePresent="+notEmpty(state)+" errorPresent="+notEmpty(err)+" expectedStatePresent="+notEmpty(expected));
        String redirect=store.getString("oauth_redirect");
        String verifier=store.getSecret("oauth_verifier");
        if(err!=null){oauthFailure(new Exception("OAuth: "+err));return;}
        if(code==null||state==null||!state.equals(expected)){ DiagnosticLog.log("OAUTH state validation failed match="+(state!=null&&state.equals(expected))); oauthFailure(new Exception("OAuth stateが一致しません"));return;}
        if(!notEmpty(redirect)||!notEmpty(verifier)){ DiagnosticLog.log("OAUTH pending session lost redirect="+notEmpty(redirect)+" verifier="+notEmpty(verifier)); oauthFailure(new Exception("OAuthセッション情報が失われました。もう一度ログインしてください"));return;}
        DiagnosticLog.log("OAUTH callback validated redirect="+redirect+" verifierPresent=true");
        status("GitHubログイン処理中…");
        io.execute(()->{ try {
            DiagnosticLog.log("OAUTH token exchange start clientIdTail="+tail(store.getString("client_id"),4));
            GitHubOAuth.TokenResult t=GitHubOAuth.exchange(store.getString("client_id"),store.getSecret("client_secret"),code,redirect,verifier);
            DiagnosticLog.log("OAUTH token exchange success refreshPresent="+notEmpty(t.refreshToken)+" accessExpiresAt="+t.accessExpiresAt);
            GitHubApi a=new GitHubApi(t.accessToken);
            DiagnosticLog.log("OAUTH /user lookup start");
            String login=a.getLogin();
            DiagnosticLog.log("OAUTH /user lookup success login="+login);
            saveTokens(t);
            store.putString("login",login);
            store.clearOAuthPending();
            store.remove("oauth_last_error");
            ui.post(()->{refreshAuthUi();status("✓ GitHubログイン完了");toast("GitHubにログインしました"); DiagnosticLog.log("OAUTH login completed");});
        } catch(Exception e){ui.post(()->oauthFailure(e));} });
    }

    private void oauthFailure(Exception e) {
        DiagnosticLog.error("OAUTH",e);
        String msg=e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();
        store.clearOAuthPending();
        store.putString("oauth_last_error",msg);
        refreshAuthUi();
        status("OAuthエラー\n"+msg);
    }

    private void logout(){ DiagnosticLog.log("AUTH logout"); store.clearTokens(); store.clearOAuthPending(); store.remove("oauth_last_error"); selectedRepo=null; repoText.setText("未選択"); refreshAuthUi(); status("ログアウトしました"); }

    private void saveTokens(GitHubOAuth.TokenResult t) throws Exception {
        store.putSecret("access_token",t.accessToken); store.putLong("access_expires_at",t.accessExpiresAt);
        store.putSecret("refresh_token",t.refreshToken); store.putLong("refresh_expires_at",t.refreshExpiresAt);
    }

    private GitHubApi api() throws Exception {
        String token=store.getSecret("access_token"); if(!notEmpty(token)) throw new Exception("先に「GitHubでログイン」してください");
        long exp=store.getLong("access_expires_at",0); String refresh=store.getSecret("refresh_token");
        if(exp>0 && System.currentTimeMillis()>exp-300000L && notEmpty(refresh)) {
            DiagnosticLog.log("OAUTH access token refresh start");
            GitHubOAuth.TokenResult t=GitHubOAuth.refresh(store.getString("client_id"),store.getSecret("client_secret"),refresh); saveTokens(t); token=t.accessToken; DiagnosticLog.log("OAUTH access token refresh success");
        }
        return new GitHubApi(token);
    }

    private void loadRepos() {
        if(!isLoggedIn()){toast("先にGitHubへログインしてください");return;}
        DiagnosticLog.log("REPO list start"); status("リポジトリ取得中…"); io.execute(()->{ try { List<GitHubApi.Repo> repos=api().listRepos(); DiagnosticLog.log("REPO list success count="+repos.size()); ui.post(()->showRepoPicker(repos)); } catch(Exception e){ DiagnosticLog.error("REPO list",e); ui.post(()->error(e)); } });
    }
    private void showRepoPicker(List<GitHubApi.Repo> repos) {
        status("待機中"); if(repos.isEmpty()){toast("リポジトリがありません");return;} String[] names=new String[repos.size()]; for(int i=0;i<names.length;i++) names[i]=repos.get(i).fullName;
        new AlertDialog.Builder(this).setTitle("リポジトリ選択").setItems(names,(d,which)->{selectedRepo=repos.get(which); repoText.setText(selectedRepo.fullName); DiagnosticLog.log("REPO selected "+selectedRepo.fullName);}).setNegativeButton("キャンセル",null).show();
    }
    private void createRepoDialog() {
        if(!isLoggedIn()){toast("先にGitHubへログインしてください");return;}
        EditText e=input("repository-name",false);
        new AlertDialog.Builder(this).setTitle("新規リポジトリ").setMessage("Private + README初期化で作成します。")
                .setView(e).setNegativeButton("キャンセル",null).setPositiveButton("作成",(d,w)->{String name=e.getText().toString().trim(); if(name.isEmpty())return; DiagnosticLog.log("REPO create start name="+name+" private=true"); status("作成中…"); io.execute(()->{try{GitHubApi.Repo r=api().createRepo(name,true); ui.post(()->{selectedRepo=r; repoText.setText(r.fullName); status("作成完了"); DiagnosticLog.log("REPO create success "+r.fullName);});}catch(Exception ex){DiagnosticLog.error("REPO create",ex);ui.post(()->error(ex));}});}).show();
    }

    private void startBuild() {
        if(!isLoggedIn()){toast("先にGitHubへログインしてください");return;} if(shared.isEmpty()){toast("source.zip と .yml を共有してください");return;} if(selectedRepo==null){toast("リポジトリを選択してください");return;}
        buildButton.setEnabled(false); status("アップロード中…");
        DiagnosticLog.log("BUILD start repo="+selectedRepo.fullName+" files="+shared.size());
        io.execute(()->{ try {
            GitHubApi a=api(); String sha=a.commitFiles(selectedRepo,shared,getContentResolver()); DiagnosticLog.log("BUILD commit success sha="+tail(sha,8)); postStatus("コミット完了 / Actions待機中…");
            GitHubApi.Run run=null; for(int i=0;i<40&&run==null;i++){ if(i>0)Thread.sleep(3000); run=a.findRun(selectedRepo.fullName,sha); }
            if(run==null) throw new Exception("このコミットから起動したActionsが見つかりません。workflowの on: push を確認してください");
            long id=run.id; DiagnosticLog.log("BUILD actions run found id="+id+" status="+run.status);
            while(!"completed".equals(run.status)){ DiagnosticLog.log("BUILD actions status id="+id+" status="+run.status); postStatus("Actions: "+run.status+"  #"+id); Thread.sleep(5000); a=api(); run=a.getRun(selectedRepo.fullName,id); }
            DiagnosticLog.log("BUILD actions completed id="+id+" conclusion="+run.conclusion);
            if(!"success".equals(run.conclusion)) throw new Exception("Actions終了: "+run.conclusion+"  (#"+id+")");
            postStatus("ビルド成功 / APK取得中…"); List<GitHubApi.Artifact> arts=a.artifacts(selectedRepo.fullName,id); if(arts.isEmpty()) throw new Exception("Artifactがありません");
            GitHubApi.Artifact chosen=arts.get(0); for(GitHubApi.Artifact x:arts) if(x.name.toLowerCase().contains("apk")){chosen=x;break;}
            DiagnosticLog.log("BUILD artifact selected id="+chosen.id+" name="+chosen.name);
            byte[] zip=a.downloadArtifact(selectedRepo.fullName,chosen.id); DiagnosticLog.log("BUILD artifact downloaded bytes="+zip.length); List<String> saved=saveApks(zip); if(saved.isEmpty()) throw new Exception("Artifact内に.apkがありません");
            String names=String.join(", ",saved); DiagnosticLog.log("BUILD complete apk="+names); ui.post(()->{status("✓ 完了\nDownload: "+names); buildButton.setEnabled(true);});
        } catch(Exception e){ DiagnosticLog.error("BUILD",e); ui.post(()->{buildButton.setEnabled(true); error(e);}); } });
    }

    private List<String> saveApks(byte[] zipBytes) throws Exception {
        List<String> saved=new ArrayList<>(); try(ZipInputStream zin=new ZipInputStream(new ByteArrayInputStream(zipBytes))) {
            ZipEntry z; byte[] buf=new byte[32768]; while((z=zin.getNextEntry())!=null){ if(z.isDirectory()||!z.getName().toLowerCase().endsWith(".apk"))continue; String name=z.getName(); int slash=name.lastIndexOf('/'); if(slash>=0)name=name.substring(slash+1);
                ContentValues v=new ContentValues(); v.put(MediaStore.Downloads.DISPLAY_NAME,name); v.put(MediaStore.Downloads.MIME_TYPE,"application/vnd.android.package-archive"); v.put(MediaStore.Downloads.RELATIVE_PATH,"Download");
                Uri u=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v); if(u==null)throw new Exception("Downloadへ保存できません");
                try(OutputStream out=getContentResolver().openOutputStream(u)){int n;while((n=zin.read(buf))>=0)out.write(buf,0,n);} saved.add(name); DiagnosticLog.log("APK saved Download/"+name);
            }
        } return saved;
    }

    private void openUrl(String url){
        try{
            Uri u=Uri.parse(url); DiagnosticLog.log("OPEN_URL host="+u.getHost()+" path="+u.getPath());
            startActivity(new Intent(Intent.ACTION_VIEW,u));
        }catch(Exception e){DiagnosticLog.error("OPEN_URL",e);error(e);}
    }

    private void showDiagnosticLog() {
        final Dialog d=new Dialog(this);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(18),dp(18),dp(18),dp(18)); box.setBackgroundColor(BG);
        TextView title=text("診断ログ",20,true); box.addView(title,new LinearLayout.LayoutParams(-1,dp(42)));
        TextView body=text(DiagnosticLog.report(this),12,false); body.setTextIsSelectable(true); body.setTypeface(android.graphics.Typeface.MONOSPACE); body.setGravity(Gravity.TOP|Gravity.START); body.setPadding(dp(12),dp(12),dp(12),dp(12)); body.setBackground(round(DGRAY,8));
        ScrollView scroll=new ScrollView(this); scroll.addView(body,new ScrollView.LayoutParams(-1,-2)); box.addView(scroll,new LinearLayout.LayoutParams(-1,0,1f));
        box.addView(space(12));
        LinearLayout buttons=row(); Button clear=button("ログ消去", Color.rgb(68,17,0)); buttons.addView(clear,new LinearLayout.LayoutParams(dp(80),dp(44)));
        Space stretch=new Space(this); buttons.addView(stretch,new LinearLayout.LayoutParams(0,1,1f));
        Button share=button(".txtを共有", LBLUE), copy=button("コピー", GRAY), close=button("閉じる", DGRAY);
        buttons.addView(share,new LinearLayout.LayoutParams(dp(92),dp(44))); buttons.addView(gap()); buttons.addView(copy,new LinearLayout.LayoutParams(dp(64),dp(44))); buttons.addView(gap()); buttons.addView(close,new LinearLayout.LayoutParams(dp(64),dp(44))); box.addView(buttons,new LinearLayout.LayoutParams(-1,dp(44)));
        clear.setOnClickListener(v->{ DiagnosticLog.clear(); DiagnosticLog.log("LOG cleared by user"); body.setText(DiagnosticLog.report(this)); });
        copy.setOnClickListener(v->{ ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE); cm.setPrimaryClip(ClipData.newPlainText("GitBuild diagnostic",DiagnosticLog.report(this))); toast("診断ログをコピーしました"); DiagnosticLog.log("LOG copied"); });
        share.setOnClickListener(v->shareDiagnosticLog()); close.setOnClickListener(v->d.dismiss());
        d.setContentView(box); Window w=d.getWindow(); if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent); w.setLayout((int)(getResources().getDisplayMetrics().widthPixels*0.96f),(int)(getResources().getDisplayMetrics().heightPixels*0.88f));} d.show(); if(d.getWindow()!=null)d.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels*0.96f),(int)(getResources().getDisplayMetrics().heightPixels*0.88f));
    }

    private void shareDiagnosticLog() {
        try {
            DiagnosticLog.log("LOG share requested");
            Uri u=Uri.parse("content://com.cmyk.gitbuild.diag/GitBuild_diagnostic.txt");
            Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_STREAM,u); i.putExtra(Intent.EXTRA_SUBJECT,"GitBuild diagnostic report"); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i,"診断ログを共有"));
        } catch(Exception e){ DiagnosticLog.error("LOG share",e); error(e); }
    }

    private static String safeIntentData(Intent i){
        if(i==null||i.getData()==null)return "null"; Uri u=i.getData(); return u.getScheme()+"://"+u.getHost()+u.getPath();
    }
    private static String tail(String s,int n){ if(s==null)return "null"; return s.length()<=n?s:s.substring(s.length()-n); }
    private static String randomUrlSafe(int bytes){byte[] b=new byte[bytes];new SecureRandom().nextBytes(b);return Base64.encodeToString(b,Base64.URL_SAFE|Base64.NO_PADDING|Base64.NO_WRAP);}
    private static String enc(String s) throws Exception{return URLEncoder.encode(s,"UTF-8").replace("+","%20");}
    private static boolean notEmpty(String s){return s!=null&&!s.isEmpty();}
    private void postStatus(String s){ui.post(()->status(s));} private void status(String s){statusText.setText(s);} private void error(Exception e){DiagnosticLog.error("UI",e); status("エラー\n"+(e.getMessage()==null?e.getClass().getSimpleName():e.getMessage()));}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    private TextView text(String s,int sp,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextColor(TEXT);v.setTextSize(sp);if(bold)v.setTypeface(null,1);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    private TextView label(String s){TextView v=text(s,12,false);v.setTextColor(WHITE);v.setPadding(0,0,0,dp(6));return v;}
    private EditText input(String hint,boolean password){EditText e=new EditText(this);e.setHint(hint);e.setTextColor(TEXT);e.setHintTextColor(WHITE);e.setSingleLine(true);e.setPadding(dp(12),0,dp(12),0);e.setBackground(round(GRAY,8));if(password)e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);return e;}
    private View card(TextView content){LinearLayout l=new LinearLayout(this);l.setPadding(dp(14),dp(12),dp(14),dp(12));l.setBackground(round(GRAY,10));l.addView(content,new LinearLayout.LayoutParams(-1,-2));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(8));l.setLayoutParams(p);return l;}
    private Button button(String s,int color){Button b=new Button(this);b.setText(s);b.setTextColor(TEXT);b.setTextSize(14);b.setAllCaps(false);b.setPadding(dp(8),0,dp(8),0);b.setBackground(round(color,10));return b;}
    private GradientDrawable round(int c,int r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));return g;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);return l;} private LinearLayout.LayoutParams weight(){return new LinearLayout.LayoutParams(0,dp(44),1f);} private View gap(){Space s=new Space(this);s.setLayoutParams(new LinearLayout.LayoutParams(dp(8),1));return s;} private View space(int h){Space s=new Space(this);s.setLayoutParams(new LinearLayout.LayoutParams(1,dp(h)));return s;}
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);} private static String human(long b){if(b<1024)return b+" B";if(b<1024*1024)return String.format(Locale.US,"%.1f KB",b/1024f);return String.format(Locale.US,"%.1f MB",b/1048576f);}
}
