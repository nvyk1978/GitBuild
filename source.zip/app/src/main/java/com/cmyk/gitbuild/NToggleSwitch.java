package com.cmyk.gitbuild;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/** Compact N-standard toggle used across cmyk Android tools. */
public final class NToggleSwitch extends View {
    public interface OnCheckedChangeListener { void onCheckedChanged(NToggleSwitch view, boolean checked); }

    private static final int OFF = Color.rgb(69,64,64);      // N Gray #454040
    private static final int ON = Color.rgb(34,51,85);       // N Blue #223355
    private static final int THUMB = Color.rgb(169,169,153); // N White #A9A999

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF track = new RectF();
    private boolean checked;
    private OnCheckedChangeListener listener;

    public NToggleSwitch(Context c) { super(c); init(); }
    public NToggleSwitch(Context c, AttributeSet a) { super(c,a); init(); }
    public NToggleSwitch(Context c, AttributeSet a, int s) { super(c,a,s); init(); }

    private void init(){
        setClickable(true);
        setFocusable(true);
        setMinimumWidth(dp(42));
        setMinimumHeight(dp(24));
        setContentDescription("toggle");
    }

    public boolean isChecked(){ return checked; }
    public void setChecked(boolean value){
        if(checked==value) return;
        checked=value;
        refreshDrawableState();
        invalidate();
        if(listener!=null) listener.onCheckedChanged(this,checked);
    }
    public void toggle(){ setChecked(!checked); }
    public void setOnCheckedChangeListener(OnCheckedChangeListener l){ listener=l; }

    @Override protected void onMeasure(int ws,int hs){
        int w=resolveSize(dp(42),ws), h=resolveSize(dp(24),hs);
        setMeasuredDimension(w,h);
    }

    @Override protected void onDraw(Canvas c){
        super.onDraw(c);
        float h=getHeight(), w=getWidth();
        float pad=Math.max(1f, dpF(1));
        track.set(pad,pad,w-pad,h-pad);
        paint.setColor(isEnabled()?(checked?ON:OFF):Color.rgb(101,96,96));
        c.drawRoundRect(track,h/2f,h/2f,paint);

        float r=Math.max(dpF(8), (h-dpF(6))/2f);
        float cx=checked ? w-r-dpF(3) : r+dpF(3);
        paint.setColor(THUMB);
        c.drawCircle(cx,h/2f,r,paint);
    }

    @Override public boolean onTouchEvent(MotionEvent e){
        if(!isEnabled()) return false;
        if(e.getAction()==MotionEvent.ACTION_UP){
            toggle();
            performClick();
            return true;
        }
        return true;
    }
    @Override public boolean performClick(){ super.performClick(); return true; }

    private int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    private float dpF(float v){ return v*getResources().getDisplayMetrics().density; }
}
