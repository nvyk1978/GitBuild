package com.cmyk.gitbuild;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.LinearInterpolator;

/**
 * Nトグル標準コンポーネント。
 * Track: 44x24dp / OFF thumb: 24dp white / ON thumb: 26dp light blue /
 * LOCK thumb: 26dp N red / slide: 120ms / Canvas direct drawing.
 */
public final class NToggleSwitch extends View {
    public interface OnCheckedChangeListener {
        void onCheckedChanged(NToggleSwitch view, boolean checked);
    }

    private static final int TRACK_COLOR = Color.rgb(69, 64, 64);       // N Gray #454040
    private static final int OFF_THUMB = Color.WHITE;                   // #FFFFFF
    private static final int DEFAULT_ON_THUMB = Color.rgb(68, 85, 119); // N Light Blue #445577
    private static final int LOCK_THUMB = Color.rgb(68, 17, 0);         // N Red #441100
    private static final long SLIDE_MS = 120L;

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF track = new RectF();

    private boolean checked;
    private boolean locked;
    private float position; // 0=OFF, 1=ON
    private int onThumbColor = DEFAULT_ON_THUMB;
    private ValueAnimator animator;
    private OnCheckedChangeListener listener;

    public NToggleSwitch(Context c) { super(c); init(); }
    public NToggleSwitch(Context c, AttributeSet a) { super(c, a); init(); }
    public NToggleSwitch(Context c, AttributeSet a, int s) { super(c, a, s); init(); }

    private void init() {
        setClickable(true);
        setFocusable(true);
        setContentDescription("toggle");
    }

    public boolean isChecked() { return checked; }
    public boolean isLocked() { return locked; }

    /** Nトグル標準はライトブルー。用途別トグルだけこの色を上書きする。 */
    public void setOnThumbColor(int color) {
        onThumbColor = color;
        invalidate();
    }

    public void setLocked(boolean value) {
        if (locked == value) return;
        locked = value;
        invalidate();
    }

    public void setChecked(boolean value) {
        setChecked(value, isLaidOut());
    }

    public void setChecked(boolean value, boolean animate) {
        if (checked == value && (!animate || position == (value ? 1f : 0f))) return;
        checked = value;
        float target = value ? 1f : 0f;
        if (animator != null) animator.cancel();

        if (!animate) {
            position = target;
            invalidate();
        } else {
            animator = ValueAnimator.ofFloat(position, target);
            animator.setDuration(SLIDE_MS);
            animator.setInterpolator(new LinearInterpolator());
            animator.addUpdateListener(a -> {
                position = (float) a.getAnimatedValue();
                invalidate();
            });
            animator.start();
        }
        if (listener != null) listener.onCheckedChanged(this, checked);
    }

    public void toggle() {
        if (!locked) setChecked(!checked, true);
    }

    public void setOnCheckedChangeListener(OnCheckedChangeListener l) {
        listener = l;
    }

    @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        // 26dp high canvas keeps the 26dp ON/LOCK thumb from clipping.
        setMeasuredDimension(resolveSize(dp(44), widthMeasureSpec), resolveSize(dp(26), heightMeasureSpec));
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        final float trackW = dpF(44f);
        final float trackH = dpF(24f);
        final float left = (getWidth() - trackW) / 2f;
        final float top = (getHeight() - trackH) / 2f;
        track.set(left, top, left + trackW, top + trackH);

        paint.setColor(TRACK_COLOR);
        canvas.drawRoundRect(track, trackH / 2f, trackH / 2f, paint);

        // OFF is exactly 24dp. ON/LOCK are exactly 26dp.
        final float diameter = (locked || checked) ? dpF(26f) : dpF(24f);
        final float radius = diameter / 2f;
        final float offCx = left + dpF(12f);
        final float onCx = left + trackW - dpF(13f);
        final float cx = offCx + (onCx - offCx) * position;
        final float cy = top + trackH / 2f;

        paint.setColor(locked ? LOCK_THUMB : (checked ? onThumbColor : OFF_THUMB));
        canvas.drawCircle(cx, cy, radius, paint);
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        if (!isEnabled() || locked) return false;
        if (event.getAction() == MotionEvent.ACTION_UP) {
            toggle();
            performClick();
            return true;
        }
        return true;
    }

    @Override public boolean performClick() {
        super.performClick();
        return true;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private float dpF(float value) {
        return value * getResources().getDisplayMetrics().density;
    }
}
