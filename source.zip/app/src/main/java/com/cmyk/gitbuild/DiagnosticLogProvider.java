package com.cmyk.gitbuild;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;

public final class DiagnosticLogProvider extends ContentProvider {
    @Override public boolean onCreate() { return true; }

    private boolean isSource(Uri uri) {
        String p=uri==null?null:uri.getLastPathSegment();
        return p!=null && ("source".equalsIgnoreCase(p) || p.toLowerCase().endsWith(".zip"));
    }

    private File sourceFile() {
        return getContext()==null?null:new File(getContext().getCacheDir(),"gitbuild_shared_source.zip");
    }

    @Override public String getType(Uri uri) { return isSource(uri)?"application/zip":"text/plain"; }

    @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        if (getContext() == null) throw new FileNotFoundException("No context");
        try {
            File f;
            if(isSource(uri)){
                f=sourceFile();
                if(f==null||!f.isFile()||f.length()<=0)throw new FileNotFoundException("source.zip cache unavailable");
            }else{
                f=DiagnosticLog.writeReportFile(getContext());
            }
            return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
        } catch (Exception e) {
            throw new FileNotFoundException(e.getMessage());
        }
    }

    @Override public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        MatrixCursor c = new MatrixCursor(new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE});
        try {
            if(isSource(uri)){
                File f=sourceFile();
                c.addRow(new Object[]{"source.zip", f!=null&&f.isFile()?f.length():0});
            }else{
                File f = DiagnosticLog.writeReportFile(getContext());
                c.addRow(new Object[]{"GitBuild_diagnostic.txt", f.length()});
            }
        } catch (Exception e) {
            c.addRow(new Object[]{isSource(uri)?"source.zip":"GitBuild_diagnostic.txt", 0});
        }
        return c;
    }

    @Override public Uri insert(Uri uri, ContentValues values) { throw new UnsupportedOperationException(); }
    @Override public int delete(Uri uri, String selection, String[] selectionArgs) { return 0; }
    @Override public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) { return 0; }
}
