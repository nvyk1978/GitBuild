package com.cmyk.gitbuild;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;

/** N-style circular check. Defaults to #227733 / #FFFFFF; callers may override. */
public final class GreenCheckView extends View {
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shimmerPaint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private int fillColor=Color.rgb(34,119,51);
    private int checkColor=Color.WHITE;
    private final ValueAnimator shimmerAnimator;
    private boolean shimmering;
    private float shimmerX;

    public GreenCheckView(Context c){super(c); shimmerAnimator=createAnimator();}
    public GreenCheckView(Context c, AttributeSet a){super(c,a); shimmerAnimator=createAnimator();}

    private ValueAnimator createAnimator(){
        ValueAnimator a=ValueAnimator.ofFloat(0f,1f);
        a.setDuration(1450L);
        a.setRepeatCount(ValueAnimator.INFINITE);
        a.setInterpolator(new LinearInterpolator());
        a.addUpdateListener(v->{
            float w=Math.max(1f,getWidth());
            float f=(Float)v.getAnimatedValue();
            shimmerX=(-0.8f*w)+(2.6f*w*f);
            invalidate();
        });
        return a;
    }

    public void setColors(int fillColor,int checkColor){this.fillColor=fillColor;this.checkColor=checkColor;invalidate();}

    public void setShimmering(boolean enabled){
        if(shimmering==enabled) return;
        shimmering=enabled;
        if(enabled){ if(isAttachedToWindow()&&!shimmerAnimator.isStarted()) shimmerAnimator.start(); }
        else { shimmerAnimator.cancel(); invalidate(); }
    }

    @Override protected void onAttachedToWindow(){ super.onAttachedToWindow(); if(shimmering&&!shimmerAnimator.isStarted()) shimmerAnimator.start(); }
    @Override protected void onDetachedFromWindow(){ shimmerAnimator.cancel(); super.onDetachedFromWindow(); }
    @Override protected void onMeasure(int w,int h){int s=resolveSize(dp(20),w);setMeasuredDimension(s,s);}

    @Override protected void onDraw(Canvas c){
        super.onDraw(c);
        float s=Math.min(getWidth(),getHeight());
        float cx=getWidth()/2f, cy=getHeight()/2f;
        paint.setStyle(Paint.Style.FILL); paint.setColor(fillColor);
        c.drawCircle(cx,cy,s/2f,paint);
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(dpF(2f)); paint.setStrokeCap(Paint.Cap.SQUARE); paint.setStrokeJoin(Paint.Join.MITER); paint.setColor(checkColor);
        Path p=new Path();
        p.moveTo(s*0.27f,s*0.52f); p.lineTo(s*0.44f,s*0.69f); p.lineTo(s*0.75f,s*0.34f);
        c.drawPath(p,paint);
        if(shimmering && getWidth()>0){
            float band=Math.max(dpF(5f),s*0.52f);
            LinearGradient g=new LinearGradient(shimmerX-band,0f,shimmerX+band,0f,
                    new int[]{Color.TRANSPARENT,Color.argb(185,0,0,0),Color.TRANSPARENT},
                    new float[]{0f,0.5f,1f},Shader.TileMode.CLAMP);
            shimmerPaint.setShader(g);
            int save=c.save();
            Path clip=new Path(); clip.addCircle(cx,cy,s/2f,Path.Direction.CW); c.clipPath(clip);
            c.drawRect(0f,0f,getWidth(),getHeight(),shimmerPaint);
            c.restoreToCount(save);
            shimmerPaint.setShader(null);
        }
    }
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);} private float dpF(float v){return v*getResources().getDisplayMetrics().density;}
}
