package com.cmyk.gitbuild;

import android.content.ContentResolver;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public final class GitHubApi {
    public static final class Repo {
        public final String fullName;
        public final String defaultBranch;
        Repo(String fullName, String defaultBranch) { this.fullName = fullName; this.defaultBranch = defaultBranch; }
        @Override public String toString() { return fullName; }
    }
    public static final class Run {
        public final long id;
        public final String status;
        public final String conclusion;
        Run(long id, String status, String conclusion) { this.id = id; this.status = status; this.conclusion = conclusion; }
    }
    public static final class Artifact {
        public final long id;
        public final String name;
        Artifact(long id, String name) { this.id = id; this.name = name; }
    }
    public static final class CommitResult {
        public final String commitSha;
        public final String previousSha;
        public final String previousTreeSha;
        CommitResult(String commitSha, String previousSha, String previousTreeSha) {
            this.commitSha = commitSha;
            this.previousSha = previousSha;
            this.previousTreeSha = previousTreeSha;
        }
    }

    private final String token;
    public GitHubApi(String token) { this.token = token; }

    private JSONObject json(String method, String path, JSONObject body) throws Exception {
        DiagnosticLog.log("GITHUB_API "+method+" "+path);
        HttpURLConnection c = open(method, "https://api.github.com" + path, true);
        if (body != null) {
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            byte[] b = body.toString().getBytes(StandardCharsets.UTF_8);
            c.setFixedLengthStreamingMode(b.length);
            try (OutputStream out = c.getOutputStream()) { out.write(b); }
        }
        int code = c.getResponseCode();
        DiagnosticLog.log("GITHUB_API response "+method+" "+path+" status="+code);
        String text = readText(code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream());
        if (code < 200 || code >= 300) throw new Exception("GitHub " + code + ": " + text);
        return text.isEmpty() ? new JSONObject() : new JSONObject(text);
    }

    private JSONArray array(String path) throws Exception {
        DiagnosticLog.log("GITHUB_API GET "+path);
        HttpURLConnection c = open("GET", "https://api.github.com" + path, true);
        int code = c.getResponseCode();
        DiagnosticLog.log("GITHUB_API response GET "+path+" status="+code);
        String text = readText(code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream());
        if (code < 200 || code >= 300) throw new Exception("GitHub " + code + ": " + text);
        return new JSONArray(text);
    }

    private HttpURLConnection open(String method, String url, boolean auth) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(20000); c.setReadTimeout(45000);
        c.setRequestProperty("Accept", "application/vnd.github+json");
        c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28");
        c.setRequestProperty("User-Agent", "GitBuild-Android");
        if (auth) c.setRequestProperty("Authorization", "Bearer " + token);
        return c;
    }

    private static String readText(InputStream in) throws Exception {
        if (in == null) return "";
        try (InputStream input = in; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192]; int n;
            while ((n = input.read(buf)) >= 0) out.write(buf, 0, n);
            return out.toString(StandardCharsets.UTF_8.name());
        }
    }

    public String getLogin() throws Exception {
        JSONObject u = json("GET", "/user", null);
        return u.getString("login");
    }

    public List<Repo> listRepos() throws Exception {
        JSONArray a = array("/user/repos?per_page=100&sort=updated&affiliation=owner,collaborator,organization_member");
        List<Repo> out = new ArrayList<>();
        for (int i=0;i<a.length();i++) {
            JSONObject r = a.getJSONObject(i);
            out.add(new Repo(r.getString("full_name"), r.optString("default_branch", "main")));
        }
        return out;
    }

    public Repo createRepo(String name, boolean isPrivate) throws Exception {
        JSONObject b = new JSONObject().put("name", name).put("private", isPrivate).put("auto_init", true);
        JSONObject r = json("POST", "/user/repos", b);
        return new Repo(r.getString("full_name"), r.optString("default_branch", "main"));
    }

    public CommitResult commitFiles(Repo repo, List<SharedItem> files, ContentResolver resolver) throws Exception {
        String[] p = repo.fullName.split("/", 2);
        String base = "/repos/" + p[0] + "/" + p[1];
        JSONObject ref = json("GET", base + "/git/ref/heads/" + url(repo.defaultBranch), null);
        String parent = ref.getJSONObject("object").getString("sha");
        JSONObject commit = json("GET", base + "/git/commits/" + parent, null);
        String baseTree = commit.getJSONObject("tree").getString("sha");
        JSONArray entries = new JSONArray();

        for (SharedItem f : files) {
            byte[] bytes = readAll(resolver, f.uri);
            String lower = f.name.toLowerCase();
            boolean wf = lower.endsWith(".yml") || lower.endsWith(".yaml");
            if (wf) {
                String s = new String(bytes, StandardCharsets.UTF_8);
                wf = s.contains("jobs:") && (s.contains("on:") || s.contains("workflow_dispatch"));
            }
            String path;
            if (wf) {
                path = ".github/workflows/" + safeName(f.name);
            } else if (lower.endsWith(".zip")) {
                // GitBuild accepts a versioned/arbitrary source ZIP name from Android share,
                // but normalizes it in the repository so existing workflows can always use source.zip.
                path = "source.zip";
                DiagnosticLog.log("GITHUB_API normalize source zip "+f.name+" -> source.zip");
            } else {
                path = safeName(f.name);
            }
            JSONObject blob = json("POST", base + "/git/blobs",
                    new JSONObject().put("content", Base64.encodeToString(bytes, Base64.NO_WRAP)).put("encoding", "base64"));
            entries.put(new JSONObject().put("path", path).put("mode", "100644").put("type", "blob").put("sha", blob.getString("sha")));
        }
        JSONObject tree = json("POST", base + "/git/trees", new JSONObject().put("base_tree", baseTree).put("tree", entries));
        JSONObject newCommit = json("POST", base + "/git/commits", new JSONObject()
                .put("message", "GitBuild upload")
                .put("tree", tree.getString("sha"))
                .put("parents", new JSONArray().put(parent)));
        String sha = newCommit.getString("sha");
        json("PATCH", base + "/git/refs/heads/" + url(repo.defaultBranch), new JSONObject().put("sha", sha).put("force", false));
        return new CommitResult(sha, parent, baseTree);
    }

    /**
     * Restore repository contents to the exact tree that existed before the GitBuild upload.
     * A forward recovery commit is used instead of force-resetting history. [skip ci] prevents
     * ordinary push/pull_request workflows from running again for the recovery commit.
     * Returns false if the branch head changed after GitBuild's upload, so unrelated changes
     * are never overwritten.
     */
    public boolean recoverPreviousState(Repo repo, CommitResult build) throws Exception {
        String[] p = repo.fullName.split("/", 2);
        String base = "/repos/" + p[0] + "/" + p[1];
        JSONObject ref = json("GET", base + "/git/ref/heads/" + url(repo.defaultBranch), null);
        String current = ref.getJSONObject("object").getString("sha");
        if (!current.equals(build.commitSha)) {
            DiagnosticLog.log("GITHUB_API recovery skipped head changed current=" + current + " expected=" + build.commitSha);
            return false;
        }

        JSONObject recovery = json("POST", base + "/git/commits", new JSONObject()
                .put("message", "GitBuild recovery [skip ci]")
                .put("tree", build.previousTreeSha)
                .put("parents", new JSONArray().put(build.commitSha)));
        String recoverySha = recovery.getString("sha");
        json("PATCH", base + "/git/refs/heads/" + url(repo.defaultBranch),
                new JSONObject().put("sha", recoverySha).put("force", false));
        DiagnosticLog.log("GITHUB_API recovery success sha=" + recoverySha);
        return true;
    }

    public Run findRun(String fullName, String sha) throws Exception {
        String[] p = fullName.split("/",2);
        JSONObject r = json("GET", "/repos/"+p[0]+"/"+p[1]+"/actions/runs?head_sha="+url(sha)+"&per_page=10", null);
        JSONArray a = r.getJSONArray("workflow_runs");
        if (a.length()==0) return null;
        JSONObject x = a.getJSONObject(0);
        return new Run(x.getLong("id"), x.getString("status"), x.isNull("conclusion") ? null : x.optString("conclusion", null));
    }

    public Run getRun(String fullName, long runId) throws Exception {
        String[] p = fullName.split("/",2);
        JSONObject x = json("GET", "/repos/"+p[0]+"/"+p[1]+"/actions/runs/"+runId, null);
        return new Run(x.getLong("id"), x.getString("status"), x.isNull("conclusion") ? null : x.optString("conclusion", null));
    }

    public void cancelRun(String fullName, long runId) throws Exception {
        String[] p = fullName.split("/",2);
        json("POST", "/repos/"+p[0]+"/"+p[1]+"/actions/runs/"+runId+"/cancel", null);
    }

    public List<Artifact> artifacts(String fullName, long runId) throws Exception {
        String[] p = fullName.split("/",2);
        JSONObject r = json("GET", "/repos/"+p[0]+"/"+p[1]+"/actions/runs/"+runId+"/artifacts", null);
        JSONArray a = r.getJSONArray("artifacts"); List<Artifact> out = new ArrayList<>();
        for (int i=0;i<a.length();i++) { JSONObject x=a.getJSONObject(i); if(!x.optBoolean("expired",false)) out.add(new Artifact(x.getLong("id"), x.getString("name"))); }
        return out;
    }

    public byte[] downloadArtifact(String fullName, long artifactId) throws Exception {
        String[] p = fullName.split("/",2);
        HttpURLConnection c = open("GET", "https://api.github.com/repos/"+p[0]+"/"+p[1]+"/actions/artifacts/"+artifactId+"/zip", true);
        c.setInstanceFollowRedirects(false);
        int code = c.getResponseCode();
        if (code != 302 && code != 301) throw new Exception("Artifact download HTTP " + code + ": " + readText(c.getErrorStream()));
        String loc = c.getHeaderField("Location");
        HttpURLConnection d = open("GET", loc, false);
        int dc = d.getResponseCode();
        if (dc < 200 || dc >= 300) throw new Exception("Artifact blob HTTP " + dc);
        try (InputStream in=d.getInputStream(); ByteArrayOutputStream out=new ByteArrayOutputStream()) {
            byte[] buf=new byte[32768]; int n; while((n=in.read(buf))>=0) out.write(buf,0,n); return out.toByteArray();
        }
    }

    private static byte[] readAll(ContentResolver r, Uri u) throws Exception {
        try(InputStream in=r.openInputStream(u); ByteArrayOutputStream out=new ByteArrayOutputStream()) {
            if(in==null) throw new Exception("Cannot open shared file: "+u);
            byte[] buf=new byte[32768]; int n; while((n=in.read(buf))>=0) out.write(buf,0,n); return out.toByteArray();
        }
    }
    private static String safeName(String s) { return s.replace("/","_").replace("\\","_"); }
    private static String url(String s) throws Exception { return URLEncoder.encode(s, "UTF-8").replace("+", "%20"); }
}
