package com.cmyk.gitbuild;

import android.content.ContentResolver;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public final class GitHubApi {
    public static final class Repo {
        public final String fullName;
        public final String defaultBranch;
        public final boolean isPrivate;
        Repo(String fullName, String defaultBranch, boolean isPrivate) {
            this.fullName = fullName;
            this.defaultBranch = defaultBranch;
            this.isPrivate = isPrivate;
        }
        @Override public String toString() { return fullName; }
    }

    public static final class Run {
        public final long id;
        public final String status;
        public final String conclusion;
        Run(long id, String status, String conclusion) {
            this.id = id;
            this.status = status;
            this.conclusion = conclusion;
        }
    }

    public static final class Artifact {
        public final long id;
        public final String name;
        Artifact(long id, String name) { this.id = id; this.name = name; }
    }

    public static final class CommitResult {
        public final String commitSha;
        public final String previousSha;
        public final String previousTreeSha;
        public final String treeSha;
        public final boolean contentChanged;
        CommitResult(String commitSha, String previousSha, String previousTreeSha, String treeSha, boolean contentChanged) {
            this.commitSha = commitSha;
            this.previousSha = previousSha;
            this.previousTreeSha = previousTreeSha;
            this.treeSha = treeSha;
            this.contentChanged = contentChanged;
        }
    }

    public static final class DispatchResult {
        public final long workflowId;
        public final String workflowPath;
        public final long requestedAtEpochMillis;
        DispatchResult(long workflowId, String workflowPath, long requestedAtEpochMillis) {
            this.workflowId = workflowId;
            this.workflowPath = workflowPath;
            this.requestedAtEpochMillis = requestedAtEpochMillis;
        }
    }

    public static final class Job {
        public final long id;
        public final String name;
        public final String status;
        public final String conclusion;
        public final List<String> failedSteps;
        Job(long id, String name, String status, String conclusion, List<String> failedSteps) {
            this.id=id;
            this.name=name;
            this.status=status;
            this.conclusion=conclusion;
            this.failedSteps=failedSteps;
        }
    }

    private final String token;
    public GitHubApi(String token) { this.token = token; }

    private JSONObject json(String method, String path, JSONObject body) throws Exception {
        DiagnosticLog.log("GITHUB_API "+method+" "+path);
        HttpURLConnection c = open(method, "https://api.github.com" + path, true);
        if (body != null) {
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            byte[] b = body.toString().getBytes(StandardCharsets.UTF_8);
            c.setFixedLengthStreamingMode(b.length);
            try (OutputStream out = c.getOutputStream()) { out.write(b); }
        }
        int code = c.getResponseCode();
        DiagnosticLog.log("GITHUB_API response "+method+" "+path+" status="+code);
        String text = readText(code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream());
        if (code < 200 || code >= 300) throw new Exception("GitHub " + code + ": " + text);
        return text.isEmpty() ? new JSONObject() : new JSONObject(text);
    }

    private JSONArray array(String path) throws Exception {
        DiagnosticLog.log("GITHUB_API GET "+path);
        HttpURLConnection c = open("GET", "https://api.github.com" + path, true);
        int code = c.getResponseCode();
        DiagnosticLog.log("GITHUB_API response GET "+path+" status="+code);
        String text = readText(code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream());
        if (code < 200 || code >= 300) throw new Exception("GitHub " + code + ": " + text);
        return new JSONArray(text);
    }

    private HttpURLConnection open(String method, String url, boolean auth) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(20000);
        c.setReadTimeout(45000);
        c.setRequestProperty("Accept", "application/vnd.github+json");
        c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28");
        c.setRequestProperty("User-Agent", "GitBuild-Android");
        if (auth) c.setRequestProperty("Authorization", "Bearer " + token);
        return c;
    }

    private static String readText(InputStream in) throws Exception {
        if (in == null) return "";
        try (InputStream input = in; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192]; int n;
            while ((n = input.read(buf)) >= 0) out.write(buf, 0, n);
            return out.toString(StandardCharsets.UTF_8.name());
        }
    }

    /**
     * Keeps old Android workflow files buildable on current GitHub-hosted runners.
     * setup-android v1-v3 still request the retired SDK package named "tools";
     * v4 uses the current command-line tools and Node 24.
     */
    private static byte[] normalizeWorkflow(byte[] bytes, String fileName) {
        String source = new String(bytes, StandardCharsets.UTF_8);
        String normalized = source.replaceAll(
                "android-actions/setup-android@v(?:1|2|3)(?:\\.[0-9]+)*(?=\\s|['\\\"]|$)",
                "android-actions/setup-android@v4");
        if (source.equals(normalized)) return bytes;
        DiagnosticLog.log("GITHUB_API workflow normalized setup-android -> v4 file=" + fileName);
        return normalized.getBytes(StandardCharsets.UTF_8);
    }

    public String getLogin() throws Exception {
        JSONObject u = json("GET", "/user", null);
        return u.getString("login");
    }

    public List<Repo> listRepos() throws Exception {
        JSONArray a = array("/user/repos?per_page=100&sort=updated&affiliation=owner,collaborator,organization_member");
        List<Repo> out = new ArrayList<>();
        for (int i=0;i<a.length();i++) {
            JSONObject r = a.getJSONObject(i);
            out.add(new Repo(r.getString("full_name"), r.optString("default_branch", "main"), r.optBoolean("private", false)));
        }
        return out;
    }

    public Repo createRepo(String name, boolean isPrivate) throws Exception {
        JSONObject b = new JSONObject().put("name", name).put("private", isPrivate).put("auto_init", true);
        JSONObject r = json("POST", "/user/repos", b);
        return new Repo(r.getString("full_name"), r.optString("default_branch", "main"), r.optBoolean("private", isPrivate));
    }

    public Repo updateRepo(Repo repo, String newName, boolean isPrivate) throws Exception {
        String[] p = repo.fullName.split("/", 2);
        if (p.length != 2) throw new Exception("Invalid repository: " + repo.fullName);
        JSONObject body = new JSONObject().put("name", newName).put("private", isPrivate);
        JSONObject r = json("PATCH", "/repos/" + url(p[0]) + "/" + url(p[1]), body);
        return new Repo(r.getString("full_name"), r.optString("default_branch", repo.defaultBranch), r.optBoolean("private", isPrivate));
    }

    /**
     * Creates the upload tree and commits it only when repository contents really changed.
     * Identical input deliberately returns the existing branch head so Git history stays clean;
     * callers should dispatch the build workflow directly in that case.
     */
    public CommitResult commitFiles(Repo repo, List<SharedItem> files, ContentResolver resolver) throws Exception {
        String[] p = repo.fullName.split("/", 2);
        String base = "/repos/" + p[0] + "/" + p[1];
        JSONObject ref = json("GET", base + "/git/ref/heads/" + url(repo.defaultBranch), null);
        String parent = ref.getJSONObject("object").getString("sha");
        JSONObject commit = json("GET", base + "/git/commits/" + parent, null);
        String baseTree = commit.getJSONObject("tree").getString("sha");
        JSONArray entries = new JSONArray();

        for (SharedItem f : files) {
            byte[] bytes = readAll(resolver, f.uri);
            String lower = f.name.toLowerCase();
            boolean wf = lower.endsWith(".yml") || lower.endsWith(".yaml");
            if (wf) {
                String s = new String(bytes, StandardCharsets.UTF_8);
                wf = s.contains("jobs:") && (s.contains("on:") || s.contains("workflow_dispatch"));
            }
            if (wf) {
                byte[] normalized = normalizeWorkflow(bytes, f.name);
                if (normalized != bytes) bytes = normalized;
            }
            String path;
            if (wf) {
                path = ".github/workflows/" + safeName(f.name);
            } else if (lower.endsWith(".zip")) {
                path = "source.zip";
                DiagnosticLog.log("GITHUB_API normalize source zip "+f.name+" -> source.zip");
            } else {
                path = safeName(f.name);
            }
            JSONObject blob = json("POST", base + "/git/blobs",
                    new JSONObject().put("content", Base64.encodeToString(bytes, Base64.NO_WRAP)).put("encoding", "base64"));
            entries.put(new JSONObject().put("path", path).put("mode", "100644").put("type", "blob").put("sha", blob.getString("sha")));
        }

        JSONObject tree = json("POST", base + "/git/trees", new JSONObject().put("base_tree", baseTree).put("tree", entries));
        String treeSha = tree.getString("sha");
        boolean contentChanged = !treeSha.equals(baseTree);
        DiagnosticLog.log("GITHUB_API upload tree base=" + baseTree + " new=" + treeSha + " changed=" + contentChanged);
        if (!contentChanged) {
            DiagnosticLog.log("GITHUB_API identical contents; commit skipped head=" + parent);
            return new CommitResult(parent, parent, baseTree, treeSha, false);
        }

        JSONObject newCommit = json("POST", base + "/git/commits", new JSONObject()
                .put("message", "GitBuild upload")
                .put("tree", treeSha)
                .put("parents", new JSONArray().put(parent)));
        String sha = newCommit.getString("sha");
        json("PATCH", base + "/git/refs/heads/" + url(repo.defaultBranch), new JSONObject().put("sha", sha).put("force", false));
        return new CommitResult(sha, parent, baseTree, treeSha, true);
    }

    public DispatchResult dispatchBuildWorkflow(Repo repo) throws Exception {
        String[] p = repo.fullName.split("/", 2);
        if (p.length != 2) throw new Exception("Invalid repository: " + repo.fullName);
        String base = "/repos/" + p[0] + "/" + p[1];
        JSONObject listed = json("GET", base + "/actions/workflows?per_page=100", null);
        JSONArray workflows = listed.optJSONArray("workflows");
        if (workflows == null || workflows.length() == 0) throw new Exception("GitHub Actions workflowがありません");

        long chosenId = -1L;
        String chosenPath = null;
        int chosenScore = Integer.MIN_VALUE;
        for (int i = 0; i < workflows.length(); i++) {
            JSONObject wf = workflows.getJSONObject(i);
            if (!"active".equals(wf.optString("state", "active"))) continue;
            long id = wf.optLong("id", -1L);
            String path = wf.optString("path", "");
            if (id <= 0 || path.isEmpty()) continue;
            String text;
            try {
                JSONObject file = json("GET", base + "/contents/" + urlPath(path) + "?ref=" + url(repo.defaultBranch), null);
                String encoded = file.optString("content", "").replace("\n", "").replace("\r", "");
                if (encoded.isEmpty()) continue;
                text = new String(Base64.decode(encoded, Base64.DEFAULT), StandardCharsets.UTF_8);
            } catch (Exception e) {
                DiagnosticLog.log("GITHUB_API workflow inspect skipped path=" + path + " reason=" + e.getClass().getSimpleName());
                continue;
            }
            String lower = text.toLowerCase();
            if (!lower.contains("workflow_dispatch")) continue;
            if (!lower.contains("source.zip")) continue;
            int score = 100;
            String pathLower = path.toLowerCase();
            String nameLower = wf.optString("name", "").toLowerCase();
            if (pathLower.contains("build")) score += 10;
            if (nameLower.contains("build")) score += 6;
            if (lower.contains("assembledebug") || lower.contains("assemble debug")) score += 4;
            if (score > chosenScore) {
                chosenScore = score;
                chosenId = id;
                chosenPath = path;
            }
        }
        if (chosenId <= 0) throw new Exception("source.zip対応かつ workflow_dispatch 有効なActions workflowが見つかりません");

        long requestedAt = System.currentTimeMillis();
        json("POST", base + "/actions/workflows/" + chosenId + "/dispatches", new JSONObject().put("ref", repo.defaultBranch));
        DiagnosticLog.log("GITHUB_API workflow_dispatch id="+chosenId+" path=" + chosenPath + " ref=" + repo.defaultBranch);
        return new DispatchResult(chosenId, chosenPath, requestedAt);
    }

    public boolean recoverPreviousState(Repo repo, CommitResult build) throws Exception {
        if (!build.contentChanged) {
            DiagnosticLog.log("GITHUB_API recovery skipped because upload had no content change");
            return true;
        }
        String[] p = repo.fullName.split("/", 2);
        String base = "/repos/" + p[0] + "/" + p[1];
        JSONObject ref = json("GET", base + "/git/ref/heads/" + url(repo.defaultBranch), null);
        String current = ref.getJSONObject("object").getString("sha");
        if (!current.equals(build.commitSha)) {
            DiagnosticLog.log("GITHUB_API recovery skipped head changed current=" + current + " expected=" + build.commitSha);
            return false;
        }
        JSONObject recovery = json("POST", base + "/git/commits", new JSONObject()
                .put("message", "GitBuild recovery [skip ci]")
                .put("tree", build.previousTreeSha)
                .put("parents", new JSONArray().put(build.commitSha)));
        String recoverySha = recovery.getString("sha");
        json("PATCH", base + "/git/refs/heads/" + url(repo.defaultBranch), new JSONObject().put("sha", recoverySha).put("force", false));
        DiagnosticLog.log("GITHUB_API recovery success sha=" + recoverySha);
        return true;
    }

    public Run findRun(String fullName, String sha) throws Exception {
        String[] p = fullName.split("/",2);
        JSONObject r = json("GET", "/repos/"+p[0]+"/"+p[1]+"/actions/runs?head_sha="+url(sha)+"&per_page=10", null);
        JSONArray a = r.getJSONArray("workflow_runs");
        if (a.length()==0) return null;
        JSONObject x = a.getJSONObject(0);
        return new Run(x.getLong("id"), x.getString("status"), x.isNull("conclusion") ? null : x.optString("conclusion", null));
    }

    /** Finds only the workflow_dispatch run created after the dispatch request, avoiding stale runs on an unchanged SHA. */
    public Run findWorkflowDispatchRun(Repo repo, DispatchResult dispatch, String sha) throws Exception {
        String[] p = repo.fullName.split("/",2);
        String path = "/repos/"+p[0]+"/"+p[1]+"/actions/workflows/"+dispatch.workflowId+"/runs?event=workflow_dispatch&branch="+url(repo.defaultBranch)+"&per_page=20";
        JSONObject r = json("GET", path, null);
        JSONArray a = r.optJSONArray("workflow_runs");
        if (a == null) return null;
        long threshold = dispatch.requestedAtEpochMillis - 5000L;
        for (int i=0;i<a.length();i++) {
            JSONObject x=a.getJSONObject(i);
            if (!sha.equals(x.optString("head_sha",""))) continue;
            long created=0L;
            try { created=Instant.parse(x.optString("created_at","")).toEpochMilli(); } catch(Exception ignored) {}
            if (created>0L && created<threshold) continue;
            return new Run(x.getLong("id"), x.getString("status"), x.isNull("conclusion") ? null : x.optString("conclusion", null));
        }
        return null;
    }

    public Run getRun(String fullName, long runId) throws Exception {
        String[] p = fullName.split("/",2);
        JSONObject x = json("GET", "/repos/"+p[0]+"/"+p[1]+"/actions/runs/"+runId, null);
        return new Run(x.getLong("id"), x.getString("status"), x.isNull("conclusion") ? null : x.optString("conclusion", null));
    }

    public void cancelRun(String fullName, long runId) throws Exception {
        String[] p = fullName.split("/",2);
        json("POST", "/repos/"+p[0]+"/"+p[1]+"/actions/runs/"+runId+"/cancel", null);
    }

    public void rerunFailedJobs(String fullName, long runId) throws Exception {
        String[] p = fullName.split("/",2);
        json("POST", "/repos/"+p[0]+"/"+p[1]+"/actions/runs/"+runId+"/rerun-failed-jobs", null);
        DiagnosticLog.log("GITHUB_API rerun failed jobs run="+runId);
    }

    public List<Job> jobs(String fullName, long runId) throws Exception {
        String[] p = fullName.split("/",2);
        JSONObject r=json("GET", "/repos/"+p[0]+"/"+p[1]+"/actions/runs/"+runId+"/jobs?per_page=100", null);
        JSONArray a=r.optJSONArray("jobs");
        List<Job> out=new ArrayList<>();
        if(a==null)return out;
        for(int i=0;i<a.length();i++){
            JSONObject j=a.getJSONObject(i);
            List<String> failed=new ArrayList<>();
            JSONArray steps=j.optJSONArray("steps");
            if(steps!=null){
                for(int k=0;k<steps.length();k++){
                    JSONObject st=steps.getJSONObject(k);
                    String c=st.optString("conclusion","");
                    if("failure".equals(c)||"cancelled".equals(c)||"timed_out".equals(c)) failed.add(st.optString("name","step"));
                }
            }
            out.add(new Job(j.optLong("id",-1L), j.optString("name","job"), j.optString("status",""), j.optString("conclusion",""), failed));
        }
        return out;
    }

    public String downloadJobLog(String fullName, long jobId, int maxChars) throws Exception {
        String[] p=fullName.split("/",2);
        HttpURLConnection c=open("GET", "https://api.github.com/repos/"+p[0]+"/"+p[1]+"/actions/jobs/"+jobId+"/logs", true);
        c.setInstanceFollowRedirects(false);
        int code=c.getResponseCode();
        String loc=c.getHeaderField("Location");
        String text;
        if((code==301||code==302||code==307||code==308) && loc!=null){
            HttpURLConnection d=open("GET",loc,false);
            int dc=d.getResponseCode();
            if(dc<200||dc>=300) throw new Exception("Job log HTTP "+dc);
            text=readText(d.getInputStream());
        }else if(code>=200&&code<300){
            text=readText(c.getInputStream());
        }else{
            throw new Exception("Job log HTTP "+code+": "+readText(c.getErrorStream()));
        }
        if(maxChars>0 && text.length()>maxChars) text=text.substring(text.length()-maxChars);
        return text;
    }

    public String failureReport(String fullName, long runId) throws Exception {
        StringBuilder s=new StringBuilder();
        s.append("GitBuild Actions failure report\n");
        s.append("Repository: ").append(fullName).append('\n');
        s.append("Run: #").append(runId).append("\n\n");
        List<Job> jobs=jobs(fullName,runId);
        boolean any=false;
        for(Job j:jobs){
            String c=j.conclusion==null?"":j.conclusion;
            if(!("failure".equals(c)||"cancelled".equals(c)||"timed_out".equals(c)||"action_required".equals(c))) continue;
            any=true;
            s.append("Job: ").append(j.name).append(" [").append(c).append("] id=").append(j.id).append('\n');
            if(!j.failedSteps.isEmpty()) s.append("Failed steps: ").append(String.join(" / ",j.failedSteps)).append('\n');
            try{
                String log=downloadJobLog(fullName,j.id,12000);
                if(!log.trim().isEmpty()) s.append("--- log tail ---\n").append(log.trim()).append("\n--- end log ---\n");
            }catch(Exception e){
                s.append("Log download failed: ").append(e.getMessage()).append('\n');
            }
            s.append('\n');
        }
        if(!any) s.append("Failed job details were not available.\n");
        return s.toString();
    }

    public List<Artifact> artifacts(String fullName, long runId) throws Exception {
        String[] p = fullName.split("/",2);
        JSONObject r = json("GET", "/repos/"+p[0]+"/"+p[1]+"/actions/runs/"+runId+"/artifacts", null);
        JSONArray a = r.getJSONArray("artifacts"); List<Artifact> out = new ArrayList<>();
        for (int i=0;i<a.length();i++) {
            JSONObject x=a.getJSONObject(i);
            if(!x.optBoolean("expired",false)) out.add(new Artifact(x.getLong("id"), x.getString("name")));
        }
        return out;
    }

    public byte[] downloadArtifact(String fullName, long artifactId) throws Exception {
        String[] p = fullName.split("/",2);
        HttpURLConnection c = open("GET", "https://api.github.com/repos/"+p[0]+"/"+p[1]+"/actions/artifacts/"+artifactId+"/zip", true);
        c.setInstanceFollowRedirects(false);
        int code = c.getResponseCode();
        if (code != 302 && code != 301) throw new Exception("Artifact download HTTP " + code + ": " + readText(c.getErrorStream()));
        String loc = c.getHeaderField("Location");
        HttpURLConnection d = open("GET", loc, false);
        int dc = d.getResponseCode();
        if (dc < 200 || dc >= 300) throw new Exception("Artifact blob HTTP " + dc);
        try (InputStream in=d.getInputStream(); ByteArrayOutputStream out=new ByteArrayOutputStream()) {
            byte[] buf=new byte[32768]; int n;
            while((n=in.read(buf))>=0) out.write(buf,0,n);
            return out.toByteArray();
        }
    }

    private static byte[] readAll(ContentResolver r, android.net.Uri u) throws Exception {
        try(InputStream in=r.openInputStream(u); ByteArrayOutputStream out=new ByteArrayOutputStream()) {
            if(in==null) throw new Exception("Cannot open shared file: "+u);
            byte[] buf=new byte[32768]; int n;
            while((n=in.read(buf))>=0) out.write(buf,0,n);
            return out.toByteArray();
        }
    }

    private static String safeName(String s) { return s.replace("/","_").replace("\\","_"); }
    private static String url(String s) throws Exception { return URLEncoder.encode(s, "UTF-8").replace("+", "%20"); }
    private static String urlPath(String path) throws Exception {
        String[] parts = path.split("/", -1);
        StringBuilder out = new StringBuilder();
        for (String part : parts) {
            if (part.isEmpty()) continue;
            if (out.length() > 0) out.append('/');
            out.append(url(part));
        }
        return out.toString();
    }
}
