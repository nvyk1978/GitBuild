package com.cmyk.bookmarkslauncher.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.cmyk.bookmarkslauncher.data.BookmarkNode;

public final class BookmarkTileView extends FrameLayout {
    private static final int N_GRAY = 0xFF454040;
    private static final int N_LGRAY = 0xFF656060;
    private static final int N_ICON = 0xFFA9A999;
    private static final int N_ORANGE = 0xFF775500;
    private static final int N_GREEN = 0xFF227733;

    private final BookmarkNode node;
    private final TextView title;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path bookmarkPath = new Path();
    private boolean dropHighlight;

    public BookmarkTileView(Context context, BookmarkNode node) {
        super(context);
        this.node = node;
        setWillNotDraw(false);
        setPadding(dp(8), dp(8), dp(8), dp(8));
        setBackground(tileBackground(N_GRAY, 12));
        setClickable(true);
        setFocusable(true);

        title = new TextView(context);
        title.setText(node.title);
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(12);
        title.setMaxLines(node.spanY > 1 ? 3 : 2);
        title.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM);
        title.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        LayoutParams lp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
        addView(title, lp);
    }

    public BookmarkNode getNode() { return node; }

    public void setDropHighlight(boolean highlighted) {
        if (dropHighlight == highlighted) return;
        dropHighlight = highlighted;
        setBackground(tileBackground(highlighted ? N_LGRAY : N_GRAY, 12));
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float cx = getWidth() / 2f;
        float top = dp(12);
        float size = Math.min(getWidth(), getHeight()) * (node.spanX > 1 || node.spanY > 1 ? 0.26f : 0.34f);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(node.isFolder() ? N_ORANGE : N_ICON);

        if (node.isFolder()) {
            float left = cx - size;
            float right = cx + size;
            float bottom = top + size * 1.35f;
            canvas.drawRoundRect(left, top + size * 0.25f, right, bottom, dp(6), dp(6), paint);
            canvas.drawRoundRect(left + size * 0.12f, top, cx, top + size * 0.45f, dp(5), dp(5), paint);
        } else {
            bookmarkPath.reset();
            float left = cx - size * 0.65f;
            float right = cx + size * 0.65f;
            float bottom = top + size * 1.55f;
            bookmarkPath.moveTo(left, top);
            bookmarkPath.lineTo(right, top);
            bookmarkPath.lineTo(right, bottom);
            bookmarkPath.lineTo(cx, bottom - size * 0.45f);
            bookmarkPath.lineTo(left, bottom);
            bookmarkPath.close();
            canvas.drawPath(bookmarkPath, paint);
        }

        if (dropHighlight) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(2));
            paint.setColor(N_GREEN);
            canvas.drawRoundRect(dp(2), dp(2), getWidth() - dp(2), getHeight() - dp(2), dp(12), dp(12), paint);
            paint.setStyle(Paint.Style.FILL);
        }
    }

    private GradientDrawable tileBackground(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
