package com.cmyk.bookmarkslauncher.data;

public final class BookmarkNode {
    public static final int TYPE_BOOKMARK = 0;
    public static final int TYPE_FOLDER = 1;

    public String id;
    public String externalSource;
    public String externalId;
    public int type;
    public String parentId;
    public String title;
    public String url;
    public int sortIndex;
    public int spanX = 1;
    public int spanY = 1;
    public long createdAt;
    public long updatedAt;
    public Long lastAccessedAt;
    public Long deletedAt;
    public String faviconPath;
    public String screenshotPath;
    public String offlinePath;
    public Long offlineSavedAt;

    public boolean isFolder() {
        return type == TYPE_FOLDER;
    }
}
