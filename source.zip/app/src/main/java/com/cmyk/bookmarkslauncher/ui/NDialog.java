package com.cmyk.bookmarkslauncher.ui;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public final class NDialog {
    public interface ChoiceListener { void onChoice(int which); }
    public interface TextListener { void onText(String text); }

    private static final int D_GRAY = 0xFF252020;
    private static final int GRAY = 0xFF454040;
    private static final int L_GRAY = 0xFF656060;
    private static final int L_BLUE = 0xFF445577;
    private static final int L_RED = 0xFF662211;
    private static final int TEXT = 0xFFFFFFFF;
    private static final int ICON = 0xFFA9A999;

    private NDialog() {}

    public static void showChoices(Activity activity, String title, String[] items, int destructiveIndex, ChoiceListener listener) {
        Dialog dialog = baseDialog(activity);
        LinearLayout root = root(activity);
        addTitle(activity, root, title);
        for (int i = 0; i < items.length; i++) {
            final int index = i;
            TextView row = action(activity, items[i], i == destructiveIndex ? L_RED : GRAY);
            row.setOnClickListener(v -> {
                dialog.dismiss();
                listener.onChoice(index);
            });
            root.addView(row, lpMatchWrap(0, 4, 0, 4));
        }
        dialog.setContentView(root);
        show(activity, dialog);
    }

    public static void showMessage(Activity activity, String title, String message) {
        Dialog dialog = baseDialog(activity);
        LinearLayout root = root(activity);
        addTitle(activity, root, title);

        ScrollView scroll = new ScrollView(activity);
        TextView body = new TextView(activity);
        body.setText(message);
        body.setTextColor(TEXT);
        body.setTextSize(15);
        body.setLineSpacing(0f, 1.12f);
        body.setPadding(dp(activity, 4), dp(activity, 2), dp(activity, 4), dp(activity, 12));
        scroll.addView(body, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 280)));

        LinearLayout buttons = buttonRow(activity);
        TextView close = action(activity, "閉じる", GRAY);
        close.setGravity(Gravity.CENTER);
        close.setOnClickListener(v -> dialog.dismiss());
        buttons.addView(close, new LinearLayout.LayoutParams(dp(activity, 96), dp(activity, 46)));
        root.addView(buttons, lpMatchWrap(10, 8, 0, 0));

        dialog.setContentView(root);
        show(activity, dialog);
    }

    public static void showInput(Activity activity, String title, String hint, String initial,
                                 boolean uriInput, String positiveLabel, TextListener listener) {
        Dialog dialog = baseDialog(activity);
        LinearLayout root = root(activity);
        addTitle(activity, root, title);

        EditText input = new EditText(activity);
        input.setSingleLine(true);
        input.setText(initial == null ? "" : initial);
        input.setHint(hint);
        input.setTextColor(TEXT);
        input.setHintTextColor(ICON);
        input.setTextSize(16);
        input.setPadding(dp(activity, 14), 0, dp(activity, 14), 0);
        input.setBackground(roundRect(activity, GRAY, 12));
        input.setInputType(uriInput
                ? InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI
                : InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        root.addView(input, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 52)));

        LinearLayout buttons = buttonRow(activity);
        TextView cancel = action(activity, "キャンセル", GRAY);
        cancel.setGravity(Gravity.CENTER);
        cancel.setOnClickListener(v -> dialog.dismiss());
        buttons.addView(cancel, new LinearLayout.LayoutParams(dp(activity, 112), dp(activity, 46)));

        SpaceView gap = new SpaceView(activity);
        buttons.addView(gap, new LinearLayout.LayoutParams(dp(activity, 8), 1));

        TextView ok = action(activity, positiveLabel, L_BLUE);
        ok.setGravity(Gravity.CENTER);
        ok.setOnClickListener(v -> {
            String text = input.getText().toString().trim();
            dialog.dismiss();
            listener.onText(text);
        });
        buttons.addView(ok, new LinearLayout.LayoutParams(dp(activity, 96), dp(activity, 46)));
        root.addView(buttons, lpMatchWrap(14, 12, 0, 0));

        dialog.setContentView(root);
        dialog.setOnShowListener(d -> {
            input.requestFocus();
            Window w = dialog.getWindow();
            if (w != null) w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        });
        show(activity, dialog);
    }

    private static Dialog baseDialog(Activity activity) {
        Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        return dialog;
    }

    private static LinearLayout root(Activity activity) {
        LinearLayout root = new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(activity, 18), dp(activity, 18), dp(activity, 18), dp(activity, 18));
        root.setBackground(roundRect(activity, D_GRAY, 18));
        return root;
    }

    private static void addTitle(Activity activity, LinearLayout root, String title) {
        TextView tv = new TextView(activity);
        tv.setText(title);
        tv.setTextColor(TEXT);
        tv.setTextSize(20);
        tv.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(tv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 46)));
    }

    private static TextView action(Activity activity, String text, int background) {
        TextView tv = new TextView(activity);
        tv.setText(text);
        tv.setTextColor(TEXT);
        tv.setTextSize(16);
        tv.setGravity(Gravity.CENTER_VERTICAL);
        tv.setPadding(dp(activity, 14), 0, dp(activity, 14), 0);
        tv.setBackground(roundRect(activity, background, 12));
        return tv;
    }

    private static LinearLayout buttonRow(Activity activity) {
        LinearLayout row = new LinearLayout(activity);
        row.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        return row;
    }

    private static void show(Activity activity, Dialog dialog) {
        dialog.show();
        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawableResource(android.R.color.transparent);
            WindowManager.LayoutParams p = new WindowManager.LayoutParams();
            p.copyFrom(w.getAttributes());
            p.width = activity.getResources().getDisplayMetrics().widthPixels - dp(activity, 36);
            p.height = WindowManager.LayoutParams.WRAP_CONTENT;
            p.gravity = Gravity.CENTER;
            w.setAttributes(p);
        }
    }

    private static GradientDrawable roundRect(Activity activity, int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(activity, radiusDp));
        return d;
    }

    private static LinearLayout.LayoutParams lpMatchWrap(int top, int bottom, int left, int right) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(left, top, right, bottom);
        return lp;
    }

    private static int dp(Activity activity, int value) {
        return Math.round(value * activity.getResources().getDisplayMetrics().density);
    }

    private static final class SpaceView extends View {
        SpaceView(Activity activity) { super(activity); }
    }
}
