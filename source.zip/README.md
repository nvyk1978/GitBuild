# GitBuild 0.1.48

Android application for uploading source packages to GitHub and following GitHub Actions builds.

- App name: GitBuild
- applicationId: `com.cmyk.gitbuild`
- versionName: `0.1.48`
- versionCode: `49`
- compileSdk / targetSdk: 36
- Stable debug signing key: `app/gitbuild-dev.keystore`
