# GitBuild 0.1.51

Android GitHub build helper app.

- applicationId: `com.cmyk.gitbuild`
- version: `0.1.51 (52)`
- minSdk 29 / targetSdk 36 / compileSdk 36
- fixed signing key: `app/gitbuild-dev.keystore`
- GitHub Actions: `.github/workflows/build.yml`
- APK artifact: `GitBuild_0.1.51.apk`
- source artifact: `source.zip`
